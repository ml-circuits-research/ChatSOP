#!/usr/bin/env node
// Differential test: apply the same random compound "what-if" scenarios to several independently
// compiled knowledge bases and compare every conclusion with a reference KB. Each KB has its own
// vocabulary, so an adapter maps canonical changes and probes to that KB's relation names.
//
//   node test/difftest.mjs [N] [SEED] [--kbs r1,r2,r3] [--naive] [--lift]
//   node test/difftest.mjs --emit DIR N SEED      write the scenario queries as .sop files (for parity tests)
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Engine } from '../src/engine.mjs';

const ROOT = fileURLToPath(new URL('../experiment/', import.meta.url));
const TANKS = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8'];
const FULL = ['t1', 't2', 't3', 't4', 't5', 't6', 't7'];
const TECHS = ['ilse', 'bram', 'noor', 'tomas'];
const ZONES = ['hatchery', 'grow-out-hall', 'quarantine-wing'];
const SPECIES = ['arctic-char', 'rainbow-trout', 'atlantic-salmon', 'siberian-sturgeon'];
const CERTS = ['hatchery', 'grow-out', 'medication'];

const COMMON = {
  temp: 'set {t} temp-c {v}', biomass: 'set {t} biomass-kg {v}', volume: 'set {t} volume-m3 {v}',
  resp: ['remove ?x responsible-for {t}', 'add {w} responsible-for {t}'],
  maint: 'add {p} under-maintenance yes', move: 'set {t} located-in {z}',
  species: 'set {t} holds-species {s}', stage: 'set {t} life-stage {l}',
  backup_add: 'add {t} has backup-aeration', backup_rm: 'remove {t} has backup-aeration',
  probes: {
    overstocked: ['?t overstocked yes'], thermal: ['?t thermal-alarm yes'], stressed: ['?t stressed yes'],
    test: ['?t water-test-frequency ?v'], feed: ['?t feedings-per-day ?v'], atrisk: ['?t at-risk yes'],
    quarantine: ['?t under-quarantine yes'], empty: ['?t is-empty yes'], overloaded: ['?t overloaded yes'],
  },
  viol: ['?p', '?t'],
};
export const ADAPTERS = {
  ref: {
    temp: 'set {t} temp {v}', biomass: 'set {t} biomass {v}', volume: 'set {t} volume {v}',
    resp: ['set {t} responsible {w}'], circuit: 'add {c} status down', maint: 'add {p} status under-maintenance',
    move: 'set {t} located-in {z}', species: 'set {t} holds {s}', stage: 'set {t} life-stage {l}',
    backup_add: 'add {t} has backup-aeration', backup_rm: 'remove {t} has backup-aeration',
    cert_add: 'add {w} certified {c}-cert', cert_rm: 'remove {w} certified {c}-cert',
    probes: {
      overstocked: ['?t status overstocked'], thermal: ['?t status thermal-alarm'], stressed: ['?t status stressed'],
      test: ['?t water-test ?v'], feed: ['?t feedings-per-day ?v'], atrisk: ['?t status at-risk'],
      quarantine: ['?t status under-quarantine'], empty: ['?t status empty'], overloaded: ['?t status overloaded'],
      limit: ['?t holds ?s', '?s density-limit ?v'], density: ['?t density ?v'],
    },
    constraint: 'c-cert', viol: ['?who', '?t'], transfer: 'transfer', treat: 'treat', dir: 'reference',
  },
  r1: {
    ...COMMON, temp: 'set {t} temperature-c {v}', circuit: 'add {c} circuit-down yes',
    backup_add: 'add {t} has-backup-aeration yes', backup_rm: 'remove {t} has-backup-aeration yes',
    cert_add: 'add {w} certified-for {c}-cert', cert_rm: 'remove {w} certified-for {c}-cert',
    probes: { ...COMMON.probes, limit: ['?t density-limit-kgm3 ?v'], density: ['?t density-kgm3 ?v'] },
    constraint: 'c-responsible-certified', transfer: 'transfer-fish', treat: 'treat-tank', dir: 'sonnet-runs/r1',
  },
  r2: {
    ...COMMON, circuit: 'add {c} is-down yes',
    cert_add: 'add {w} certified-for {c}', cert_rm: 'remove {w} certified-for {c}',
    probes: { ...COMMON.probes, limit: ['?t holds-species ?s', '?s density-limit-kg-m3 ?v'], density: ['?t density-kg-m3 ?v'] },
    constraint: 'c-responsible-cert', transfer: 'transfer-fish', treat: 'treat-sick-tank', dir: 'sonnet-runs/r2',
  },
  r3: {
    ...COMMON, circuit: 'add {c} power down',
    cert_add: 'add {w} certified {c}', cert_rm: 'remove {w} certified {c}',
    probes: { ...COMMON.probes, limit: ['?t is-a tank', '?t density-limit ?v'], density: ['?t density ?v'] },
    constraint: 'c-certification', transfer: 'transfer', treat: 'treat', dir: 'sonnet-runs/r3',
  },
};

// deterministic PRNG (mulberry32)
export function rng(seed) {
  let a = seed >>> 0;
  const next = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  return { next, choice: (xs) => xs[Math.floor(next() * xs.length)], sample: (xs, k) => { const c = xs.slice(), o = []; while (o.length < k) o.push(c.splice(Math.floor(next() * c.length), 1)[0]); return o; } };
}

export function scenario(R) {
  const n = R.choice([1, 2, 2, 3, 3, 4]);
  const changes = [], used = new Set();
  let guard = 0;
  while (changes.length < n && guard++ < 1000) {
    const kind = R.choice(['temp', 'temp', 'biomass', 'biomass', 'volume', 'resp', 'resp', 'circuit', 'maint', 'move', 'move',
      'species', 'species', 'stage', 'backup_add', 'backup_rm', 'cert_add', 'cert_rm']);
    let a, key;
    if (['temp', 'biomass', 'species', 'stage'].includes(kind)) {
      const t = R.choice(FULL);
      a = { t, v: kind === 'temp' ? R.choice([3, 5, 6, 9, 12, 13, 16, 17, 20]) : R.choice([60, 150, 200, 250, 400, 500, 800, 1000, 1200, 1500, 2000]), s: R.choice(SPECIES), l: R.choice(['fry', 'adult']) };
      key = kind + t;
    } else if (['volume', 'move', 'resp', 'backup_add'].includes(kind)) {
      const t = R.choice(TANKS);
      a = { t, v: R.choice([5, 8, 10, 20, 40, 60, 100]), z: R.choice(ZONES), w: R.choice(TECHS) };
      key = kind + t;
    } else if (kind === 'backup_rm') { a = { t: 't5' }; key = kind + 't5'; if (used.has('backup_addt5')) continue; }
    else if (kind === 'circuit') { const c = R.choice(['circuit-a', 'circuit-b']); a = { c }; key = kind + c; }
    else if (kind === 'maint') { const p = R.choice(['p1', 'p2', 'p3', 'p4']); a = { p }; key = kind + p; }
    else { const w = R.choice(TECHS), c = R.choice(CERTS); a = { w, c }; key = 'cert' + w + c; }
    if (used.has(key) || (kind === 'backup_add' && a.t === 't5' && used.has('backup_rmt5'))) continue;
    used.add(key);
    changes.push([kind, a]);
  }
  const transfers = [0, 1, 2].map(() => R.sample(TANKS, 2));
  transfers[0] = [R.choice(FULL), 't8'];
  const treats = R.sample(FULL, 2);
  return { changes, transfers, treats };
}

const fill = (tpl, a) => tpl.replace(/\{(\w)\}/g, (_, k) => a[k]);

export function build(ad, sc, withAnswers = false) {
  const q = ['@w assume'];
  for (const [kind, a] of sc.changes) for (const line of [].concat(ad[kind])) q.push('  ' + fill(line, a));
  for (const [name, pats] of Object.entries(ad.probes)) { q.push(`@pr-${name} find\n  in $w`); for (const p of pats) q.push('  match ' + p); }
  q.push('@viol check\n  in $w');
  sc.transfers.forEach(([a, b], i) => {
    q.push(`@tr${i} plan\n  in $w\n  task ${ad.transfer} ${a} ${b}`);
    q.push(`@tr${i}-empty find\n  in $tr${i}\n  match ${ad.probes.empty[0]}`);
    q.push(`@tr${i}-dens find\n  in $tr${i}\n  match ${ad.probes.density[0].replace('?t', b)}`);
  });
  sc.treats.forEach((t, i) => q.push(`@tt${i} plan\n  in $w\n  task ${ad.treat} ${t}`));
  if (withAnswers) {
    for (const name of Object.keys(ad.probes)) q.push(`@a-${name} answer\n  from $pr-${name}`);
    q.push('@a-viol answer\n  from $viol');
    sc.transfers.forEach((_, i) => q.push(`@a-tr${i} answer\n  from $tr${i}\n@a-tr${i}-empty answer\n  from $tr${i}-empty\n@a-tr${i}-dens answer\n  from $tr${i}-dens`));
    sc.treats.forEach((_, i) => q.push(`@a-tt${i} answer\n  from $tt${i}`));
  }
  return q.join('\n') + '\n';
}

export function observe(eng, ad, sc) {
  eng.query(build(ad, sc));
  if (eng.errors.length) throw new Error(eng.errors.slice(0, 3).join('\n'));
  const D = eng.dict;
  const obs = {};
  for (const name of Object.keys(ad.probes)) {
    const rows = eng.result('pr-' + name).rows;
    obs[name] = ['test', 'feed', 'limit', 'density'].includes(name)
      ? rows.map((r) => [D.str(r['?t']), D.str(r['?v'])]).sort().map((x) => x.join('='))
      : rows.map((r) => D.str(r['?t'])).sort();
  }
  const [pv, tv] = ad.viol;
  obs.violations = [...new Set(eng.result('viol').rows.filter((r) => D.str(r['?constraint']) === ad.constraint).map((r) => D.str(r[pv]) + '/' + D.str(r[tv])))].sort();
  obs.transfer = sc.transfers.map(([a, b], i) => {
    const res = eng.result('tr' + i);
    if (!res.ok) return `${a}->${b} BLOCKED`;
    const steps = res.rows.map((r) => D.str(r['?step']).toLowerCase()).join(' ');
    const empty = eng.result(`tr${i}-empty`).rows.map((r) => D.str(r['?t'])).sort().join(',');
    const dens = eng.result(`tr${i}-dens`).rows.map((r) => D.str(r['?v'])).sort().join(',');
    return `${a}->${b} OK ${steps.includes('peroxide') ? 'disinfect' : 'no-disinfect'} empty=${empty} dens=${dens}`;
  });
  obs.treat = sc.treats.map((t, i) => {
    const res = eng.result('tt' + i);
    if (!res.ok) return `${t} BLOCKED`;
    const steps = res.rows.map((r) => D.str(r['?step']).toLowerCase()).join(' ');
    return `${t} OK ${steps.includes('formalin') ? 'formalin' : steps.includes('salin') || steps.includes('salt') ? 'salt' : '?'} ${res.rows.length}`;
  });
  return obs;
}

export function loadKB(name, opts = {}) {
  const dir = ROOT + ADAPTERS[name].dir;
  return new Engine(['kb1.sop', 'kb2.sop'].map((f) => [f, readFileSync(`${dir}/${f}`, 'utf8')]), opts);
}

function main() {
  const argv = process.argv.slice(2);
  if (argv[0] === '--emit') {
    const [, dir, n, seed] = argv;
    const R = rng(parseInt(seed, 10));
    const cases = [];
    for (let k = 0; k < parseInt(n, 10); k++) {
      const sc = scenario(R);
      for (const name of Object.keys(ADAPTERS)) {
        mkdirSync(`${dir}/${name}`, { recursive: true });
        const f = `${dir}/${name}/s${String(k).padStart(4, '0')}.sop`;
        writeFileSync(f, build(ADAPTERS[name], sc, true));
        const kb = `experiment/${ADAPTERS[name].dir}`;
        cases.push(['run', `${kb}/kb1.sop`, `${kb}/kb2.sop`, '-q', f]);
      }
    }
    writeFileSync(`${dir}/cases.json`, JSON.stringify(cases));
    console.log(`${cases.length} cases written to ${dir}/cases.json`);
    return;
  }
  const pos = argv.filter((a) => !a.startsWith('--'));
  const n = parseInt(pos[0] || '300', 10), seed = parseInt(pos[1] || '7', 10);
  const kbs = argv.includes('--kbs') ? argv[argv.indexOf('--kbs') + 1].split(',') : ['r1', 'r2', 'r3'];
  const opts = argv.includes('--naive') ? { seminaive: false, lazy: false, incremental: false, joinOrder: false } : {};
  if (argv.includes('--lift')) Object.assign(opts, { lift: true, liftMin: 2 });
  const R = rng(seed);
  const t0 = performance.now();
  const ref = loadKB('ref', opts);
  const engs = Object.fromEntries(kbs.map((k) => [k, loadKB(k, opts)]));
  const total = {}, agree = Object.fromEntries(kbs.map((k) => [k, {}])), scenOk = Object.fromEntries(kbs.map((k) => [k, 0]));
  const diffs = [];
  for (let s = 0; s < n; s++) {
    const sc = scenario(R);
    const want = observe(ref, ADAPTERS.ref, sc);
    for (const [key, v] of Object.entries(want)) total[key] = (total[key] || 0) + (Array.isArray(v) && ['transfer', 'treat'].includes(key) ? v.length : 1);
    for (const k of kbs) {
      const got = observe(engs[k], ADAPTERS[k], sc);
      let ok = true;
      for (const [key, v] of Object.entries(want)) {
        const items = ['transfer', 'treat'].includes(key) ? v.map((x, i) => [x, got[key][i]]) : [[JSON.stringify(v), JSON.stringify(got[key])]];
        for (const [a, b] of items) {
          if (a === b) agree[k][key] = (agree[k][key] || 0) + 1;
          else { ok = false; diffs.push({ kb: k, scenario: s, probe: key, changes: sc.changes, ref: a, got: b }); }
        }
      }
      if (ok) scenOk[k]++;
    }
  }
  const pad = (x, w) => String(x).padStart(w);
  console.log(`${n} scenarios, seed ${seed}, ${(performance.now() - t0).toFixed(0)} ms`);
  console.log('probe'.padEnd(12) + pad('total', 7) + kbs.map((k) => pad(k, 8)).join(''));
  for (const key of Object.keys(total)) console.log(key.padEnd(12) + pad(total[key], 7) + kbs.map((k) => pad(agree[k][key] || 0, 8)).join(''));
  const T = Object.values(total).reduce((a, b) => a + b, 0);
  console.log('ALL'.padEnd(12) + pad(T, 7) + kbs.map((k) => pad(Object.values(agree[k]).reduce((a, b) => a + b, 0), 8)).join(''));
  console.log('scenarios'.padEnd(12) + pad(n, 7) + kbs.map((k) => pad(scenOk[k], 8)).join(''));
  writeFileSync('difftest_diffs.json', JSON.stringify(diffs, null, 1));
  console.log(`${diffs.length} disagreements written to difftest_diffs.json`);
  process.exitCode = diffs.length ? 1 : 0;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main();
