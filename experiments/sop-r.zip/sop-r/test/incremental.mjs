#!/usr/bin/env node
// Incremental-maintenance test: random hypothetical worlds (pure additions, removals and mixes)
// on a synthetic KB, answered by the incremental engine and by an engine that re-saturates every
// world from scratch. Every answer must be identical.   node test/incremental.mjs [N] [WORLDS] [SEED]
import { Engine } from '../src/engine.mjs';
import { generate } from '../bench/gen.mjs';
import { rng } from './difftest.mjs';

const [N = 1500, W = 150, SEED = 3] = process.argv.slice(2).map(Number);
const CL = Math.max(20, N / 10), Z = Math.max(10, N / 200);
const kb = generate(N, CL, Z, 1);
const inc = new Engine([['kb', kb]]);
const ref = new Engine([['kb', kb]], { incremental: false });
const R = rng(SEED);
const probes = ['?x alert yes', '?x busy yes', '?x hotspot yes', '?x has-busy-zone yes', '?x limit ?v', '?x located-in ?v', '?x overloaded yes', '?x shift ?v'];
let same = 0, diff = 0, n = 0;
const stats = { adds: 0, mixed: 0 };
for (let k = 0; k < W; k++) {
  const lines = [];
  const pureAdd = R.next() < 0.6;
  pureAdd ? stats.adds++ : stats.mixed++;
  const m = 1 + Math.floor(R.next() * 4);
  for (let i = 0; i < m; i++) {
    const e = R.next() < 0.5 ? `new${k}-${i}` : `e${Math.floor(R.next() * N)}`;
    const c = Math.floor(R.next() * 6);
    if (c === 0) lines.push(`add ${e} is-a c${Math.floor(R.next() * CL)}`);
    if (c === 1) lines.push(`add ${e} in-zone z${Math.floor(R.next() * Z)}`);
    if (c === 2) lines.push(`add ${e} load ${50 + Math.floor(R.next() * 50)}`, `add ${e} capacity ${20 + Math.floor(R.next() * 40)}`);
    if (c === 3) lines.push(`add z${Math.floor(R.next() * Z)} located-in s${Math.floor(R.next() * 3)}`);
    if (c === 4) lines.push(pureAdd ? `add ${e} has backup` : `remove ${e} has backup`);
    if (c === 5) lines.push(pureAdd ? `add c${Math.floor(R.next() * CL)} subclass-of m0` : `set e${Math.floor(R.next() * N)} load 95`);
  }
  // ask the probes in a random order, sometimes nesting a second world on the first
  const nested = R.next() < 0.3;
  const q = ['@w assume', ...lines.map((l) => '  ' + l)];
  if (nested) q.push('@w2 assume', '  in $w', `  add extra${k} is-a c1`, `  add extra${k} in-zone z0`, `  add extra${k} load 99`, `  add extra${k} capacity 20`);
  const order = probes.map((p, i) => [R.next(), p, i]).sort((a, b) => a[0] - b[0]);
  for (const [, p, i] of order) q.push(`@p${i} find`, `  in $${nested ? 'w2' : 'w'}`, `  match ${p}`, `@a${i} answer`, `  from $p${i}`);
  const text = q.join('\n') + '\n';
  const a = inc.query(text), b = ref.query(text);
  if (a.errors.length || b.errors.length) { console.log(a.errors, b.errors); process.exit(1); }
  for (const name of a.answers()) {
    n++;
    if (a.render(name) === b.render(name)) same++;
    else { diff++; if (diff < 4) console.log('DIFF world', k, name, lines); }
  }
}
console.log(`${W} worlds (${stats.adds} pure-addition, ${stats.mixed} mixed), ${n} answers: ${same} identical, ${diff} different; incremental continuations: ${inc.stats.incremental || 0}`);
process.exitCode = diff ? 1 : 0;
