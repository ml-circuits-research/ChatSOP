#!/usr/bin/env node
// Grade the 12 compound scenarios (6 questions each) for the Sonnet-written query circuits (r1..r3)
// and for Sonnet answering directly from the text (baseline), against the gold answers.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Engine } from '../src/engine.mjs';

const E = fileURLToPath(new URL('../experiment/', import.meta.url));
const gold = JSON.parse(readFileSync(E + 'material/compound_gold.json', 'utf8'));
const TANKS = new Set(['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']);
const TECHS = new Set(['ilse', 'bram', 'noor', 'tomas']);
const norm = (g) => JSON.stringify({ a: [...g.a].sort(), b: g.b, c: [...g.c].sort(), d: g.d.map((x) => x.join('/')).sort(), e: [...g.e].sort(), f: g.f });

function fromEngine(run, sid) {
  const d = `${E}sonnet-runs/${run}`;
  const eng = new Engine([['kb1.sop', readFileSync(`${d}/kb1.sop`, 'utf8')], ['kb2.sop', readFileSync(`${d}/kb2.sop`, 'utf8')],
    ['query', readFileSync(`${d}/compound-queries/${sid.toLowerCase()}.sop`, 'utf8')]]);
  if (eng.errors.length) throw new Error(eng.errors.join('\n'));
  const D = eng.dict;
  const res = (ans) => eng.result(eng.wires.get(ans).one('from').args[0].slice(1));
  const vals = (r) => r.rows.flatMap((row) => Object.values(row).map((id) => D.val(id)));
  const nums = vals(res('b')).filter((v) => typeof v === 'number');
  return {
    a: [...new Set(vals(res('a')).filter((v) => TANKS.has(v)))],
    b: nums.length === 1 ? nums[0] : nums,
    c: [...new Set(vals(res('c')).filter((v) => TANKS.has(v)))],
    d: [...new Set(res('d').rows.map((row) => { const v = Object.values(row).map((id) => D.val(id)); const p = v.find((x) => TECHS.has(x)); const t = v.find((x) => TANKS.has(x)); return p && t ? `${p}/${t}` : null; }).filter(Boolean))].map((x) => x.split('/')),
    e: [...new Set(vals(res('e')).filter((v) => TECHS.has(v)))],
    f: res('f').ok ? 'yes' : 'no',
  };
}

for (const name of ['baseline/compound-run1', 'baseline/compound-run2', 'r1', 'r2', 'r3']) {
  let ok = 0, n = 0; const bad = [];
  const answers = name.startsWith('baseline') ? JSON.parse(readFileSync(`${E}${name}.json`, 'utf8')) : null;
  for (const [sid, g] of Object.entries(gold)) {
    const got = answers ? answers[sid] : fromEngine(name, sid);
    const G = JSON.parse(norm(g)), X = JSON.parse(norm(got));
    for (const k of 'abcdef') { n++; if (JSON.stringify(G[k]) === JSON.stringify(X[k])) ok++; else bad.push(`${sid}.${k}: gold ${JSON.stringify(G[k])} got ${JSON.stringify(X[k])}`); }
  }
  console.log(`${name}: ${ok}/${n}`);
  for (const b of bad) console.log('    ' + b);
}
