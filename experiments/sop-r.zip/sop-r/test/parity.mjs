#!/usr/bin/env node
// Parity test: run the reference Python engine and the Node engine on the same inputs and compare
// their output byte for byte.   node test/parity.mjs CASES.json [--py path/to/sopr.py] [--opts "--naive"]
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const casesFile = args[0];
const py = args.includes('--py') ? args[args.indexOf('--py') + 1] : fileURLToPath(new URL('../experiment/python-original/sopr.py', import.meta.url));
const extra = args.includes('--opts') ? args[args.indexOf('--opts') + 1].split(' ').filter(Boolean) : [];
const cli = fileURLToPath(new URL('../bin/sopr.mjs', import.meta.url));
const cases = JSON.parse(readFileSync(casesFile, 'utf8'));
let same = 0, diff = 0;
const fails = [];
for (const c of cases) {
  const a = spawnSync('python3', [py, ...c], { encoding: 'utf8' });
  const b = spawnSync('node', [cli, ...c, ...extra], { encoding: 'utf8' });
  if (a.stdout === b.stdout && a.status === b.status) same++;
  else { diff++; fails.push({ c, py: a.stdout + a.stderr, node: b.stdout + b.stderr }); }
}
console.log(`${cases.length} cases: ${same} identical, ${diff} different`);
for (const f of fails.slice(0, 8)) {
  console.log('--- ' + f.c.join(' '));
  const pl = f.py.split('\n'), nl = f.node.split('\n');
  for (let i = 0; i < Math.max(pl.length, nl.length); i++) if (pl[i] !== nl[i]) { console.log('  py  : ' + pl[i]); console.log('  node: ' + nl[i]); if (i > 40) break; }
}
process.exitCode = diff ? 1 : 0;
