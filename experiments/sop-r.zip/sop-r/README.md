# SOP-R — reasoning simbolic peste circuite SOP Lang

Un LLM citește un text (manual, regulament, instrucțiuni) și îl compilează în circuite SOP Lang: fire cu atribuire unică, de tip fapte, reguli, constrângeri și proceduri. O interogare este tot un circuit, iar evaluarea ei face raționamentul: deducție, excepții, agregări, lumi ipotetice, planificare, verificări, cu explicație pentru fiecare răspuns.

Arhiva conține propunerea, motorul în Node (fără dependențe, Node ≥ 18), documentația și tot experimentul pilot, reproductibil.

## Ce e unde

| | |
|---|---|
| `docs/PROPUNERE.md` | propunerea: tipurile de fire, algoritmul, pilotul și rezultatele, experimentul la scară |
| `docs/SCALARE.md` | explozia combinatorică și indexarea la zeci–sute de milioane de fire, cu măsurători |
| `docs/IMPLEMENTARE.md` | arhitectura motorului, invarianții, testele, cum se extinde, ce trebuie pentru producție |
| `docs/SPEC.md` | specificația limbajului (în engleză: este textul dat LLM-ului compilator) |
| `src/`, `bin/sopr.mjs` | motorul și linia de comandă |
| `test/` | paritate cu prototipul Python, test diferențial, test incremental, notarea scenariilor |
| `bench/` | generatorul de KB-uri sintetice mari și benchmark-ul pe configurații |
| `experiment/` | manualul, întrebările, KB-ul de referință, cele 3 rulări Sonnet, baseline-urile, prompturile, prototipul Python |

## Pornire rapidă

```
node bin/sopr.mjs lint  experiment/sonnet-runs/r1/kb1.sop experiment/sonnet-runs/r1/kb2.sop
node bin/sopr.mjs vocab experiment/sonnet-runs/r1/kb1.sop experiment/sonnet-runs/r1/kb2.sop
node bin/sopr.mjs run   experiment/sonnet-runs/r1/kb1.sop experiment/sonnet-runs/r1/kb2.sop \
                        -q experiment/sonnet-runs/r1/queries/q18.sop
node bin/sopr.mjs why   experiment/reference/kb1.sop experiment/reference/kb2.sop -t "t1 water-test daily"
node bin/sopr.mjs run   experiment/examples/bikes.sop -q experiment/examples/bikes-queries.sop
```

Din cod:

```js
import { Engine } from './src/engine.mjs';
const eng = new Engine([['kb.sop', kbText]]);           // compilare + lint
if (eng.errors.length) throw new Error(eng.errors.join('\n'));
eng.query(queryText);                                    // se poate repeta; KB-ul și saturarea rămân
for (const name of eng.answers()) console.log(eng.render(name));
```

## Teste și benchmark

```
npm test                      # test diferențial (300 de lumi), incremental (200 de lumi), notarea scenariilor
npm run test:parity           # 302 comenzi pe pilot, comparate cu prototipul Python (cere python3)
npm run test:parity-random    # 400 de scenarii aleatoare, Python vs Node
npm run bench:small           # 20.000 de entități, toate configurațiile (circa 1 minut)
npm run bench:medium          # 100.000 de entități (circa 5 minute, circa 1,5 GB RAM)
npm run bench:rules           # 200.000 de reguli
```

Opțiunile motorului (`--naive`, `--no-lazy`, `--no-seminaive`, `--no-incremental`, `--no-join-order`, `--no-provenance`, `--lift`) pornesc sau opresc fiecare optimizare. Toate combinațiile dau aceleași răspunsuri; testele verifică asta.

## Rezultate pe scurt

- **Pilot:** 3 compilări Sonnet independente → 78/78 întrebări și 215/216 întrebări pe scenarii compuse. Sonnet citind direct textul a răspuns și el corect la tot, deci la scara pilotului lanțul simbolic nu e mai bun, doar verificabil.
- **Portul Node** dă aceleași ieșiri ca Python pe 702 comenzi. Singurele 3 diferențe sunt la `why`, unde e găsit alt lanț de derivare, la fel de valid.
- **Viteză:** la 2.000 de entități, sub 0,1 s pe interogare față de circa 40 s în prototipul Python. La 100.000 de entități (1,28 milioane de fapte), o lume ipotetică prin adăugare durează 31 ms, față de 29 s cu algoritmul naiv.
