#!/usr/bin/env python3
"""
sopr.py - SOP-R: a minimal symbolic reasoning profile on top of SOP Lang-style
single-assignment wires.

  @wireName wireType
    keyword value ...

Knowledge wires : fact, rule, constraint, method   (+ find / group as reusable views)
Query wires     : find, group, assume, plan, check, answer

One data model (triples with provenance, living in a "world") and one evaluation
principle (stratified fixpoint + world forking + task decomposition).

Usage:
  sopr.py lint  KB.sop [KB2.sop ...]
  sopr.py vocab KB.sop [KB2.sop ...]
  sopr.py run   KB.sop [KB2.sop ...] -q QUERY.sop
  sopr.py why   KB.sop [KB2.sop ...] -t "subject relation object"
"""
import sys
import re
from collections import defaultdict


class SopError(Exception):
    pass


class Q(str):
    """A quoted string literal (never lower-cased, never a variable)."""


NUM = re.compile(r'^-?\d+(\.\d+)?$')
LEX = re.compile(r'"([^"]*)"|(\S+)')
NAME = re.compile(r'^[a-z0-9_.\-]+$')


def norm(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, float):
        v = round(v, 6)
        if v == int(v):
            return int(v)
    return v


def lex(line):
    out = []
    for m in LEX.finditer(line):
        if m.group(1) is not None:
            out.append(Q(m.group(1)))
            continue
        t = m.group(2)
        if t.startswith('#'):
            break
        if NUM.match(t):
            out.append(norm(float(t)) if '.' in t else int(t))
        else:
            out.append(t.lower())
    return out


def is_var(t):
    return type(t) is str and t.startswith('?')


def is_ref(t):
    return type(t) is str and t.startswith('$')


def fmt(v):
    if isinstance(v, Q):
        return '"%s"' % v
    return str(v)


def fmt_t(t):
    return ' '.join(fmt(x) for x in t)


class Line:
    def __init__(self, kw, args, n, raw):
        self.kw, self.args, self.n, self.raw = kw, args, n, raw


class Wire:
    def __init__(self, name, type_, origin, n):
        self.name, self.type, self.origin, self.n = name, type_, origin, n
        self.lines = []

    def get(self, *kws):
        return [l for l in self.lines if l.kw in kws]

    def one(self, kw):
        for l in self.lines:
            if l.kw == kw:
                return l
        return None

    def where(self):
        return '%s:%d @%s' % (self.origin, self.n, self.name)


def parse(text, origin):
    wires, cur = [], None
    for n, line in enumerate(text.splitlines(), 1):
        toks = lex(line)
        if not toks:
            continue
        head = toks[0]
        if type(head) is str and head.startswith('@'):
            if len(toks) != 2 or type(toks[1]) is not str:
                raise SopError('%s:%d: a wire header is "@name type"' % (origin, n))
            cur = Wire(head[1:], toks[1], origin, n)
            wires.append(cur)
        else:
            if cur is None:
                raise SopError('%s:%d: line outside of a wire' % (origin, n))
            if type(head) is not str:
                raise SopError('%s:%d: line must start with a keyword' % (origin, n))
            raw = line.strip()[len(head):].strip() if line.strip().lower().startswith(head) else ''
            cur.lines.append(Line(head, toks[1:], n, raw))
    return wires


POS, NEG = ('when', 'match'), ('unless', 'not')
META = ('source', 'note')
AGGS = ('count', 'sum', 'min', 'max', 'avg')
KEYWORDS = {
    'fact': None,  # frame: any keyword is a relation
    'rule': POS + NEG + ('let', 'test', 'from', 'then', 'overrides', 'supersedes') + META,
    'constraint': POS + NEG + ('let', 'test', 'from', 'message', 'supersedes') + META,
    'method': POS + NEG + ('task', 'let', 'test', 'require', 'forbid', 'require-test', 'step', 'do',
                           'forall', 'add', 'remove', 'set', 'supersedes') + META,
    'find': POS + NEG + ('in', 'from', 'let', 'test', 'return') + META,
    'group': POS + NEG + ('in', 'from', 'let', 'test', 'by') + AGGS + META,
    'assume': ('in', 'add', 'remove', 'set') + META,
    'plan': ('in', 'task') + META,
    'check': ('in',) + META,
    'answer': ('from', 'show', 'text') + META,
}
FACT_RESERVED = ('about', 'say', 'overrides', 'supersedes') + META
OPS = {'+', '-', '*', '/', '(', ')', '<', '<=', '>', '>=', '=', '!=', 'and', 'or'}

PRELUDE = """
@prelude-isa rule
  when ?x is-a ?c
  when ?c subclass-of ?d
  then ?x is-a ?d
@prelude-sub rule
  when ?a subclass-of ?b
  when ?b subclass-of ?c
  then ?a subclass-of ?c
"""


class Store:
    def __init__(self):
        self.by_rel = defaultdict(set)
        self.why = {}

    def add(self, t, why):
        s = self.by_rel[t[1]]
        if t in s:
            return False
        s.add(t)
        self.why[t] = why
        return True

    def __contains__(self, t):
        return t in self.by_rel.get(t[1], ())

    def all(self):
        for s in list(self.by_rel.values()):
            yield from s


class World:
    def __init__(self, eng, base, assumed=()):
        self.eng, self.base, self.assumed, self._st = eng, set(base), set(assumed), None

    def store(self):
        if self._st is None:
            self._st = self.eng.saturate(self.base, self.assumed)
        return self._st

    def copy(self):
        return World(self.eng, self.base, self.assumed)

    def add(self, t):
        self.base.add(t)
        self.assumed.add(t)
        self._st = None

    def remove(self, pat):
        rm = [t for t in self.base if all(is_var(p) or p == v for p, v in zip(pat, t))]
        self.base.difference_update(rm)
        self._st = None
        return rm

    def take(self, other):
        self.base, self.assumed, self._st = other.base, other.assumed, None


class Engine:
    def __init__(self, sources):
        """sources: list of (origin, text). KB wires accumulate across sources."""
        self.errors, self.warnings = [], []
        self.wires, self.order = {}, []
        for origin, text in [('prelude', PRELUDE)] + list(sources):
            for w in parse(text, origin):
                if w.name in self.wires:
                    self.errors.append('%s: wire name already assigned at %s (single assignment!)'
                                       % (w.where(), self.wires[w.name].where()))
                    continue
                self.wires[w.name] = w
                self.order.append(w)
        self.inactive = set()
        self.body, self.heads, self.meth = {}, {}, {}
        self.results = {}
        self._compile()

    # ------------------------------------------------------------ compile
    def err(self, w, msg, line=None):
        self.errors.append('%s%s: %s' % (w.where(), ' line %d' % line.n if line else '', msg))

    def warn(self, w, msg, line=None):
        self.warnings.append('%s%s: %s' % (w.where(), ' line %d' % line.n if line else '', msg))

    def ref(self, w, line, types=None):
        if len(line.args) != 1 or not is_ref(line.args[0]):
            self.err(w, '"%s" expects one $wire reference' % line.kw, line)
            return None
        name = line.args[0][1:]
        if name not in self.wires:
            self.err(w, 'unknown wire $%s' % name, line)
            return None
        if types and self.wires[name].type not in types:
            self.err(w, '$%s is a %s, expected %s' % (name, self.wires[name].type, '/'.join(types)), line)
            return None
        return name

    def pat(self, w, line, args=None):
        a = line.args if args is None else args
        if len(a) != 3:
            self.err(w, '"%s" expects a statement of exactly 3 terms: subject relation object '
                        '(quote multi-word values)' % line.kw, line)
            return None
        if any(is_ref(x) for x in a):
            self.err(w, '$wire reference not allowed inside a statement', line)
            return None
        return tuple(a)

    def expr(self, w, line):
        toks = lex(line.raw.replace('(', ' ( ').replace(')', ' ) '))
        if not toks:
            self.err(w, 'empty expression', line)
        return toks

    def _compile(self):
        for w in self.order:
            if w.type not in KEYWORDS:
                self.err(w, 'unknown wire type "%s"' % w.type)
                continue
            allowed = KEYWORDS[w.type]
            if w.origin == 'query' and w.type in ('fact', 'rule', 'constraint', 'method'):
                self.err(w, 'a query file may only contain query wires (find, group, assume, plan, '
                            'check, answer), not "%s"' % w.type)
            for l in w.lines:
                if allowed is not None and l.kw not in allowed:
                    self.err(w, 'keyword "%s" is not valid in a %s wire (valid: %s)'
                             % (l.kw, w.type, ', '.join(allowed)), l)
                if is_var(l.kw) or is_ref(l.kw):
                    self.err(w, 'a line must start with a keyword', l)
            for l in w.get('supersedes'):
                r = self.ref(w, l)
                if r:
                    self.inactive.add(r)
        self.active = [w for w in self.order if w.name not in self.inactive and w.type in KEYWORDS]
        self.base, self.fact_src, self.fact_triples = set(), {}, defaultdict(list)
        self.overriders = defaultdict(list)
        self.rules, self.constraints, self.methods = [], [], defaultdict(list)
        for w in self.active:
            if w.type == 'fact':
                self._fact(w)
            elif w.type in ('rule', 'constraint', 'find', 'group'):
                self.body[w.name] = self._body(w)
                if w.type == 'rule':
                    self.heads[w.name] = [p for p in (self.pat(w, l) for l in w.get('then')) if p]
                    if not self.heads[w.name]:
                        self.err(w, 'rule has no "then" line')
                    for p in self.heads[w.name]:
                        if is_var(p[1]):
                            self.err(w, 'the relation of a "then" statement cannot be a variable')
                    self.rules.append(w)
                elif w.type == 'constraint':
                    self.constraints.append(w)
            elif w.type == 'method':
                self._method(w)
            if w.type in ('fact', 'rule'):
                for l in w.get('overrides'):
                    r = self.ref(w, l, ('rule',))
                    if r:
                        self.overriders[r].append(w.name)
        self._lint()
        self.strata = []
        if not self.errors:
            self._stratify()
        self.base_world = World(self, self.base)

    def _fact(self, w):
        subj = None
        for l in w.lines:
            if l.kw in META or l.kw in ('overrides', 'supersedes'):
                continue
            if l.kw == 'about':
                if len(l.args) != 1:
                    self.err(w, '"about" expects one subject term', l)
                else:
                    subj = l.args[0]
                continue
            if l.kw == 'say':
                t = self.pat(w, l)
            else:
                if subj is None:
                    self.err(w, 'relation line before "about <subject>" (or use "say S R O")', l)
                    continue
                if len(l.args) != 1:
                    self.err(w, 'a fact line is "relation value" with ONE value term; quote multi-word '
                                'values or use several lines', l)
                    continue
                t = (subj, l.kw, l.args[0])
            if t:
                if any(is_var(x) for x in t):
                    self.err(w, 'variables are not allowed in facts (use a rule)', l)
                    continue
                self.base.add(t)
                self.fact_src.setdefault(t, w.name)
                self.fact_triples[w.name].append(t)

    def _body(self, w):
        body = []
        for l in w.lines:
            if l.kw in POS or l.kw in NEG:
                p = self.pat(w, l)
                if p:
                    body.append(('pos' if l.kw in POS else 'neg', p))
            elif l.kw == 'from':
                r = self.ref(w, l, ('find', 'group', 'plan', 'check'))
                if r:
                    body.append(('from', r))
            elif l.kw == 'let':
                toks = self.expr(w, l)
                if len(toks) < 3 or not is_var(toks[0]) or toks[1] != '=':
                    self.err(w, 'let syntax: let ?var = expression', l)
                else:
                    body.append(('let', toks[0], toks[2:]))
            elif l.kw == 'test':
                body.append(('test', self.expr(w, l)))
        return body

    def _method(self, w):
        t = w.one('task')
        if not t or not t.args or is_var(t.args[0]):
            self.err(w, 'method needs "task <name> ?params..."')
            return
        seq = []
        for l in w.lines:
            k = l.kw
            if k in ('require', 'forbid'):
                msg = l.args[3] if len(l.args) == 4 and isinstance(l.args[3], Q) else None
                p = self.pat(w, l, l.args[:3] if msg is not None else None)
                if p:
                    seq.append((k, p, msg))
            elif k == 'require-test':
                toks = self.expr(w, l)
                msg = toks.pop() if toks and isinstance(toks[-1], Q) else None
                seq.append((k, toks, msg))
            elif k == 'step':
                seq.append((k, l.args))
            elif k == 'do':
                if not l.args:
                    self.err(w, 'do <task> args...', l)
                else:
                    seq.append((k, l.args[0], l.args[1:]))
            elif k == 'forall':
                if len(l.args) < 5 or l.args[3] != 'do':
                    self.err(w, 'forall syntax: forall S R O do <task> args...', l)
                else:
                    seq.append((k, tuple(l.args[:3]), l.args[4], l.args[5:]))
            elif k in ('add', 'remove', 'set'):
                p = self.pat(w, l)
                if p:
                    seq.append((k, p))
        self.meth[w.name] = dict(task=t.args[0], params=t.args[1:], app=self._body(w), seq=seq, wire=w)
        self.methods[t.args[0]].append(w.name)

    # ------------------------------------------------------------ lint
    def _body_vars(self, body):
        bound = set()
        for it in body:
            if it[0] == 'pos':
                bound |= {x for x in it[1] if is_var(x)}
            elif it[0] == 'from':
                bound |= self._out_vars(it[1])
            elif it[0] == 'let':
                bound.add(it[1])
        return bound

    def _out_vars(self, name, seen=()):
        w = self.wires[name]
        if name in seen:
            return set()
        if w.type == 'find':
            r = w.one('return')
            if r:
                return {x for x in r.args if is_var(x)}
            return self._body_vars(self.body.get(name, []))
        if w.type == 'group':
            vs = set()
            for l in w.get('by'):
                vs |= {x for x in l.args if is_var(x)}
            for l in w.get(*AGGS):
                if l.args and is_var(l.args[-1]):
                    vs.add(l.args[-1])
            return vs
        if w.type == 'plan':
            return {'?n', '?step', '?status', '?reason'}
        return {'?constraint', '?message'} | {v for c in self.constraints for v in self._body_vars(self.body[c.name])}

    def _lint(self):
        rels, atoms = set(), set()

        def learn(t):
            if not is_var(t[1]):
                rels.add(t[1])
            for x in (t[0], t[2]):
                if type(x) is str and not is_var(x):
                    atoms.add(x)
        for t in self.base:
            learn(t)
        for w in self.rules:
            for h in self.heads.get(w.name, []):
                learn(h)
        for m in self.meth.values():
            for it in m['seq']:
                if it[0] in ('add', 'set'):
                    learn(it[1])
        for w in self.active:
            if w.type in ('assume',):
                for l in w.get('add', 'set'):
                    if len(l.args) == 3:
                        learn(tuple(l.args))
        self.known_rels, self.known_atoms = rels, atoms

        def check_pat(w, p, what):
            if not is_var(p[1]) and p[1] not in rels:
                self.warn(w, 'relation "%s" (%s) is never asserted or derived anywhere - typo or '
                             'vocabulary drift?' % (p[1], what))
            for x in (p[0], p[2]):
                if type(x) is str and not is_var(x) and x not in atoms:
                    self.warn(w, 'constant "%s" (%s) never appears in any fact or rule conclusion'
                              % (x, what))

        for w in self.active:
            body = self.body.get(w.name)
            if w.type == 'method' and w.name in self.meth:
                m = self.meth[w.name]
                body = m['app']
                bound = self._body_vars(body) | {x for x in m['params'] if is_var(x)}
                for it in m['seq']:
                    if it[0] in ('require', 'forbid'):
                        check_pat(w, it[1], it[0])
                        if it[0] == 'require':
                            bound |= {x for x in it[1] if is_var(x)}
                    elif it[0] == 'do' and it[1] not in self.methods:
                        self.warn(w, 'task "%s" has no method; it will be emitted as a primitive step' % it[1])
                    elif it[0] == 'forall':
                        check_pat(w, it[1], 'forall')
                        if it[2] not in self.methods:
                            self.warn(w, 'task "%s" has no method; it will be emitted as a primitive step' % it[2])
                    elif it[0] in ('add', 'set'):
                        for x in it[1]:
                            if is_var(x) and x not in bound:
                                self.err(w, 'variable %s in "%s" is not bound' % (x, it[0]))
                    elif it[0] == 'step':
                        for x in it[1]:
                            if is_var(x) and x not in bound:
                                self.err(w, 'variable %s in "step" is not bound by task params/when/require' % x)
            if body is None:
                continue
            bound = self._body_vars(body)
            if w.type == 'method':
                bound |= {x for x in self.meth[w.name]['params'] if is_var(x)}
            for it in body:
                if it[0] in ('pos', 'neg'):
                    check_pat(w, it[1], 'condition')
                    if w.type in ('rule', 'constraint') and is_var(it[1][1]):
                        self.err(w, 'a variable in relation position is only allowed in query wires')
                elif it[0] in ('let', 'test'):
                    toks = it[2] if it[0] == 'let' else it[1]
                    for x in toks:
                        if is_var(x) and x not in bound:
                            self.err(w, 'variable %s used in %s is not bound by a positive condition' % (x, it[0]))
                        if type(x) is str and not isinstance(x, Q) and not is_var(x) and x not in OPS \
                                and x not in atoms and not NUM.match(x):
                            self.warn(w, 'token "%s" in expression is not a known constant - operators '
                                         'must be separated by spaces' % x)
            if w.type == 'rule':
                for h in self.heads.get(w.name, []):
                    for x in h:
                        if is_var(x) and x not in bound:
                            self.err(w, 'variable %s in "then" is not bound by a positive condition' % x)
            if w.type in ('find', 'group') and w.origin != 'query' and w.one('in'):
                self.err(w, 'a view stored in the knowledge base cannot have an "in" line')
            if w.type == 'find':
                r = w.one('return')
                if r:
                    for x in r.args:
                        if not is_var(x) or x not in bound:
                            self.err(w, 'return: %s is not a bound variable' % fmt(x), r)
            if w.type == 'group':
                for l in w.get(*AGGS):
                    a = l.args
                    if not (len(a) == 3 and is_var(a[0]) and a[1] == 'as' and is_var(a[2])):
                        self.err(w, 'aggregate syntax: %s ?var as ?result' % l.kw, l)
                    elif a[0] not in bound:
                        self.err(w, 'aggregate variable %s is not bound' % a[0], l)
                for l in w.get('by'):
                    for x in l.args:
                        if x not in bound:
                            self.err(w, 'by: %s is not a bound variable' % fmt(x), l)
        for w in self.active:
            if w.type in ('assume', 'plan', 'check', 'find', 'group'):
                for l in w.get('in'):
                    self.ref(w, l, ('assume', 'plan'))
            if w.type == 'plan':
                t = w.one('task')
                if not t or not t.args:
                    self.err(w, 'plan needs "task <name> args..."')
                elif t.args[0] not in self.methods:
                    self.warn(w, 'no method defines task "%s" (known tasks: %s)'
                              % (t.args[0], ', '.join(sorted(self.methods)) or 'none'))
            if w.type == 'answer':
                f = w.one('from')
                if not f:
                    self.err(w, 'answer needs "from $wire"')
                else:
                    self.ref(w, f, ('find', 'group', 'plan', 'check'))

    # ------------------------------------------------------------ stratification
    def _view_rels(self, name, seen=()):
        rels = set()
        if name in seen:
            return rels
        for it in self.body.get(name, []):
            if it[0] in ('pos', 'neg'):
                rels.add(it[1][1])
            elif it[0] == 'from':
                rels |= self._view_rels(it[1], seen + (name,))
        return rels

    def _deps(self, name):
        pos, neg = set(), set()
        for it in self.body[name]:
            if it[0] == 'pos':
                pos.add(it[1][1])
            elif it[0] == 'neg':
                neg.add(it[1][1])
            elif it[0] == 'from':
                neg |= self._view_rels(it[1])
        for o in self.overriders.get(name, []):
            if self.wires[o].type == 'rule' and o not in self.inactive:
                p2, n2 = self._deps(o)
                neg |= p2 | n2
        return pos, neg

    def _stratify(self):
        strat = defaultdict(int)
        deps = {w.name: self._deps(w.name) for w in self.rules}
        limit = len(self.known_rels) + len(self.rules) + 5
        for _ in range(limit):
            changed = False
            for w in self.rules:
                pos, neg = deps[w.name]
                hs = [h[1] for h in self.heads[w.name]]
                m = max([strat[p] for p in pos] + [strat[n] + 1 for n in neg] + [strat[h] for h in hs] + [0])
                for h in hs:
                    if strat[h] != m:
                        strat[h] = m
                        changed = True
            if not changed:
                break
        else:
            self.errors.append('rules are not stratifiable: some relation depends on its own negation / '
                               'aggregation / override (check "unless", "from", "overrides" cycles)')
            return
        by = defaultdict(list)
        for w in self.rules:
            by[max([strat[h[1]] for h in self.heads[w.name]] + [0])].append(w.name)
        self.strata = [by[k] for k in sorted(by)]

    # ------------------------------------------------------------ core evaluation
    def match(self, store, pat, env):
        r = env.get(pat[1], pat[1]) if is_var(pat[1]) else pat[1]
        cands = store.all() if is_var(r) else store.by_rel.get(r, ())
        for t in list(cands):
            e, ok = None, True
            for p, v in zip(pat, t):
                if is_var(p):
                    cur = (e or env).get(p)
                    if cur is None:
                        if e is None:
                            e = dict(env)
                        e[p] = v
                    elif cur != v:
                        ok = False
                        break
                elif p != v:
                    ok = False
                    break
            if ok:
                yield t, (e if e is not None else env)

    def evalx(self, toks, env):
        parts, loc = [], {}
        for i, t in enumerate(toks):
            if type(t) is str and t in OPS:
                parts.append('==' if t == '=' else t)
                continue
            if is_var(t):
                if t not in env:
                    return None
                t = env[t]
            loc['_%d' % i] = t
            parts.append('_%d' % i)
        try:
            return norm(eval(' '.join(parts), {'__builtins__': {}}, loc))
        except Exception:
            return None

    def solve(self, body, store, env0=None):
        envs = [(dict(env0 or {}), ())]
        for it in body:
            if it[0] == 'pos':
                envs = [(e2, sup + (t,)) for e, sup in envs for t, e2 in self.match(store, it[1], e)]
            elif it[0] == 'from':
                rows, new = self.rows(it[1], store), []
                for e, sup in envs:
                    for row in rows:
                        if all(e.get(k, v) == v for k, v in row.items()):
                            e2 = dict(e)
                            e2.update(row)
                            new.append((e2, sup))
                envs = new
        for it in body:
            if it[0] == 'let':
                new = []
                for e, sup in envs:
                    v = self.evalx(it[2], e)
                    if v is None:
                        continue
                    if it[1] in e:
                        if e[it[1]] == v:
                            new.append((e, sup))
                    else:
                        e2 = dict(e)
                        e2[it[1]] = v
                        new.append((e2, sup))
                envs = new
            elif it[0] == 'test':
                envs = [(e, sup) for e, sup in envs if self.evalx(it[1], e) is True]
            elif it[0] == 'neg':
                envs = [(e, sup) for e, sup in envs if next(self.match(store, it[1], e), None) is None]
        seen, out = set(), []
        for e, sup in envs:
            k = frozenset(e.items())
            if k not in seen:
                seen.add(k)
                out.append((e, sup))
        out.sort(key=lambda x: sorted((k, str(v)) for k, v in x[0].items()))
        return out

    def derive(self, name, store, depth=0):
        """All (head triple, support) a rule yields on `store`, after suppression by its overriders."""
        if depth > 20:
            raise SopError('override chain too deep / cyclic at @%s' % name)
        blocked = set()
        for o in self.overriders.get(name, []):
            if o in self.inactive:
                continue
            if self.wires[o].type == 'fact':
                blocked |= {(t[0], t[1]) for t in self.fact_triples[o] if t in store}
            else:
                blocked |= {(t[0], t[1]) for t, _ in self.derive(o, store, depth + 1)}
        out = []
        for env, sup in self.solve(self.body[name], store):
            for h in self.heads[name]:
                t = tuple(env.get(x, x) if is_var(x) else x for x in h)
                if (t[0], t[1]) not in blocked:
                    out.append((t, sup))
        return out

    def saturate(self, base, assumed=()):
        st = Store()
        for t in base:
            st.add(t, ('assumed', ()) if t in assumed and t not in self.fact_src
                   else ('fact @%s' % self.fact_src.get(t, '?'), ()))
        for stratum in self.strata:
            changed, rounds = True, 0
            while changed:
                changed = False
                rounds += 1
                if rounds > 10000:
                    raise SopError('fixpoint did not converge (unbounded arithmetic recursion?)')
                for name in stratum:
                    for t, sup in self.derive(name, st):
                        if st.add(t, ('rule @%s' % name, sup)):
                            changed = True
        return st

    # ------------------------------------------------------------ relational wires
    def world_of(self, w, default=None):
        l = w.one('in')
        if not l:
            return default or self.base_world
        return self.result(l.args[0][1:])['world']

    def rows(self, name, store):
        w = self.wires[name]
        if w.type in ('plan', 'check'):
            return self.result(name)['rows']
        if w.one('in'):
            store = self.world_of(w).store()
        envs = [e for e, _ in self.solve(self.body[name], store)]
        if w.type == 'find':
            r = w.one('return')
            if r:
                seen, out = set(), []
                for e in envs:
                    row = {v: e[v] for v in r.args if v in e}
                    k = frozenset(row.items())
                    if k not in seen:
                        seen.add(k)
                        out.append(row)
                return out
            return envs
        by = [v for l in w.get('by') for v in l.args]
        groups = defaultdict(list)
        for e in envs:
            groups[tuple(e.get(v) for v in by)].append(e)
        if not by and not envs:
            groups[()] = []
        out = []
        for key, es in groups.items():
            row = dict(zip(by, key))
            for l in w.get(*AGGS):
                vals = [e[l.args[0]] for e in es if l.args[0] in e]
                nums = [v for v in vals if isinstance(v, (int, float))]
                if l.kw == 'count':
                    v = len(set(vals))
                elif l.kw == 'sum':
                    v = sum(nums)
                elif not nums:
                    continue
                elif l.kw == 'min':
                    v = min(nums)
                elif l.kw == 'max':
                    v = max(nums)
                else:
                    v = sum(nums) / len(nums)
                row[l.args[2]] = norm(v)
            out.append(row)
        return out

    # ------------------------------------------------------------ worlds, plans, checks
    def result(self, name):
        if name in self.results:
            return self.results[name]
        w = self.wires[name]
        if w.type == 'assume':
            world = self.world_of(w).copy()
            for l in w.lines:
                if l.kw in ('add', 'remove', 'set'):
                    self.apply(world, l.kw, tuple(l.args), {})
            res = dict(kind='assume', world=world, rows=[])
        elif w.type == 'plan':
            world = self.world_of(w).copy()
            t = w.one('task')
            ok, steps, reason = self.exec_task(t.args[0], list(t.args[1:]), world, 0)
            title = ' '.join(fmt(a) for a in t.args)
            if ok:
                rows = [{'?n': i, '?step': Q(s)} for i, s in enumerate(steps, 1)]
            else:
                rows = [{'?status': 'blocked', '?reason': Q(reason)}]
            res = dict(kind='plan', world=world, rows=rows, ok=ok, reason=reason, title=title)
        elif w.type == 'check':
            world = self.world_of(w)
            rows = []
            for c in self.constraints:
                m = c.one('message')
                for e, _ in self.solve(self.body[c.name], world.store()):
                    row = dict(e)
                    row['?constraint'] = c.name
                    if m and m.args:
                        row['?message'] = Q(' '.join(str(e.get(a, a)) if is_var(a) else str(a) for a in m.args))
                    rows.append(row)
            res = dict(kind='check', world=world, rows=rows)
        elif w.type in ('find', 'group'):
            world = self.world_of(w)
            res = dict(kind=w.type, world=world, rows=self.rows(name, world.store()))
        else:
            raise SopError('@%s (%s) cannot be evaluated as a query wire' % (name, w.type))
        self.results[name] = res
        return res

    def apply(self, world, kind, pat, env):
        t = tuple(env.get(x, x) if is_var(x) else x for x in pat)
        if kind == 'remove':
            world.remove(t)
            return
        if any(is_var(x) for x in t):
            raise SopError('"%s %s": unbound variable' % (kind, fmt_t(t)))
        if kind == 'set':
            world.remove((t[0], t[1], '?_'))
        world.add(t)

    def exec_task(self, task, args, world, depth):
        if depth > 40:
            return False, [], 'recursion limit reached in task "%s"' % task
        names = self.methods.get(task)
        if not names:
            return True, [' '.join(str(a) for a in [task] + args)], None
        hard, soft = [], []
        call = '%s %s' % (task, ' '.join(str(a) for a in args))
        for name in names:
            m = self.meth[name]
            if len(m['params']) != len(args):
                continue
            env, ok = {}, True
            for p, a in zip(m['params'], args):
                if is_var(p):
                    if env.get(p, a) != a:
                        ok = False
                    env[p] = a
                elif p != a:
                    ok = False
            if not ok:
                continue
            envs = self.solve(m['app'], world.store(), env)
            if not envs:
                soft.append('@%s: its when/unless conditions do not hold for "%s"' % (name, call))
                continue
            for e, _ in envs:
                w2, steps = world.copy(), []
                reason = self.run_seq(m, dict(e), w2, steps, depth)
                if reason is None:
                    world.take(w2)
                    return True, steps, None
                hard.append(reason)
        if hard:
            return False, [], hard[0]
        if soft:
            return False, [], 'no applicable method for "%s" (%s)' % (call, '; '.join(soft))
        return False, [], 'no method for "%s" with %d argument(s)' % (task, len(args))

    def run_seq(self, m, env, world, steps, depth):
        name = m['wire'].name

        def sub(xs):
            return [env.get(x, x) if is_var(x) else x for x in xs]
        for it in m['seq']:
            k = it[0]
            if k in ('require', 'forbid'):
                hit = next(iter(sorted(self.match(world.store(), it[1], env),
                                       key=lambda x: fmt_t(x[0]))), None)
                shown = fmt_t(sub(it[1]))
                if k == 'require':
                    if hit is None:
                        return it[2] or 'requirement not met: %s (@%s)' % (shown, name)
                    env.update(hit[1])
                elif hit is not None:
                    return it[2] or 'forbidden condition holds: %s (@%s)' % (fmt_t(hit[0]), name)
            elif k == 'require-test':
                if self.evalx(it[1], env) is not True:
                    return it[2] or 'test failed: %s (@%s)' % (' '.join(str(x) for x in sub(it[1])), name)
            elif k == 'step':
                steps.append(' '.join(str(x) for x in sub(it[1])))
            elif k == 'do':
                ok, st, reason = self.exec_task(it[1], sub(it[2]), world, depth + 1)
                if not ok:
                    return reason
                steps.extend(st)
            elif k == 'forall':
                hits = sorted(self.match(world.store(), it[1], env), key=lambda x: fmt_t(x[0]))
                for _, e2 in hits:
                    args = [e2.get(x, x) if is_var(x) else x for x in it[3]]
                    ok, st, reason = self.exec_task(it[2], args, world, depth + 1)
                    if not ok:
                        return reason
                    steps.extend(st)
            else:
                self.apply(world, k, it[1], env)
        return None

    # ------------------------------------------------------------ output
    def render(self, name):
        w = self.wires[name]
        out = []
        src = w.one('from').args[0][1:] if w.type == 'answer' else name
        res = self.result(src)
        label = w.one('text') if w.type == 'answer' else None
        out.append('== %s%s ==' % (name, ' : ' + ' '.join(str(a) for a in label.args) if label else ''))
        if res['kind'] == 'plan':
            if res['ok']:
                out.append('PLAN %s: OK (%d steps)' % (res['title'], len(res['rows'])))
                out += ['  %d. %s' % (r['?n'], r['?step']) for r in res['rows']]
            else:
                out.append('PLAN %s: BLOCKED - %s' % (res['title'], res['reason']))
            return '\n'.join(out)
        rows = res['rows']
        show = w.one('show') if w.type == 'answer' else None
        if show:
            seen, proj = set(), []
            for r in rows:
                row = {v: r[v] for v in show.args if v in r}
                k = frozenset(row.items())
                if k not in seen:
                    seen.add(k)
                    proj.append(row)
            rows = proj
        lines = sorted(' | '.join('%s=%s' % (k, fmt(v)) for k, v in sorted(r.items())) for r in rows)
        out += ['  ' + l for l in lines]
        out.append('(%d row%s)' % (len(rows), '' if len(rows) == 1 else 's'))
        return '\n'.join(out)

    def explain(self, store, t, depth=0, seen=None, out=None):
        seen = set() if seen is None else seen
        out = [] if out is None else out
        why = store.why.get(t)
        out.append('%s%s   [%s]' % ('  ' * depth, fmt_t(t), why[0] if why else 'NOT DERIVED'))
        if why and t not in seen:
            seen.add(t)
            for s in why[1]:
                self.explain(store, s, depth + 1, seen, out)
        return out

    def vocab(self):
        st = self.base_world.store()
        out = ['# relations (base facts / total incl. derived)']
        base_n = defaultdict(int)
        for t in self.base:
            base_n[t[1]] += 1
        derived_by = defaultdict(set)
        for w in self.rules:
            for h in self.heads[w.name]:
                derived_by[h[1]].add(w.name)
        for r in sorted(set(st.by_rel) | set(derived_by)):
            objs = sorted({fmt(t[2]) for t in st.by_rel.get(r, ())})
            sample = ', '.join(objs[:8]) + (' ...' if len(objs) > 8 else '')
            d = (' derived-by ' + ','.join('@' + x for x in sorted(derived_by[r]))) if r in derived_by else ''
            out.append('  %-28s %3d / %3d%s   values: %s' % (r, base_n[r], len(st.by_rel.get(r, ())), d, sample))
        out.append('# tasks (methods)')
        for task in sorted(self.methods):
            for n in self.methods[task]:
                out.append('  %s %s   (@%s)' % (task, ' '.join(self.meth[n]['params']), n))
        out.append('# constraints')
        for c in self.constraints:
            out.append('  @%s' % c.name)
        return '\n'.join(out)


def main(argv):
    if len(argv) < 2 or argv[0] not in ('lint', 'vocab', 'run', 'why'):
        print(__doc__)
        return 2
    cmd, rest = argv[0], argv[1:]
    files, q, t = [], None, None
    i = 0
    while i < len(rest):
        if rest[i] == '-q':
            q = rest[i + 1]
            i += 2
        elif rest[i] == '-t':
            t = rest[i + 1]
            i += 2
        else:
            files.append(rest[i])
            i += 1
    try:
        sources = [(f.split('/')[-1], open(f, encoding='utf-8').read()) for f in files]
        if q:
            sources.append(('query', open(q, encoding='utf-8').read()))
        eng = Engine(sources)
    except SopError as e:
        print('ERROR', e)
        return 1
    for x in eng.errors:
        print('ERROR  ', x)
    for x in eng.warnings:
        print('WARNING', x)
    if eng.errors:
        print('%d error(s) - nothing evaluated' % len(eng.errors))
        return 1
    try:
        if cmd == 'lint':
            st = eng.base_world.store()
            n = sum(len(s) for s in st.by_rel.values())
            print('OK: %d wires, %d base facts, %d facts after inference, %d rules in %d strata, '
                  '%d methods, %d constraints, %d warning(s)'
                  % (len(eng.active) - 2, len(eng.base), n, len(eng.rules) - 2, len(eng.strata),
                     len(eng.meth), len(eng.constraints), len(eng.warnings)))
        elif cmd == 'vocab':
            print(eng.vocab())
        elif cmd == 'why':
            toks = lex(t)
            print('\n'.join(eng.explain(eng.base_world.store(), tuple(toks))))
        else:
            names = [w.name for w in eng.order if w.origin == 'query' and w.type == 'answer']
            if not names:
                qs = [w.name for w in eng.order if w.origin == 'query']
                names = qs[-1:]
            for n in names:
                print(eng.render(n))
    except SopError as e:
        print('ERROR', e)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
