import sys, json
sys.path.insert(0, '/home/claude/sopr')
from sopr import Engine
G, RUNS = sys.argv[1], sys.argv[2]
gold = json.load(open(G + '/compound_gold.json'))
TANKS = {'t%d' % i for i in range(1, 9)}
TECHS = {'ilse', 'bram', 'noor', 'tomas'}
def norm(g):
    return dict(a=sorted(g['a']), b=g['b'], c=sorted(g['c']), d=sorted(tuple(x) for x in g['d']), e=sorted(g['e']), f=g['f'])
def from_engine(r, sid):
    d = '%s/%s/s4' % (RUNS, r)
    src = [(f, open('%s/%s' % (d, f)).read()) for f in ('kb1.sop', 'kb2.sop')]
    eng = Engine(src + [('query', open('%s/queries/%s.sop' % (d, sid.lower())).read())])
    assert not eng.errors, eng.errors
    def rows(n):
        w = eng.wires[n]
        res = eng.result(w.one('from').args[0][1:])
        return res
    vals = lambda res: [v for row in res['rows'] for v in row.values()]
    out = {}
    out['a'] = sorted({v for v in vals(rows('a')) if v in TANKS})
    nums = [v for v in vals(rows('b')) if isinstance(v, (int, float))]
    out['b'] = nums[0] if len(nums) == 1 else nums
    out['c'] = sorted({v for v in vals(rows('c')) if v in TANKS})
    out['d'] = sorted({(next(v for v in row.values() if v in TECHS), next(v for v in row.values() if v in TANKS))
                       for row in rows('d')['rows'] if any(v in TECHS for v in row.values())})
    out['e'] = sorted({v for v in vals(rows('e')) if v in TECHS})
    res = rows('f')
    out['f'] = 'yes' if res.get('ok') else 'no'
    return out
tot = {}
for name in ['b3', 'b4', 'r1', 'r2', 'r3']:
    ok, n, bad = 0, 0, []
    ans = json.load(open('%s/%s/answers.json' % (RUNS, name))) if name.startswith('b') else None
    for sid, g in gold.items():
        g = norm(g)
        got = norm(ans[sid]) if ans else from_engine(name, sid)
        for k in 'abcdef':
            n += 1
            if got[k] == g[k]: ok += 1
            else: bad.append((sid, k, 'gold', g[k], 'got', got[k]))
    print('%s: %d/%d' % (name, ok, n))
    for b in bad: print('   ', b)
