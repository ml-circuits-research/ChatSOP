#!/usr/bin/env python3
"""
Differential test: apply the same random compound "what-if" scenarios to several
independently compiled knowledge bases and compare every derived conclusion with a
reference KB. Each KB has its own vocabulary, so a small adapter maps canonical
changes / probes to that KB's relation names.

  difftest.py REF_DIR RUNS_DIR [N] [SEED]
"""
import sys
import random
import json
from collections import defaultdict
from sopr import Engine

TANKS = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']
FULL = ['t1', 't2', 't3', 't4', 't5', 't6', 't7']
TECHS = ['ilse', 'bram', 'noor', 'tomas']
ZONES = ['hatchery', 'grow-out-hall', 'quarantine-wing']
SPECIES = ['arctic-char', 'rainbow-trout', 'atlantic-salmon', 'siberian-sturgeon']
CERTS = ['hatchery', 'grow-out', 'medication']

COMMON = dict(
    temp='set {t} temp-c {v}', biomass='set {t} biomass-kg {v}', volume='set {t} volume-m3 {v}',
    resp=['remove ?x responsible-for {t}', 'add {w} responsible-for {t}'],
    maint='add {p} under-maintenance yes', move='set {t} located-in {z}',
    species='set {t} holds-species {s}', stage='set {t} life-stage {l}',
    backup_add='add {t} has backup-aeration', backup_rm='remove {t} has backup-aeration',
    probes=dict(overstocked=['?t overstocked yes'], thermal=['?t thermal-alarm yes'], stressed=['?t stressed yes'],
                test=['?t water-test-frequency ?v'], feed=['?t feedings-per-day ?v'], atrisk=['?t at-risk yes'],
                quarantine=['?t under-quarantine yes'], empty=['?t is-empty yes'], overloaded=['?t overloaded yes']),
    viol=('?p', '?t'))

ADAPTERS = {
    'ref': dict(
        temp='set {t} temp {v}', biomass='set {t} biomass {v}', volume='set {t} volume {v}',
        resp=['set {t} responsible {w}'], circuit='add {c} status down', maint='add {p} status under-maintenance',
        move='set {t} located-in {z}', species='set {t} holds {s}', stage='set {t} life-stage {l}',
        backup_add='add {t} has backup-aeration', backup_rm='remove {t} has backup-aeration',
        cert_add='add {w} certified {c}-cert', cert_rm='remove {w} certified {c}-cert',
        probes=dict(overstocked=['?t status overstocked'], thermal=['?t status thermal-alarm'],
                    stressed=['?t status stressed'], test=['?t water-test ?v'], feed=['?t feedings-per-day ?v'],
                    atrisk=['?t status at-risk'], quarantine=['?t status under-quarantine'],
                    empty=['?t status empty'], overloaded=['?t status overloaded'],
                    limit=['?t holds ?s', '?s density-limit ?v'], density=['?t density ?v']),
        constraint='c-cert', viol=('?who', '?t'), transfer='transfer', treat='treat'),
    'r1': dict(COMMON, temp='set {t} temperature-c {v}', circuit='add {c} circuit-down yes',
               backup_add='add {t} has-backup-aeration yes', backup_rm='remove {t} has-backup-aeration yes',
               cert_add='add {w} certified-for {c}-cert', cert_rm='remove {w} certified-for {c}-cert',
               probes=dict(COMMON['probes'], limit=['?t density-limit-kgm3 ?v'], density=['?t density-kgm3 ?v']),
               constraint='c-responsible-certified', transfer='transfer-fish', treat='treat-tank'),
    'r2': dict(COMMON, circuit='add {c} is-down yes',
               cert_add='add {w} certified-for {c}', cert_rm='remove {w} certified-for {c}',
               probes=dict(COMMON['probes'], limit=['?t holds-species ?s', '?s density-limit-kg-m3 ?v'], density=['?t density-kg-m3 ?v']),
               constraint='c-responsible-cert', transfer='transfer-fish', treat='treat-sick-tank'),
    'r3': dict(COMMON, circuit='add {c} power down',
               cert_add='add {w} certified {c}', cert_rm='remove {w} certified {c}',
               probes=dict(COMMON['probes'], limit=['?t is-a tank', '?t density-limit ?v'], density=['?t density ?v']),
               constraint='c-certification', transfer='transfer', treat='treat'),
}


def scenario(rng):
    """A list of canonical changes + plan probes."""
    n = rng.choice([1, 2, 2, 3, 3, 4])
    changes, used = [], set()
    while len(changes) < n:
        kind = rng.choice(['temp', 'temp', 'biomass', 'biomass', 'volume', 'resp', 'resp', 'circuit', 'maint',
                           'move', 'move', 'species', 'species', 'stage', 'backup_add', 'backup_rm',
                           'cert_add', 'cert_rm'])
        if kind in ('temp', 'biomass', 'species', 'stage'):
            t = rng.choice(FULL)
            a = dict(t=t, v=rng.choice([3, 5, 6, 9, 12, 13, 16, 17, 20]) if kind == 'temp'
                     else rng.choice([60, 150, 200, 250, 400, 500, 800, 1000, 1200, 1500, 2000]),
                     s=rng.choice(SPECIES), l=rng.choice(['fry', 'adult']))
            key = (kind, t)
        elif kind in ('volume', 'move', 'resp', 'backup_add'):
            t = rng.choice(TANKS)
            a = dict(t=t, v=rng.choice([5, 8, 10, 20, 40, 60, 100]), z=rng.choice(ZONES), w=rng.choice(TECHS))
            key = (kind, t)
        elif kind == 'backup_rm':
            a, key = dict(t='t5'), (kind, 't5')
            if ('backup_add', 't5') in used:
                continue
        elif kind == 'circuit':
            c = rng.choice(['circuit-a', 'circuit-b'])
            a, key = dict(c=c), (kind, c)
        elif kind == 'maint':
            p = rng.choice(['p1', 'p2', 'p3', 'p4'])
            a, key = dict(p=p), (kind, p)
        else:
            w, c = rng.choice(TECHS), rng.choice(CERTS)
            a, key = dict(w=w, c=c), ('cert', w, c)
        if key in used or (kind == 'backup_add' and ('backup_rm', 't5') in used and a['t'] == 't5'):
            continue
        used.add(key)
        changes.append((kind, a))
    transfers = [tuple(rng.sample(TANKS, 2)) for _ in range(3)]
    transfers[0] = (rng.choice(FULL), 't8')       # make sure some transfers have an empty destination
    treats = rng.sample(FULL, 2)
    return changes, transfers, treats


def build(ad, changes, transfers, treats):
    q = ['@w assume']
    for kind, a in changes:
        tpl = ad[kind]
        for line in (tpl if isinstance(tpl, list) else [tpl]):
            q.append('  ' + line.format(**a))
    for name, pats in ad['probes'].items():
        q.append('@pr-%s find\n  in $w' % name)
        q += ['  match ' + p for p in pats]
    q.append('@viol check\n  in $w')
    for i, (a, b) in enumerate(transfers):
        q.append('@tr%d plan\n  in $w\n  task %s %s %s' % (i, ad['transfer'], a, b))
        q.append('@tr%d-empty find\n  in $tr%d\n  match %s' % (i, i, ad['probes']['empty'][0]))
        q.append('@tr%d-dens find\n  in $tr%d\n  match %s' % (i, i, ad['probes']['density'][0].replace('?t', b)))
    for i, t in enumerate(treats):
        q.append('@tt%d plan\n  in $w\n  task %s %s' % (i, ad['treat'], t))
    return '\n'.join(q) + '\n'


def observe(kb_sources, ad, sc):
    changes, transfers, treats = sc
    eng = Engine(kb_sources + [('query', build(ad, changes, transfers, treats))])
    if eng.errors:
        raise RuntimeError(eng.errors[:3])
    obs = {}
    for name in ad['probes']:
        rows = eng.result('pr-' + name)['rows']
        if name in ('test', 'feed', 'limit', 'density'):
            obs[name] = sorted((r['?t'], str(r['?v'])) for r in rows)
        else:
            obs[name] = sorted(r['?t'] for r in rows)
    pv, tv = ad['viol']
    obs['violations'] = sorted({(r[pv], r[tv]) for r in eng.result('viol')['rows']
                                if r['?constraint'] == ad['constraint']})
    for i, (a, b) in enumerate(transfers):
        res = eng.result('tr%d' % i)
        key = 'transfer'
        if res['ok']:
            steps = ' '.join(str(r['?step']).lower() for r in res['rows'])
            val = ['OK', 'disinfect' if 'peroxide' in steps else 'no-disinfect',
                   sorted(r['?t'] for r in eng.result('tr%d-empty' % i)['rows']),
                   sorted(str(r['?v']) for r in eng.result('tr%d-dens' % i)['rows'])]
        else:
            val = ['BLOCKED']
        obs.setdefault(key, []).append(['%s->%s' % (a, b)] + val)
    for i, t in enumerate(treats):
        res = eng.result('tt%d' % i)
        if res['ok']:
            steps = ' '.join(str(r['?step']).lower() for r in res['rows'])
            val = ['OK', 'formalin' if 'formalin' in steps else 'salt' if 'salin' in steps or 'salt' in steps else '?',
                   len(res['rows'])]
        else:
            val = ['BLOCKED']
        obs.setdefault('treat', []).append([t] + val)
    return obs, eng


def main():
    ref_dir, runs_dir = sys.argv[1], sys.argv[2]
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 300
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 7
    rng = random.Random(seed)

    def src(d):
        return [(f, open('%s/%s' % (d, f)).read()) for f in ('kb1.sop', 'kb2.sop')]
    kbs = {'ref': src(ref_dir)}
    for r in ('r1', 'r2', 'r3'):
        kbs[r] = src('%s/%s/s3' % (runs_dir, r))
    agree, total = defaultdict(lambda: defaultdict(int)), defaultdict(int)
    diffs = []
    scen_ok = defaultdict(int)
    for k in range(n):
        sc = scenario(rng)
        ref, _ = observe(kbs['ref'], ADAPTERS['ref'], sc)
        for key, v in ref.items():
            items = v if key in ('transfer', 'treat') else [v]
            total[key] += len(items)
        for r in ('r1', 'r2', 'r3'):
            obs, _ = observe(kbs[r], ADAPTERS[r], sc)
            all_ok = True
            for key, v in ref.items():
                if key in ('transfer', 'treat'):
                    for a, b in zip(v, obs[key]):
                        if a == b:
                            agree[r][key] += 1
                        else:
                            all_ok = False
                            diffs.append(dict(kb=r, scenario=k, probe=key, changes=sc[0], ref=a, got=b))
                elif v == obs[key]:
                    agree[r][key] += 1
                else:
                    all_ok = False
                    diffs.append(dict(kb=r, scenario=k, probe=key, changes=sc[0], ref=v, got=obs[key]))
            scen_ok[r] += all_ok
    print('%d scenarios, seed %d' % (n, seed))
    print('%-12s %6s' % ('probe', 'total') + ''.join('%8s' % r for r in ('r1', 'r2', 'r3')))
    for key in total:
        print('%-12s %6d' % (key, total[key]) + ''.join('%8d' % agree[r][key] for r in ('r1', 'r2', 'r3')))
    tot = sum(total.values())
    print('%-12s %6d' % ('ALL', tot) + ''.join('%8d' % sum(agree[r].values()) for r in ('r1', 'r2', 'r3')))
    print('%-12s %6d' % ('scenarios', n) + ''.join('%8d' % scen_ok[r] for r in ('r1', 'r2', 'r3')))
    json.dump(diffs, open('difftest_diffs.json', 'w'), indent=1, default=str)
    print('%d disagreements written to difftest_diffs.json' % len(diffs))


if __name__ == '__main__':
    main()
