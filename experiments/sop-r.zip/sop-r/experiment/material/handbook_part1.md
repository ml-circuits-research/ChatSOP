# Kestrel Bay Aquaculture Station — Operations Handbook (Part 1)

## 1. Site layout
The station consists of two buildings: the Main Building and the Annex. The Main Building houses two zones, the Hatchery and the Grow-out Hall. The Annex houses a single zone, the Quarantine Wing.

## 2. Species
The station works with four species: Arctic char, rainbow trout, Atlantic salmon and Siberian sturgeon. The first three are salmonids; the Siberian sturgeon is a sturgeon. Salmonids and sturgeons are both cold-water fish.

## 3. Tanks
In the Hatchery, tank T1 (8 m³) holds Arctic char fry, 40 kg of biomass in total, and its water is currently at 13 °C. Tank T2, also 8 m³, holds Siberian sturgeon fry (55 kg, 12 °C).

In the Grow-out Hall, T3 (40 m³) holds adult rainbow trout: 1100 kg at 14 °C. T4 has the same volume as T3 and holds adult Arctic char, 1300 kg at 11 °C. T5 is larger, 60 m³, with 1500 kg of adult Atlantic salmon at 13 °C. The fourth tank of the hall, T8 (60 m³), is currently empty and has not been disinfected since its last use.

The Quarantine Wing has one tank, T6 (10 m³), holding 120 kg of adult Atlantic salmon at 12 °C. Any tank located in the Quarantine Wing is considered to be under quarantine.

## 4. Water supply
Each tank is supplied by one pump. Pump P1 supplies T1 and T2, P2 supplies T3 and T4, P3 supplies T5 and T8, and P4 supplies T6. P1 and P2 are wired to electrical circuit A; P3 and P4 are wired to circuit B. A pump is down when its circuit is down or when the pump itself is under maintenance. T5 is additionally equipped with a backup oxygen diffuser (backup aeration). A tank that holds fish is at risk whenever its pump is down, unless the tank has backup aeration.

## 5. Stocking density
The stocking density of a tank is its biomass divided by its volume (kg/m³). For cold-water fish the density limit is 25 kg/m³. Arctic char tolerate crowding better, so for them the limit is 35 kg/m³. A tank is overstocked when its density is strictly above the limit of the species it holds.

## 6. Temperature
Cold-water fish must be kept between 6 °C and 16 °C. For Arctic char the upper bound is 12 °C (the lower bound is unchanged). A tank whose temperature is outside the permitted range of the species it holds is in thermal alarm.

## 7. Stress and water testing
A tank is stressed if it is overstocked or in thermal alarm. Every tank that holds fish must be water-tested weekly; stressed tanks must be tested daily instead.

## 8. Feeding
Fry are fed six times a day and adults twice a day. Tanks under quarantine are fed only once a day, whatever the life stage of the fish.

## 9. Staff
Ilse is certified for hatchery work and for medication. Bram is certified for grow-out work. Noor is certified for both hatchery and grow-out work. Tomas is a trainee and holds no certification yet.

Responsibilities: Ilse is responsible for T1 and T6, Noor for T2 and T5, and Bram for T3, T4 and T8.

The technician responsible for a tank must hold the certification that matches the tank's zone: hatchery certification for tanks in the Hatchery, grow-out certification for tanks in the Grow-out Hall, and medication certification for tanks in the Quarantine Wing.

## 10. Procedures

### 10.1 Draining a tank
Close the tank's inlet valve, open its drain valve, and wait until the tank is dry.

### 10.2 Disinfecting a tank
Only an empty tank may be disinfected. Drain the tank (10.1), scrub the walls with peroxide solution, rinse the tank twice, and refill it with fresh water. The tank then counts as disinfected.

### 10.3 Water test
Take a water sample from the tank, measure ammonia and pH, and record the result in the tank log.

### 10.4 Transferring fish
Fish are transferred from a source tank to a destination tank under three conditions: the destination tank must be empty; fish may never be moved out of a tank that is under quarantine; and the transferred biomass divided by the destination's volume must not exceed the density limit of the species being moved.

Steps: if the destination tank is not disinfected, disinfect it first (10.2). Then stop feeding the source tank for 24 hours, bring the destination water to the source tank's temperature, net the fish and move them to the destination tank, and record the transfer in both tank logs.

Afterwards the destination tank holds the fish (same species, life stage and biomass) at the source tank's temperature, the source tank is empty, and the destination no longer counts as disinfected.

### 10.5 Treating a sick tank
If the tank holds fry, use a salt bath: raise the salinity to 10 g/L and hold it for 30 minutes. For any other life stage use formalin, which is permitted only if the technician responsible for the tank holds medication certification: stop feeding the tank, dose formalin, and aerate strongly for one hour. In both cases finish with a water test (10.3).
