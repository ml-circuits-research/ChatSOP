# Questions

All questions refer to the current state of the station, i.e. after all amendments.

- Q01. Which species is held in tank T4?
- Q02. Which tanks are located in the Main Building?
- Q03. Which tanks are supplied by pumps wired to circuit A?
- Q04. Which tanks hold salmonids?
- Q05. Which tanks hold cold-water fish that are not salmonids?
- Q06. What density limit applies to the fish in T3, in T4 and in T5?
- Q07. How many times per day are T1 and T6 fed?
- Q08. How often must T1 and T3 be water-tested?
- Q09. What is the stocking density of T4?
- Q10. Which tanks are overstocked?
- Q11. What is the total biomass held in the Grow-out Hall?
- Q12. How many feedings per day are given in total across all tanks of the station?
- Q13. Which technician is responsible for the largest total biomass, and how much is it?
- Q14. Which technicians are overloaded?
- Q15. Which tanks that hold fish have no backup aeration?
- Q16. Which technician–tank assignments currently violate the certification rule?
- Q17. If circuit B went down, which tanks would be at risk?
- Q18. If the temperature of T4 rose to 13 °C, which tanks would require daily water testing?
- Q19. If Bram took over responsibility for T6 from Ilse, which technician–tank assignments would violate the certification rule?
- Q20. What is the full sequence of steps for transferring the fish from T2 to T8?
- Q21. Can the fish in T6 be transferred to T8? If not, why not?
- Q22. Can the fish in T5 be transferred to T8? If not, why not?
- Q23. What is the full sequence of steps for treating T6?
- Q24. After the fish of T2 have been transferred to T8, what is the stocking density of T8, and which tanks are empty?
- Q25. What is the full sequence of steps for treating T1?
- Q26. Can T3 be treated according to the handbook? If not, why not?
