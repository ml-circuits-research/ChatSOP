# Kestrel Bay Aquaculture Station — Operations Handbook (Part 2: Amendments)

These amendments were issued after Part 1 and take precedence over it.

**A. New tank.** A new tank, T7 (10 m³), has been installed in the Quarantine Wing and is supplied by pump P4. It holds adult rainbow trout, 90 kg, at 10 °C. Tomas is responsible for T7.

**B. Harvest.** After a partial harvest, the biomass of T3 is now 950 kg.

**C. Salmon density.** For Atlantic salmon the density limit is lowered to 20 kg/m³; the general limit no longer applies to this species.

**D. Workload.** A technician who is responsible for more than two tanks is overloaded.
