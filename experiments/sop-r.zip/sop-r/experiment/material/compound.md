# Compound scenarios

Each scenario below describes a hypothetical state of the station. Start from the CURRENT state
(after all amendments) and apply ALL the listed statements of that scenario together; everything
not mentioned stays as it is. Scenarios are independent of each other.

For every scenario answer six questions:
- (a) Which tanks require daily water testing?
- (b) How many feedings per day are given in total across all tanks?
- (c) Which tanks are at risk?
- (d) Which technician-tank assignments violate the certification rule?
- (e) Which technicians are overloaded?
- (f) The transfer question stated in the scenario (yes or no).

## S01
- Tomas does not hold grow-out certification.
- The volume of T4 is 5 m³.
- Pump P3 is under maintenance.
- The volume of T2 is 100 m³.

Transfer question (f): can the fish in T2 be transferred to T8?

## S02
- T4 is located in the Quarantine Wing (no longer where it was; its pump, contents and technician are unchanged).
- The volume of T8 is 5 m³.
- The water temperature of T6 is 6 °C.

Transfer question (f): can the fish in T5 be transferred to T8?

## S03
- T1 is located in the Hatchery (no longer where it was; its pump, contents and technician are unchanged).
- Pump P3 is under maintenance.
- The water temperature of T7 is 9 °C.

Transfer question (f): can the fish in T2 be transferred to T8?

## S04
- Ilse is the technician responsible for T3 (replacing whoever was responsible before).
- The fish in T6 are fry.
- The water temperature of T3 is 16 °C.

Transfer question (f): can the fish in T5 be transferred to T8?

## S05
- Pump P3 is under maintenance.
- The fish held in T4 are Siberian sturgeon (life stage, biomass and temperature unchanged).
- T5 has no backup aeration.
- The volume of T2 is 100 m³.

Transfer question (f): can the fish in T6 be transferred to T8?

## S06
- T8 is equipped with backup aeration.
- T3 is located in the Hatchery (no longer where it was; its pump, contents and technician are unchanged).
- The biomass in T2 is 1200 kg.

Transfer question (f): can the fish in T7 be transferred to T8?

## S07
- The water temperature of T7 is 9 °C.
- T2 is located in the Quarantine Wing (no longer where it was; its pump, contents and technician are unchanged).
- Pump P2 is under maintenance.
- The water temperature of T3 is 3 °C.

Transfer question (f): can the fish in T7 be transferred to T8?

## S08
- Circuit B is down.
- The volume of T6 is 8 m³.
- The volume of T1 is 100 m³.

Transfer question (f): can the fish in T3 be transferred to T8?

## S09
- T5 is located in the Grow-out Hall (no longer where it was; its pump, contents and technician are unchanged).
- Circuit B is down.
- The biomass in T4 is 2000 kg.

Transfer question (f): can the fish in T4 be transferred to T8?

## S10
- Pump P4 is under maintenance.
- T7 is located in the Grow-out Hall (no longer where it was; its pump, contents and technician are unchanged).
- T3 is equipped with backup aeration.

Transfer question (f): can the fish in T2 be transferred to T8?

## S11
- T1 is located in the Grow-out Hall (no longer where it was; its pump, contents and technician are unchanged).
- Pump P4 is under maintenance.
- The water temperature of T3 is 6 °C.

Transfer question (f): can the fish in T3 be transferred to T8?

## S12
- T4 is located in the Grow-out Hall (no longer where it was; its pump, contents and technician are unchanged).
- T5 has no backup aeration.
- The fish in T1 are adults.

Transfer question (f): can the fish in T4 be transferred to T8?
