Q01: Arctic char
Q02: T1, T2, T3, T4, T5, T8
Q03: T1, T2, T3, T4
Q04: T1, T3, T4, T5, T6, T7
Q05: T2
Q06: T3 = 25 kg/m³; T4 = 35 kg/m³; T5 = 20 kg/m³
Q07: T1 = 6 times/day; T6 = 1 time/day
Q08: T1 daily (thermal alarm: Arctic char at 13 °C > 12 °C); T3 weekly (23.75 kg/m³ <= 25, 14 °C within 6-16)
Q09: 32.5 kg/m³ (1300/40)
Q10: T5 (1500/60 = 25 > 20)
Q11: 3750 kg (T3 950 + T4 1300 + T5 1500; T8 empty)
Q12: 20 (T1 6 + T2 6 + T3 2 + T4 2 + T5 2 + T6 1 + T7 1 + T8 0)
Q13: Bram, 2250 kg (T3 950 + T4 1300 + T8 0)
Q14: Bram (3 tanks: T3, T4, T8)
Q15: T1, T2, T3, T4, T6, T7
Q16: Tomas–T7 (quarantine tank needs medication certification; Tomas has none)
Q17: T6 and T7 (T5 has backup aeration; T8 is empty)
Q18: T1, T4, T5 (T4 in thermal alarm at 13 °C > 12 °C; T1 already thermal alarm; T5 overstocked)
Q19: Bram–T6 (no medication certification) and the existing Tomas–T7
Q20: 1) Disinfect T8 (not disinfected): close T8 inlet valve, open drain valve, wait until dry; scrub walls with peroxide solution; rinse twice; refill with fresh water. 2) Stop feeding T2 for 24 h. 3) Bring T8 water to 12 °C (T2's temperature). 4) Net the fish and move them to T8. 5) Record the transfer in both tank logs (T2 and T8).
Q21: No — T6 is in the Quarantine Wing (under quarantine); fish may never be moved out of a quarantined tank.
Q22: No — density would be 1500/60 = 25 kg/m³, above the Atlantic salmon limit of 20 kg/m³.
Q23: T6 (adult salmon, formalin; Ilse holds medication certification, so permitted): 1) stop feeding T6; 2) dose formalin; 3) aerate strongly for one hour; 4) water test: take water sample, measure ammonia and pH, record result in tank log.
Q24: T8 density = 55/60 ≈ 0.92 kg/m³; empty tank: T2 only
Q25: T1 (fry, salt bath): 1) raise salinity to 10 g/L; 2) hold for 30 minutes; 3) water test: take water sample, measure ammonia and pH, record result in tank log.
Q26: No — T3 holds adults, so formalin is required, which needs the responsible technician (Bram) to hold medication certification; he does not.
