Work ONLY inside the directory {DIR} (do not read anything outside it). It contains handbook_part1.md, handbook_part2.md (amendments that take precedence over Part 1) and compound.md (12 hypothetical scenarios, each with six questions a–f).

Read the handbook and answer every question of every scenario by reasoning directly from the text. Do NOT write or run any code or scripts and do not use any tool other than reading those three files and writing your answer file — this is a test of answering straight from the text. Work carefully: each scenario changes several things at once and every consequence of the handbook's rules counts.

Write your answers to {DIR}/answers.json as strict JSON of this exact shape (lower-case names, tanks as "t1".."t8", technicians as "ilse","bram","noor","tomas"):

{
 "S01": {"a": ["t1","t5"], "b": 20, "c": [], "d": [["tomas","t7"]], "e": ["bram"], "f": "yes"},
 "S02": { ... },
 ...
}

where a = list of tanks requiring daily water testing, b = total feedings per day (a number), c = list of tanks at risk, d = list of [technician, tank] pairs violating the certification rule, e = list of overloaded technicians, f = "yes" or "no". (The values shown above are only a format illustration.) Reply with the contents of answers.json.
