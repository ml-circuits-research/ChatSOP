You maintain a symbolic knowledge base written in a small declarative language called SOP-R. New text has arrived and must be added to the existing knowledge.

Work ONLY inside the directory {DIR} . Do not read or write anything outside that directory (no parent directories, no other folders). It contains:
- SPEC.md — the complete language specification. Read it fully and carefully first.
- sopr.py — the engine/linter (python3 sopr.py lint|vocab|run|why ...), usage is in SPEC.md §3.
- kb1.sop — the EXISTING knowledge base, compiled earlier by someone else from Part 1 of a handbook. You do not have the Part 1 text; kb1.sop is your only memory of it. Study it (and `python3 sopr.py vocab kb1.sop`) to learn its vocabulary and rules. You must NOT modify kb1.sop — the knowledge base is append-only.
- handbook_part2.md — the new text (amendments).

Deliverable: {DIR}/kb2.sop — new wires that integrate everything stated in handbook_part2.md into the existing knowledge, reusing the EXACT vocabulary (entity names, relation names, conventions) of kb1.sop. Use `supersedes` where a value or rule has changed and `overrides` where the new text introduces an exception to a rule that stays valid (see SPEC.md §1.6). Prefer data/rules that plug into the mechanisms already present in kb1.sop over parallel new mechanisms. General statements must be rules.

Requirements:
1. `python3 sopr.py lint kb1.sop kb2.sop` must report no errors; review every warning.
2. Verify with a few query files in a `scratch/` subfolder (run with `python3 sopr.py run kb1.sop kb2.sop -q scratch/x.sop`) that each amendment has the intended consequences throughout the knowledge base — not just the directly stated fact but also everything the existing rules derive from it — and that no stale value survives next to a new one.
3. Be faithful to the text: add nothing that is not stated.

When done, reply with a short report (max 200 words): the wires you added, how each amendment was integrated, and anything that was hard to express or that the existing KB made difficult.
