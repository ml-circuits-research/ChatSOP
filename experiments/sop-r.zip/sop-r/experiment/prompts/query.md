You translate natural-language questions into query circuits for a symbolic reasoning engine. The answers must be computed by the engine from a knowledge base — not by you.

Work ONLY inside the directory {DIR} . Do not read or write anything outside that directory (no parent directories, no other folders). It contains:
- SPEC.md — the complete specification of the SOP-R language. Read it fully first (especially §2 Query wires).
- sopr.py — the engine (python3 sopr.py lint|vocab|run|why ...), usage in SPEC.md §3.
- kb1.sop, kb2.sop — the knowledge base (always load both, in this order). It was compiled by someone else from a text you do not have. Study it and run `python3 sopr.py vocab kb1.sop kb2.sop` to learn its vocabulary (entity names, relation names, task names).
- questions.md — 26 questions (Q01..Q26).

Deliverable: one query file per question, {DIR}/queries/q01.sop ... q26.sop, each ending in one or more `answer` wires, such that
  python3 sopr.py run kb1.sop kb2.sop -q queries/qNN.sop
prints the answer to question NN.

Rules:
1. A query file may contain only query wires (find, group, assume, plan, check, answer). You must NOT modify kb1.sop / kb2.sop and must not add facts, rules, constraints or methods.
2. The engine must do the reasoning. Do not work the answer out yourself and encode it: no filtering on entity names that the question does not mention, no literal results. Mentioning the entities/values that appear in the question itself is of course fine. Wherever the knowledge base already derives a concept (a status, a limit, a frequency, a violation, a procedure), use that derived relation / constraint / task instead of re-implementing its logic in the query.
3. "What if" questions → `assume`; "steps for / can X be done / why not" questions → `plan` with the KB's tasks; rule-violation questions → `check`.
4. Run every query. Fix lint errors and warnings about unknown relations/constants (they mean you used a name the KB does not have). If the output looks wrong, first check whether your QUERY is wrong (wrong relation, wrong direction, missing join); do not tweak a query just to make the output match what you expect the answer to be.
5. If the knowledge base genuinely lacks what is needed for a question, still write the best query you can and mention it in your report.

When done, reply with: (a) for each question, one line `Qnn: <the engine's output summarised in a few words>`; (b) a list of any questions where you believe the KB is missing knowledge or where the language made the query awkward or impossible.
