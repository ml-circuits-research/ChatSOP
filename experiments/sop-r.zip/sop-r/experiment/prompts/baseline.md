Work ONLY inside the directory {DIR} (do not read anything outside it). It contains handbook_part1.md, handbook_part2.md (amendments that take precedence over Part 1) and questions.md.

Read both handbook parts and answer every question in questions.md by reasoning directly from the text. Do NOT write or run any code or scripts, and do not use any tool other than reading those three files and writing your answer file — this is a test of answering straight from the text.

Write your answers to {DIR}/answers.md, one entry per question in the form:

Q01: <answer>

Keep each answer short and precise: list the exact tank/technician names, numbers, or the ordered list of steps; for yes/no questions give yes/no plus the reason. No explanations beyond that. Then reply with just the contents of answers.md.
