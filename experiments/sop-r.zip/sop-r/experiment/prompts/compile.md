You are a knowledge compiler. Your job is to translate a natural-language handbook into a symbolic knowledge base written in a small declarative language called SOP-R, so that a symbolic engine can later answer questions WITHOUT access to the original text.

Work ONLY inside the directory {DIR} . Do not read or write anything outside that directory (no parent directories, no other folders). It contains:
- SPEC.md — the complete language specification. Read it fully and carefully first.
- sopr.py — the engine/linter (python3 sopr.py lint|vocab|run|why ...), usage is in SPEC.md §3.
- handbook_part1.md — the text to compile.

Deliverable: {DIR}/kb1.sop — a knowledge base that captures ALL the knowledge in handbook_part1.md: individual facts, class hierarchies, general rules (with their defaults and exceptions), computed quantities, constraints, and every procedure (with sub-procedures, preconditions and effects).

You do not know which questions will be asked later. They may be of any of these kinds: simple lookups; multi-step chains (location inside location, supply chains); class-based questions; defaults with exceptions; numeric computations and thresholds; totals/counts/maxima per group; "which ... have no ..."; hypothetical "what if X changed" scenarios (a later query will change a base fact and expect all consequences to follow from your rules); "what are the steps to do X", "is X allowed and if not why" (answered by planning with your methods); and checks for rule violations. Further handbook parts will be added later by someone who sees only your KB, not the Part 1 text — so general statements must be rules (not per-individual facts), and values that may change should be easy to replace.

Requirements:
1. `python3 sopr.py lint kb1.sop` must report no errors. Review every warning: fix those that reveal a naming inconsistency; a warning is acceptable only if the constant is legitimately absent from the current state.
2. Test your own KB: write a few small query files in a `scratch/` subfolder and run them to confirm that your rules and methods derive what the handbook says (including at least one hypothetical `assume` test and one `plan` test per procedure, including cases that must be blocked). Fix the KB until it behaves as the handbook describes.
3. Be faithful to the text: do not add knowledge that is not in the handbook, and do not leave out anything that is.
4. Follow the modelling guidelines in SPEC.md §4 and pay attention to the stratification restriction in §1.2.

When done, reply with a short report (max 300 words): number of wires by type, the main modelling decisions you made, and — importantly — anything in the handbook you found hard or impossible to express in SOP-R, or places where the spec was unclear.
