You translate natural-language hypothetical scenarios into query circuits for a symbolic reasoning engine. The answers must be computed by the engine from a knowledge base — not by you.

Work ONLY inside the directory {DIR} . Do not read or write anything outside that directory. It contains:
- SPEC.md — the complete specification of the SOP-R language. Read it fully first (especially §2 Query wires).
- sopr.py — the engine (python3 sopr.py lint|vocab|run|why ...), usage in SPEC.md §3.
- kb1.sop, kb2.sop — the knowledge base (always load both, in this order). It was compiled by someone else from a text you do not have. Study it and run `python3 sopr.py vocab kb1.sop kb2.sop` to learn its exact vocabulary (entity names, relation names and their direction, task names, how outages / maintenance / certifications / responsibilities are represented as base facts).
- compound.md — 12 hypothetical scenarios (S01..S12), each with six questions (a)–(f).

Deliverable: one query file per scenario, {DIR}/queries/s01.sop ... s12.sop. Each file must contain ONE `assume` wire that encodes all the statements of the scenario as changes to base facts, and exactly six `answer` wires named @a, @b, @c, @d, @e, @f that answer the six questions in that hypothetical world:
- @a from a find listing the tanks that require daily water testing
- @b from a group giving the total feedings per day (one row, one number)
- @c from a find listing the tanks at risk
- @d from a `check` wire (constraint violations)
- @e from a find listing the overloaded technicians
- @f from a `plan` wire for the transfer asked in the scenario (OK = yes, BLOCKED = no)

Rules:
1. A query file may contain only query wires (find, group, assume, plan, check, answer). Do not modify the knowledge base.
2. The engine must do the reasoning: encode only what the scenario states, as changes to BASE facts (use `set` to replace a value, `add`/`remove` otherwise; a statement about who is responsible or where a tank is located replaces the previous one). Never assert a derived conclusion yourself, and do not filter on entity names to shape the result.
3. Use the relations the knowledge base already derives (daily testing, feedings, at-risk, overloaded), its constraints and its tasks.
4. Run every file (`python3 sopr.py run kb1.sop kb2.sop -q queries/s01.sop`), fix lint errors and any warnings about unknown relations/constants in your queries. Do not tweak a query to make its output match what you expect.

When done, reply with one line per scenario summarising the engine output for a–f, plus any difficulty you met.
