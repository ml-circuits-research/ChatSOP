# Prompturile folosite în pilot

Toți agenții au fost Sonnet, fiecare într-un director izolat în care vedea doar fișierele enumerate.
`{DIR}` este directorul agentului. Textele sunt exact cele trimise (în engleză), cu directorul înlocuit.

| Etapă | Fișier | Vede | Nu vede |
|---|---|---|---|
| 1. Compilare | compile.md | SPEC.md, motorul, handbook_part1.md | întrebările, KB-ul de referință |
| 2. Actualizare | update.md | SPEC.md, motorul, kb1.sop, handbook_part2.md | textul Părții 1 (nu are voie să modifice kb1.sop) |
| 3. Interogare (26 de întrebări) | query.md | SPEC.md, motorul, kb1+kb2, questions.md | manualul |
| 3b. Interogare (scenarii compuse) | query-compound.md | SPEC.md, motorul, kb1+kb2, compound.md | manualul |
| Baseline | baseline.md, baseline-compound.md | manualul + întrebările | nu are voie să scrie cod |
