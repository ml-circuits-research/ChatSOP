#!/usr/bin/env node
// One benchmark run: compile a KB with one engine configuration, then answer the benchmark queries
// in sequence on the same engine (as a server would). Prints one JSON line.
//   node bench/run1.mjs DIR CONFIG
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { Engine } from '../src/engine.mjs';
import { QUERIES } from './gen.mjs';

export const CONFIGS = {
  naive: { seminaive: false, lazy: false, incremental: false, joinOrder: false },
  seminaive: { lazy: false, incremental: false, joinOrder: false },
  'seminaive+joinorder': { lazy: false, incremental: false },
  full: {},
  'full-noprov': { provenance: false },
  'full+lift': { lift: true, liftMin: 3 },
};

const [dir, cfg, only] = process.argv.slice(2);
const opts = CONFIGS[cfg];
const text = readFileSync(`${dir}/kb.sop`, 'utf8');
const gc = () => { if (global.gc) global.gc(); };
gc();
const h0 = process.memoryUsage().heapUsed;
let t = performance.now();
const eng = new Engine([['kb.sop', text]], opts);
if (eng.errors.length) { console.log(JSON.stringify({ cfg, error: eng.errors.slice(0, 3) })); process.exit(1); }
const res = { cfg, compileMs: Math.round(performance.now() - t), rules: eng.rules.length - 2, baseFacts: eng.baseKeys.size, queries: {} };
if (eng.liftReport) res.lift = eng.liftReport;
gc();
res.heapAfterLoadMB = Math.round((process.memoryUsage().heapUsed - h0) / 1048576);
const names = only ? only.split(',') : Object.keys(QUERIES);
for (const q of names) {
  t = performance.now();
  eng.query(QUERIES[q]);
  const out = eng.answers().map((n) => eng.render(n)).join('\n');
  const ms = performance.now() - t;
  res.queries[q] = { ms: Math.round(ms * 10) / 10, answer: out.split('\n').slice(1, -1).join(' ').trim(), sat: eng.baseWorld.sat ? eng.baseWorld.sat.size : 0 };
}
gc();
res.heapEndMB = Math.round((process.memoryUsage().heapUsed - h0) / 1048576);
res.baseWorldFacts = eng.baseWorld.sat ? eng.baseWorld.sat.size : 0;
res.stats = eng.stats;
console.log(JSON.stringify(res));
