#!/usr/bin/env node
// Benchmark driver: generate a synthetic KB of a given size and run every configuration in a fresh
// process (so memory is measured separately), with a time limit per configuration.
//   node bench/run.mjs N CLASSES ZONES [configs=naive,seminaive,...] [timeoutSec=600]
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync, existsSync, appendFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { generate, QUERIES } from './gen.mjs';

const [N, CL, Z, cfgs = 'naive,seminaive,seminaive+joinorder,full,full-noprov,full+lift', tmo = '600'] = process.argv.slice(2);
const dir = fileURLToPath(new URL(`./data/n${N}-c${CL}-z${Z}`, import.meta.url));
mkdirSync(dir, { recursive: true });
if (!existsSync(`${dir}/kb.sop`)) writeFileSync(`${dir}/kb.sop`, generate(+N, +CL, +Z, 1));
const results = fileURLToPath(new URL('./results.jsonl', import.meta.url));
for (const cfg of cfgs.split(',')) {
  const t = Date.now();
  const r = spawnSync('node', ['--expose-gc', '--max-old-space-size=6500', fileURLToPath(new URL('./run1.mjs', import.meta.url)), dir, cfg],
    { encoding: 'utf8', timeout: +tmo * 1000 });
  let line = (r.stdout || '').trim().split('\n').pop();
  if (!line || r.status !== 0) line = JSON.stringify({ cfg, failed: r.signal === 'SIGTERM' ? `timeout ${tmo}s` : (r.stderr || '').split('\n').filter(Boolean).slice(-2).join(' | ') });
  const rec = { N: +N, CL: +CL, Z: +Z, wallMs: Date.now() - t, ...JSON.parse(line) };
  appendFileSync(results, JSON.stringify(rec) + '\n');
  const q = rec.queries ? Object.entries(rec.queries).map(([k, v]) => `${k}=${v.ms}ms`).join(' ') : rec.failed || rec.error;
  console.log(`${cfg.padEnd(20)} compile=${rec.compileMs}ms heap=${rec.heapEndMB}MB facts=${rec.baseWorldFacts} ${q}`);
}
