# SOP-R: motor de reasoning simbolic pe SOP Lang — propunere și pilot

Este fezabil. Trei agenți Sonnet au compilat independent un manual de 980 de cuvinte în circuite, iar motorul a răspuns corect la 78 din 78 de întrebări și la 215 din 216 întrebări pe scenarii compuse.

Pilotul arată că lanțul funcționează cap-coadă, nu că bate un LLM: la această scară, Sonnet citind direct textul a răspuns corect la tot. Avantajul simbolic trebuie căutat acolo unde un LLM nu mai ajunge: KB-uri mai mari decât contextul, lumi ipotetice multe, răspunsuri auditabile. Pentru asta motorul a fost rescris în Node, cu indexare și evaluare incrementală (vezi `SCALARE.md`).

## 1. Ideea de bază

Un singur model de date și șase mecanisme ortogonale acoperă aproape tot ce numim reasoning simbolic. Modelul: fiecare fir este o relație, adică o mulțime de rânduri de legări de variabile, calculată într-o „lume” de afirmații `subiect relație obiect`. Firele de cunoaștere spun cum se închide o lume (ce se deduce din ce). Firele de interogare consumă relații și produc alte relații. Circuitul SSA este exact graful de dependențe dintre ele.

| Tip de reasoning | Mecanism în motor | Fir |
|---|---|---|
| Deducție, lanțuri multi-pas, tranzitivitate | unificare + punct fix | `rule` |
| Taxonomii și moștenire | `is-a` / `subclass-of` predefinite, restul reguli | `fact`, `rule` |
| Reguli implicite cu excepții (non-monoton) | negație stratificată + prioritate | `unless`, `overrides` |
| Cantitativ: calcule, praguri, totaluri, maxime | aritmetică + agregare | `let`, `test`, `group` |
| Ipotetic și contrafactual („ce-ar fi dacă”) | bifurcarea lumii și re-închiderea ei | `assume` |
| Procedural: pași, „e permis? de ce nu?” | descompunere de sarcini peste lumi | `method`, `plan` |
| Consistență și diagnostic | tipare interzise | `constraint`, `check` |
| Explicație | arborele de derivare al fiecărei afirmații | comanda `why` |

Patru tipuri rămân în afara motorului:

- **abducția** — se poate adăuga ca o căutare peste `assume`;
- **timpul** — se poate adăuga ca intervale de valabilitate pe fapte;
- **incertitudinea** — se poate adăuga ca ponderi pe derivări.

Acestea trei se adaugă fără a schimba modelul de date. A patra, **analogia**, cere un fir-oracol către LLM.

## 2. Tipurile de fire

Zece tipuri ajung: patru de cunoaștere, care se acumulează în KB, și șase de interogare. Sintaxa este cea din SOP Lang: `@nume tip`, apoi linii `cuvânt-cheie valoare`. Valoarea conține atomi, numere, șiruri, variabile `?x` sau referințe `$altFir`. Specificația completă este în `SPEC.md`, în engleză, pentru că e scrisă pentru LLM-ul compilator.

| Fir | Rol | Linii principale |
|---|---|---|
| `fact` | afirmații despre un subiect (cadru) sau libere | `about`, `<relație> <valoare>`, `say S R O` |
| `rule` | derivă afirmații noi; implicită sau excepție | `when`, `unless`, `let`, `test`, `from $view`, `then`, `overrides` |
| `constraint` | stare care nu trebuie să apară | `when`, `unless`, `message` |
| `method` | cum se face o sarcină; mai multe variante pe sarcină | `task`, `when`, `require`, `forbid`, `require-test`, `step`, `do`, `forall`, `add`, `remove`, `set` |
| `find` | interogare conjunctivă cu negație | `match`, `not`, `let`, `test`, `from`, `in $lume`, `return` |
| `group` | agregare | `by`, `count`, `sum`, `min`, `max`, `avg` |
| `assume` | lume ipotetică | `add`, `remove`, `set` |
| `plan` | expandează o sarcină în pași sau raportează blocajul | `task`, `in $lume` |
| `check` | listează încălcările constrângerilor | `in $lume` |
| `answer` | ce se afișează | `from`, `show`, `text` |

`find` și `group` pot sta și în KB, ca vederi reutilizabile: așa ajunge o regulă la un agregat. Orice fir de cunoaștere poate purta `supersedes $vechi` (înlocuire) sau `overrides $regulă` (excepție), deci KB-ul crește doar prin adăugare.

Exemplu scris de un agent Sonnet din manual, nemodificat:

```
@r-density-limit-default rule
  when ?t holds-species ?s
  when ?s subclass-of cold-water-fish
  when cold-water-fish max-density-kgm3 ?l
  then ?t density-limit-kgm3 ?l

@r-density-limit-species rule
  when ?t holds-species ?s
  when ?s max-density-kgm3 ?l
  then ?t density-limit-kgm3 ?l
  overrides $r-density-limit-default

@m-disinfect method
  task disinfect-tank ?t
  require ?t is-empty yes "only an empty tank may be disinfected"
  do drain-tank ?t
  step "Scrub the walls of" ?t "with peroxide solution"
  step "Rinse" ?t "twice"
  step "Refill" ?t "with fresh water"
  add ?t disinfected yes
```

Și o interogare ipotetică, tot scrisă de Sonnet, care a văzut doar KB-ul:

```
@w assume
  set t4 temperature-c 13
@q find
  in $w
  match ?t water-test-frequency daily
@a answer
  from $q
```

## 3. Cum „învață” din exemple

Învățarea este compilare verificată, nu antrenare. Bucla rulată în pilot și propusă mai departe:

1. LLM-ul citește specificația limbajului, vocabularul existent al KB-ului și un fragment de text, apoi scrie fire noi.
2. Linterul respinge variabilele nelegate și ciclurile prin negație și avertizează la relații sau constante care nu apar nicăieri. Acest avertisment prinde deriva de vocabular, principalul risc la scară.
3. LLM-ul își scrie propriile interogări de test din text, inclusiv cazuri care trebuie blocate, și repară KB-ul până trec.
4. Compilări independente ale aceluiași text se compară pe lumi perturbate aleator. Un dezacord localizează o eroare sau o ambiguitate a textului, fără răspunsuri de referință.

## 4. Pilotul

**Material.** Un manual fictiv, ca modelul să nu poată răspunde din memorie: o stație de acvacultură, 872 de cuvinte în Partea 1 și 110 în Partea 2 (amendamente). Conține taxonomie, reguli cu excepții, praguri numerice, cinci proceduri cu sub-proceduri și precondiții, și o regulă de certificare. Totul e în `experiment/material/`.

**Lanțul.** Fiecare etapă a fost un agent Sonnet separat, fără acces la ce nu trebuia să vadă. Prompturile exacte sunt în `experiment/prompts/`.

1. **Compilare.** Vede specificația și Partea 1, nu vede întrebările. Scrie `kb1.sop`.
2. **Actualizare.** Vede `kb1.sop` și Partea 2, nu vede textul Părții 1 și nu are voie să modifice `kb1.sop`. Scrie `kb2.sop`.
3. **Interogare.** Vede doar KB-ul și întrebările, nu vede manualul. Scrie câte un circuit pe întrebare.
4. **Notare.** Circuitele se rulează pe motor și se compară cu răspunsuri calculate independent.

Baseline: Sonnet cu tot textul în context, fără cod.

| Test | Ce măsoară | Simbolic (3 rulări) | Sonnet direct (2 rulări) |
|---|---|---|---|
| 26 de întrebări pe 10 tipuri de reasoning | lanțul complet | 78 / 78 | 52 / 52 |
| 12 scenarii compuse × 6 întrebări | 3–4 schimbări simultane, toate consecințele | 215 / 216 | 144 / 144 |
| 500 de lumi perturbate aleator × 17 sonde | echivalența KB-urilor cu referința | 25.500 / 25.500 | nerulat |

Cele trei KB-uri au 52–59 de fire și 22–25 de reguli fiecare. O compilare a durat circa 2 minute, o actualizare 30 de secunde, 26 de interogări 35 de secunde.

**Testul diferențial are dinți.** Am injectat trei erori în KB-urile Sonnet (`>` schimbat în `>=`, un `overrides` șters, un prag mutat de la 12 la 13) și toate au fost detectate.

**Singura greșeală** a fost la traducerea întrebării, nu la raționament. Un agent a scris `set ilse responsible-for t3` pe o relație orientată persoană → bazin. `set` a șters celelalte bazine ale lui Ilse și l-a lăsat pe Bram pe T3, fără niciun avertisment.

**Actualizarea a funcționat non-monoton.** După Partea 2, T3 nu mai este supraaglomerat (biomasa înlocuită), T5 devine supraaglomerat (limită nouă pentru somon), iar transferul T5 → T8, permis înainte, este blocat. Toate trei KB-urile au făcut asta corect.

## 5. Ce nu arată pilotul

Rezultatul este un plafon atins pe un test ușor, deci spune „se poate”, nu „cât de bine”.

- **Eu am scris și limbajul, și textul.** Manualul e curat, explicit și cade exact în zona pe care limbajul o exprimă. Un text real are ambiguitate, cunoștințe implicite și formulări vagi.
- **Scara e mică.** La 980 de cuvinte, LLM-ul direct răspunde perfect și mai ieftin.
- **Trei rulări** nu dau o estimare a variabilității.
- **Agentul de interogare a citit tot KB-ul.** La mii de fire va avea nevoie de căutare în vocabular, iar acolo pot apărea erori noi.

Problemele de limbaj găsite și reparările propuse pentru v0.2 sunt în `IMPLEMENTARE.md` §6.

## 6. Experimentul propus la scară

Întrebarea de testat: peste ce dimensiune și pentru ce tipuri de întrebări lanțul LLM → circuite → motor bate un LLM care citește textul. Pilotul a consumat circa 1,2 milioane de tokeni Sonnet în 16 rulări de agent, deci fazele de mai jos sunt ieftine.

| Fază | Ce se face | Metrici |
|---|---|---|
| E1. Text real, scară | 3 documente de 20–60 de mii de cuvinte (manual operațional, regulament, specificație tehnică), compilate pe fragmente cu vocabular partajat | % propoziții normative compilate față de declarate inexprimabile; relații sinonime la 1000 de fire; erori de lint rămase |
| E2. Comparație | 300 de întrebări pe document, stratificate pe tip; baseline-uri: LLM cu textul în context, RAG, LLM care scrie cod ad hoc | acuratețe pe tip; consistență la 5 reformulări; cost și latență pe întrebare; % răspunsuri cu derivare verificabilă |
| E3. Acumulare | 10 amendamente succesive, unele contradictorii, adăugate fără acces la textul vechi | corectitudine după fiecare pas; regresii pe întrebările vechi |
| E4. Ablații | se scot pe rând `overrides`, `assume`, `method`, linterul, auto-testele | ce tipuri de întrebări cad și cu cât |
| E5. Verificare fără referință | 5 compilări independente pe document + test diferențial pe lumi aleatoare | cât de bine prezice dezacordul erorile reale |
| E6. Scară sintetică | KB-uri generate de 10^6–10^8 fapte (`bench/`), cu stocul compact și magic sets | latență pe interogare și pe lume ipotetică, memorie pe fapt |

**Criteriu de succes, fixat dinainte:** pe documente care depășesc contextul, varianta simbolică este cel puțin egală la întrebări simple și mai bună la agregări și scenarii compuse, cu derivare pentru fiecare răspuns.

**Criteriu de oprire:** dacă pe text real sub 70% din propozițiile normative se pot compila, sau dacă deriva de vocabular nu se poate ține sub control cu firul `term` și linterul, abordarea nu merită dusă mai departe în forma aceasta.

## 7. Unde se oprește universalitatea

„Aproape universal” este adevărat pentru clasa reguli + date + proceduri, tipică manualelor și regulamentelor. Nu este adevărat în afara ei.

- **Ce nu e în text nu există.** Motorul știe doar ce s-a compilat; bunul-simț pe care un LLM îl aduce singur lipsește și trebuie scris explicit.
- **Predicatele vagi** („adecvat”, „în timp util”) cer un fir-oracol `ask` către LLM. Se poate, cu prețul determinismului pe acele ramuri.
- **Incertitudinea** se poate face cu ponderi pe derivări (proveniență pe semiinel), care dau probabilități sau costuri cu același algoritm.
- **Timpul și evenimentele** se modelează prin evenimente reificate și intervale de valabilitate pe fapte.
- **Matematica de ordin superior**, inducția și alternanța de cuantificatori sunt în afara clasei; cer un demonstrator de teoreme.
- **Costul:** deducția este polinomială în date. Planificarea și abducția sunt căutare, exponențiale în cazul cel mai rău. Pentru volumul mare de fire, vezi `SCALARE.md`.
