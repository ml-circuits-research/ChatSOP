# Implementare: structura motorului și indicații pentru versiunea de producție

Motorul Node (`src/`, circa 2.000 de linii, fără dependențe) are aceeași semantică ca prototipul Python (`experiment/python-original/sopr.py`), dar alt algoritm de evaluare. Paritatea este verificată pe fiecare ieșire (secțiunea 4). Documentul descrie modulele, invarianții de care depinde corectitudinea, cum se extinde limbajul și ce trebuie schimbat pentru producție.

## 1. Module

| Fișier | Rol |
|---|---|
| `src/lex.mjs` | lexer (atomi coborâți la litere mici, numere, șiruri între ghilimele), formatare compatibilă cu Python |
| `src/parse.mjs` | text → fire (`@nume tip` + linii `cuvânt-cheie valori`) |
| `src/terms.mjs` | dicționarul de termeni: fiecare constantă primește un întreg |
| `src/store.mjs` | stocul de fapte: `Rel` (o relație, indexuri subiect→obiecte și obiect→subiecți, straturi copy-on-write), `Store` (relație → `Rel`) |
| `src/expr.mjs` | expresii `let`/`test` cu semantica Python (comparații înlănțuite, `and`/`or`, erori de tip → „fără valoare") |
| `src/engine.mjs` | compilare, lint, stratificare, joinuri, saturare, lumi, planuri, verificări, afișare |
| `src/lift.mjs` | ridicarea familiilor de reguli în șablon + fapte-parametru |
| `bin/sopr.mjs` | linia de comandă: `lint`, `vocab`, `run`, `why`, `lift`, `stats` |

## 2. Fluxul de compilare

1. **Parsare.** Preludiul (`is-a`, `subclass-of`) și toate sursele se parsează în fire. Un nume de fir repetat e eroare (atribuire unică).
2. **Opțional, `lift`**, pe fire, înainte de compilare.
3. **Verificarea cuvintelor-cheie** pe tip de fir; `supersedes` scoate firele înlocuite din setul activ.
4. **Compilarea fiecărui fir activ** în structuri „brute" (pe tokeni): fapte, corpuri de reguli, capete, metode. Aceleași mesaje de eroare și în aceeași ordine ca prototipul.
5. **Lint:** variabile nelegate, relații și constante care nu apar nicăieri, sintaxa agregărilor etc.
6. **Stratificarea pe relații.** Negația, `from $view` și `overrides` cer strat strict inferior; ciclurile sunt eroare.
7. **`_prepare`**, care construiește structurile de evaluare:
   - corpuri compilate pe sloturi (variabilele devin indici într-un tablou, constantele devin id-uri);
   - `derivers` (relație → regulile care o concluzionează);
   - `deps`/`nonmono` per regulă (relații citite; cele citite prin negație, agregare sau excepție);
   - `dependents` (graful înainte: relație → capetele afectate);
   - `triggers` (relație → atomi de regulă, pe constantă de subiect, de obiect sau oricare);
   - stocul de bază și lumea de bază.

Firele de interogare se compilează la fel. `Engine.query(text)` înlocuiește interogările curente și păstrează KB-ul, saturarea și cache-urile: acesta e modul de lucru pentru un server.

## 3. Evaluarea

### 3.1 Joinuri (`solve`)

Un corp compilat are itemi `pos`, `neg`, `from`, `let`, `test`.

- Itemii `pos` și `from` se ordonează greedy după cardinalitatea estimată. Constantele se numără exact din index; variabilele legate se estimează ca dimensiune / chei distincte.
- Se face un join recursiv, cu mediul ca tablou de id-uri.
- `let`, `test` și `neg` se aplică apoi, în ordinea scrisă, pe fiecare mediu.
- Rezultatele se deduplică după mediu.
- Doar pentru metode rezultatele se sortează ca în prototip, pentru că ordinea decide varianta aleasă de planificator.

Varianta delta (`{ j, facts }`) pune atomul `j` primul și îl leagă doar de faptele noi.

### 3.2 Saturare (`_ensure`, `_runStratum`)

- `_ensure(sat, need)` calculează conul înapoi al relațiilor cerute (`_closure`) și rulează, strat cu strat, doar regulile al căror cap e în con și încă neterminat. Relațiile se marchează terminate (`sat.done`) după fiecare strat, deci o evaluare imbricată (o vedere folosită dintr-o regulă) nu repornește munca.
- `_runStratum`, în modul semi-naiv:
  1. runda 0 evaluează fiecare regulă o dată pe tot;
  2. apoi faptele noi dintr-o rundă (delta) sunt distribuite prin indexul de declanșare la atomii care le pot folosi;
  3. fiecare pereche (regulă, atom) se evaluează o dată cu tot lotul de fapte noi;
  4. se repetă până când nu mai apar fapte noi.
- Seturile blocate de `overrides` se calculează o singură dată pe strat. Sunt stabile, pentru că depind doar de straturi inferioare.

### 3.3 Lumi (`World`, `_newSat`)

Câmpurile unei lumi:

- `base`: stocul de fapte de bază, copy-on-write;
- `assumed`: faptele adăugate ipotetic, pentru eticheta din `why`;
- `sat`: stocul saturat curent;
- `prevSat`, `dirty`, `added`, `removed`: starea de la care se poate continua incremental;
- `parentWorld`, `parentVersion`: legătura către o lume părinte încă nesaturată.

La prima cerere după o schimbare, `_newSat`:

1. calculează `A` = conul înainte al relațiilor schimbate;
2. calculează `RS` ⊆ `A` = relațiile care trebuie refăcute de la zero, adică tot `A` dacă a existat o ștergere, altfel relațiile atinse prin negație, agregare sau excepție plus tot ce depinde de ele;
3. partajează cu părintele toate relațiile terminate din afara lui `RS`;
4. propagă faptele adăugate prin regulile monotone (`_continue`), strat cu strat, cu indexul de declanșare;
5. lasă relațiile din `RS` să fie recalculate leneș, când sunt cerute.

### 3.4 Invarianți (aici au fost bugurile)

Invarianții 2, 3 și 4 au fost încălcați în primele versiuni ale portului. Fiecare încălcare dădea răspunsuri greșite fără nicio eroare, și fiecare a fost prinsă de testele din secțiunea 4.

1. **Un tabel partajat nu se modifică niciodată pe loc.** `Store.fork()` și `_newSat` golesc `owned` la sursă, iar orice scriere ulterioară creează un strat delta.
2. **O relație terminată (`done`) într-un stoc saturat provine din părinte sau e goală, niciodată din baza curentă.** Baza curentă conține deja faptele noi; dacă relația ar fi luată de acolo, adăugarea lor nu ar mai fi văzută ca nouă și nu s-ar propaga.
3. **După o saturare completă, toate relațiile (inclusiv cele doar de bază) sunt marcate terminate.** Altfel o lume copil nu vede faptele adăugate pe relațiile de bază.
4. **Cache-ul de vederi e indexat după obiectul fir, nu după nume.** Interogările succesive refolosesc nume ca `@q`.
5. **Mulțimea `done` e închisă înapoi:** dacă o relație e terminată, toate relațiile de care depinde sunt terminate. Continuarea incrementală se bazează pe asta.

## 4. Verificare

| Test | Ce verifică | Rezultat |
|---|---|---|
| `test/parity.mjs test/cases/pilot.json` | 302 comenzi pe pilot (lint, vocab, run, why pe cele 4 KB-uri, toate interogările Sonnet și testele lor proprii), comparate octet cu octet cu Python | 299/302 identice; cele 3 diferențe sunt la `why` pe o închidere tranzitivă, unde alt lanț de derivare, la fel de valid, e găsit primul (cu `--naive`: 302/302) |
| `test/parity.mjs` pe 400 de scenarii aleatoare | lumi compuse, planuri, verificări pe cele 4 KB-uri, Python vs Node | 400/400, în toate cele 6 moduri de evaluare |
| `test/difftest.mjs 500 11` | KB-urile Sonnet contra referinței pe 500 de lumi aleatoare × 17 sonde | 25.500/25.500; rulează în 2 s (prototipul: 83 s pentru 300) |
| `test/incremental.mjs` | lumi aleatoare (adăugări, ștergeri, lumi imbricate) pe un KB sintetic; incremental vs recalculare de la zero | 1.600/1.600 și 2.400/2.400 |
| `test/grade-compound.mjs` | cele 12 scenarii compuse, notate automat | identic cu prototipul: 72, 71, 72 din 72 |
| `bench/run.mjs` | toate configurațiile dau aceleași răspunsuri la 2k, 20k, 100k entități și la 200k reguli | identice |

Regula de lucru pentru orice optimizare nouă: se adaugă sub un flag, iar flagul se rulează prin `parity` și `incremental` contra modului `--naive`. Optimizările de evaluare nu au voie să schimbe nimic în afară de ordinea premiselor în `why`.

## 5. Cum se extinde limbajul

Un tip de fir nou (de exemplu `term`, `context`) cere cinci pași:

1. cuvintele-cheie în `KEYWORDS`;
2. o ramură în `_compileWire` care produce structuri brute;
3. verificări în `_lint`;
4. dacă firul influențează evaluarea, date noi în `_prepare` și, dacă introduce dependențe, actualizarea lui `deps`, `nonmono` și `dependents`, ca să rămână corecte conul și incrementalitatea;
5. cazuri noi în `test/cases` și în `SPEC.md`.

Un operator nou în expresii: `OPS` și `parseExpr`/`ev` în `expr.mjs`. Semantica trebuie fixată explicit pentru tipuri amestecate: acolo diferă limbajele.

## 6. Ce trebuie schimbat pentru producție

În ordinea valorii, cu motivul fiecăreia.

### Limbaj (v0.2) — din problemele observate în pilot

| Schimbare | Motiv |
|---|---|
| fir `term`: relație, descriere, domeniu, codomeniu, unitate, cardinalitate, inversă, tranzitivă | `set` pe o relație orientată invers a stricat date fără avertisment; indexul de vocabular pentru LLM are nevoie de descrieri |
| `retract S R O` pe afirmație | toți trei agenții au copiat un cadru întreg ca să schimbe o valoare |
| `require-all` / `require-some` | `require` verifică doar prima potrivire |
| prioritate prin specificitate pentru valori pe clase | moștenirea pe mai multe niveluri dă acum două valori |
| linia `assumed "..."` | presupunerile compilatorului despre ce textul nu spune trebuie să fie vizibile |
| pași cu parametri numiți | salinitatea de 10 g/L trebuie să fie interogabilă |
| fapte negative explicite și valoarea „necunoscut” | acum „nedezinfectat” se exprimă doar prin absență |
| stratificare pe afirmații, sau semantică well-founded | un agent a redenumit relații doar ca să treacă de stratificare |
| contexte (`in-context`, `imports`) | vezi SCALARE §4.4 |
| lint: recursie prin aritmetică, buget de fan-out | vezi SCALARE §6 |

### Motor

1. **Stoc compact:** CSR pe `Int32Array` sau fișiere memorie-mapate, delta peste bază, compactare periodică (SCALARE §3). Interfața `Rel` (`has`, `forS`, `forO`, `forAll`, `countS`, `countO`) rămâne aceeași, deci restul motorului nu se schimbă.
2. **Magic sets** pentru interogări cu constante (SCALARE §5).
3. **DRed** pentru ștergeri incrementale (SCALARE §7).
4. **Derivări reconstruite la cerere** în loc de stocate.
5. **Persistență:** jurnal append-only de fire (KB-ul e deja append-only prin `supersedes`), plus instantanee ale stocului saturat.
6. **API:** `new Engine(sources, opts)`, `engine.query(text)`, `engine.result(name).rows`, `engine.render(name)`, `engine.why(text)`. Pentru un server, ele se expun printr-un endpoint care primește circuite și întoarce rânduri JSON cu id-uri decodate.

### Lanțul de compilare cu LLM

Ce a funcționat în pilot și trebuie păstrat:

- **Specificație scurtă, cu exemple și ghid de modelare**, în engleză (`docs/SPEC.md`). E citită de LLM, nu de oameni.
- **Bucla compilare → lint → auto-teste → reparare, făcută de același agent.** Agenții și-au scris singuri cazurile de test, inclusiv pe cele care trebuie blocate.
- **Izolare strictă între etape.** Compilatorul nu vede întrebările, cel care actualizează nu vede textul vechi, cel care interoghează nu vede textul. Doar așa se măsoară ceva.
- **Compilări independente comparate diferențial.** Dezacordul localizează erorile fără răspunsuri de referință.

Ce trebuie adăugat la scară:

- compilare pe fragmente, cu vocabularul existent dat ca listă de termeni apropiați (index semantic), nu ca tot KB-ul;
- deduplicare de entități după fiecare lot;
- `lift` rulat după fiecare lot, iar familiile raportate înapoi compilatorului ca exemplu de formă generală;
- un raport per fragment cu propozițiile normative pe care compilatorul le declară inexprimabile. Această metrică decide dacă abordarea merge pe un domeniu dat.
