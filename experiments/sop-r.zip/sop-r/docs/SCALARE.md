# Scalare: cum evităm explozia combinatorică la zeci și sute de milioane de fire

Răspunsul scurt: cele sute de milioane de fire nu se evaluează toate la fiecare interogare, și nici nu se caută regulile potrivite trecând prin toate. Fiecare fir este indexat după relațiile și constantele pe care le atinge, iar evaluarea atinge doar ce depinde de întrebare sau de schimbare. Pentru o singură mașină, patru mecanisme fac diferența între secunde și ore:

1. **Conul de dependență.** O interogare saturează doar relațiile de care depinde.
2. **Indexul de declanșare.** Un fapt nou găsește în O(1) atomii de regulă care îl pot folosi.
3. **Ridicarea regulilor în date.** Familiile de reguli care diferă doar prin constante devin un șablon plus un tabel de fapte.
4. **Lumile incrementale.** Un „ce-ar fi dacă" recalculează doar consecințele schimbării.

Toate patru sunt implementate în motorul Node, verificate contra evaluării naive și măsurate mai jos. Restul documentului arată de unde vine explozia, ce face fiecare mecanism și ce mai trebuie construit peste 10^8 fapte.

## 1. De unde vine explozia

„Multe circuite" ascunde șase probleme diferite, cu soluții diferite. Doar unele sunt combinatorice.

| Sursă | Cum crește | Exemplu | Soluție |
|---|---|---|---|
| Volumul de fapte | liniar, dar memoria contează | 10^8 triplete | dicționar de termeni, stocare pe relație, indexuri compacte (§3) |
| Volumul de reguli | liniar în numărul de reguli, pe fiecare rundă | 10^5 reguli „clasa X are limita L" | index de declanșare, ridicare în date, contexte (§4) |
| Închiderea materializată | până la pătratic | `located-in` tranzitiv pe o ierarhie adâncă | con de dependență, evaluare la cerere, etichetări de interval (§5) |
| Joinurile intermediare | produs cartezian | două condiții pe aceeași zonă scrise în ordinea greșită | ordonare după cardinalitate, joinuri worst-case optimal (§6) |
| Lumile ipotetice | O(KB) pe lume, 2^n combinații | fiecare pas de plan copiază KB-ul | copy-on-write, întreținere incrementală, ATMS (§7) |
| Vocabularul | nu e combinatorică, dar strică totul | `temp`, `temp-c`, `temperature-c` pentru același lucru | fir `term`, rezolvare de entități, index de vocabular pentru LLM (§8) |

Primele trei cer indexare. A patra cere un optimizator. A cincea cere structuri persistente. A șasea ține de procesul de compilare cu LLM și este, practic, cel mai mare risc.

## 2. Ce am măsurat

KB sintetic în stilul a ceea ce produce un LLM compilând multe documente:

- entități cu clasă, zonă, încărcare, capacitate;
- o ierarhie de clase și una de locații;
- câte o regulă de bază pentru fiecare clasă („clasa c17 are limita 55") și pentru fiecare zonă;
- reguli generale: tranzitivitate, raport, prag, alertă cu excepție;
- o agregare pe zonă, o constrângere;
- o regulă scrisă intenționat în ordinea proastă a condițiilor.

Opt interogări: închidere pe regiune, valoare punctuală, numărare de alerte, regiuni ocupate, încălcări, hotspoturi, lume ipotetică prin adăugare și lume ipotetică prin modificare. Toate configurațiile au dat aceleași răspunsuri la toate dimensiunile. Mașina: 2 nuclee, 7 GB RAM, Node 22. Datele brute sunt în `bench/results/results.jsonl`.

**Configurații:**

| Nume | Ce conține |
|---|---|
| `naive` | algoritmul prototipului Python: runde naive, condiții în ordinea scrisă, totul saturat, fiecare lume recalculată de la zero (dar cu indexurile noului stoc) |
| `seminaive+joinorder` | runde semi-naive cu index de declanșare și ordonare a joinurilor, fără con și fără incremental |
| `full` | tot: plus con de dependență și lumi incrementale copy-on-write |
| `full-noprov` | `full` fără păstrarea derivărilor (fără `why`) |
| `full+lift` | `full` cu familiile de reguli ridicate în date |

### 100.000 de entități, 10.000 de reguli de clasă, 1,28 milioane de fapte după inferență

| Interogare (în ordinea rulării, pe același motor) | naive | seminaive+joinorder | full | full+lift |
|---|---|---|---|---|
| prima interogare (închidere pe regiune) | 28,6 s | 11,0 s | 1,58 s | 1,45 s |
| valoare punctuală (`e17 limit ?`) | 0,01 s | 0,01 s | 1,08 s | 1,26 s |
| alerte | 0,03 s | 0,03 s | 0,90 s | 1,39 s |
| ce-ar fi dacă: se adaugă o entitate | 29,4 s | 12,7 s | **0,031 s** | 0,032 s |
| ce-ar fi dacă: se modifică o încărcare | 27,7 s | 12,8 s | 0,87 s | 0,91 s |
| memorie la final | 1245 MB | 1236 MB | 867 MB | 854 MB |

Cum se citește tabelul:

- `naive` plătește totul la prima întrebare, apoi răspunde instant din materializare. `full` plătește pe bucăți, doar ce trebuie: suma primelor interogări e mai mică decât în `naive`, iar ce nu se cere nu se calculează niciodată.
- Lumile ipotetice sunt unde diferența devine calitativă: **31 ms față de 29 s**, adică un factor de circa 950. Asta face posibile planificarea și căutarea peste multe ipoteze.
- Modificarea (`set`) este încă o recalculare a conului afectat (0,87 s). Ștergerile incrementale (DRed, §7) sunt următorul pas.

### Multe reguli: 50.000 de entități și 200.000 de reguli de clasă

| | seminaive+joinorder | full | full+lift |
|---|---|---|---|
| compilare (parsare 200k reguli) | 6,6 s | 6,2 s | 5,4 s |
| prima interogare | 7,3 s | 1,03 s | 0,85 s |
| ce-ar fi dacă: adăugare | 8,0 s | 0,22 s | **0,041 s** |
| memorie | 1707 MB | 1381 MB | **1043 MB** |

Ridicarea transformă 200.000 de reguli în 2 șabloane plus 400.000 de fapte-parametru. Memoria scade cu un sfert, iar lumea ipotetică devine de 5 ori mai rapidă: un fapt nou declanșează un singur șablon, care își găsește parametrii printr-un lookup indexat, nu prin căutare printre 200.000 de reguli.

### Comparația cu prototipul Python

La 2.000 de entități (27.000 de fapte), prototipul Python răspunde în circa **40 s** pe interogare, iar motorul Node `full` în 0,04–0,1 s. Prototipul nu are index pe obiect și reevaluează fiecare regulă pe tot KB-ul la fiecare rundă. Costul lui crește cel puțin pătratic, așa că la 20.000 de entități nu l-am mai rulat.

### Unde nu ajută (încă)

- **Valoarea punctuală** (`e17 limit ?`) costă 1 s în `full`: conul spune *care relații* trebuie calculate, dar nu *pentru care entități*, așa că se calculează `limit` pentru toate cele 100.000. Remediul este transformarea magic sets (§5), care ar aduce interogarea la milisecunde.
- **Regula scrisă prost** (`hotspot`) costă 2 s chiar și ordonată, pentru că perechile din aceeași zonă sunt reale (200 de entități pe zonă). Ordonarea evită produsul inutil, dar nu poate micșora un rezultat mare.
- **Memoria per fapt** a stocului JS este mare: circa 365 de octeți fără derivări și circa 680 cu derivări (incluzând textul parsat și regulile). La 10^8 fapte asta ar însemna 36–68 GB. Stocul de producție trebuie să fie compact (§3).

## 3. Faptele: 10^8–10^9 triplete

Nu e o problemă combinatorică, ci de reprezentare. Soluțiile sunt standard în stocurile de triplete (RDF-3X, Hexastore, HDT, RDFox):

1. **Dicționar de termeni.** Fiecare atom, număr sau șir devine un întreg de 32 de biți. Comparațiile, hash-urile și joinurile lucrează pe întregi. *Implementat.*
2. **Partiționare pe relație.** Fiecare relație are propriul tabel cu două indexuri, subiect→obiecte și obiect→subiecți. Un pattern cu relație constantă atinge un singur tabel. *Implementat* (hărți JS).
3. **Stocare compactă, de construit:** fiecare relație ca două permutări sortate în format CSR (subiecți distincți + offseturi + obiecte, respectiv invers), în `Int32Array` sau memorie mapată.
   - Costul este circa 8 octeți pe fapt pentru ambele direcții, plus offseturile. La 10^8 fapte asta înseamnă 1–1,5 GB, față de 36 GB în hărți JS.
   - Scrierile noi merg într-un strat delta mic, peste baza înghețată. Stocul actual face deja asta (`Rel` cu `parent`), doar că baza e o hartă.
   - Periodic, delta se comprimă în bază (ca un LSM-tree).
4. **Statistici pe relație:** număr de fapte, subiecți și obiecte distincte, histogramă pe obiecte frecvente. Le folosește optimizatorul de joinuri (§6). Parțial implementat: dimensiune și număr de chei distincte.
5. **Derivările (`why`) nu se stochează.** Se reconstruiesc la cerere: pentru un fapt derivat se caută o regulă cu capul potrivit și un set de premise existente. Stocarea derivării pentru fiecare fapt dublează memoria (măsurat: 867 → 467 MB).
6. **Peste 10^9 fapte:** partiționare pe subiect (hash) pe mai multe noduri. Regulile se replică, joinurile care nu sunt pe cheia de partiționare cer redistribuire. Înainte de asta merită partiționarea pe context (§4.4), care de obicei elimină nevoia de joinuri între partiții.

## 4. Regulile: cum știm unde se aplică o regulă

Aceasta este întrebarea principală. Sunt patru niveluri de indexare, de la grosier la fin, iar primele trei sunt implementate.

### 4.1 Graful de dependențe între relații (con)

La compilare, fiecare regulă contribuie muchii de la relațiile din condițiile ei (inclusiv negații, agregări, excepții) către relația din concluzie. Din graf rezultă două lucruri:

- **straturile:** componente tari conexe ordonate topologic, nega­ția și agregarea doar spre straturi inferioare;
- pentru orice interogare, **conul înapoi**: mulțimea minimă de relații de care depinde răspunsul.

Motorul saturează doar regulile din con și marchează relațiile terminate. Interogările următoare refolosesc ce e deja terminat. În benchmark, prima interogare pe regiune nu calculează deloc limitele, alertele sau hotspoturile.

Costul indexului este proporțional cu numărul de relații distincte, nu cu numărul de reguli. Un KB cu 10^7 reguli are tipic 10^3–10^5 relații.

### 4.2 Indexul de declanșare (rețeaua alfa din Rete)

Pentru fiecare atom pozitiv al fiecărei reguli, motorul înregistrează cheia `(relație, poziție, constantă)`:

- `?x is-a c17` se înregistrează sub `(is-a, obiect, c17)`;
- `?x in-zone ?z` se înregistrează sub `(in-zone, *)`.

Când apare un fapt nou `(e5 is-a c17)`, se fac trei căutări în hash: `(is-a, *)`, `(is-a, subiect, e5)`, `(is-a, obiect, c17)`. Se obțin exact atomii care îl pot folosi. Dintre 200.000 de reguli de clasă se atinge una singură.

Același index conduce evaluarea semi-naivă (după prima rundă, doar faptele noi declanșează reguli) și propagarea incrementală în lumile ipotetice.

### 4.3 Ridicarea familiilor de reguli în date (`lift`)

Un LLM care compilează 10.000 de documente va scrie „clasa X are limita L" de 10^5 ori, ca reguli separate. Compilatorul le detectează:

1. forma canonică a fiecărei reguli (variabile redenumite, constantele din poziții de subiect/obiect înlocuite cu goluri);
2. gruparea după formă;
3. familiile cu cel puțin 3 membri devin un șablon plus un tabel de parametri.

```
@lift-1 rule
  when ?_linst lift-1-p1 ?_lp1
  when ?_linst lift-1-p2 ?_lp2
  when ?x is-a ?_lp1
  then ?x limit ?_lp2
@lift-1-params fact
  say lift-1-i1 lift-1-p1 c0
  say lift-1-i1 lift-1-p2 55
  ...
```

Transformarea este exactă: instanța k a șablonului reproduce regula k. Testat pe KB-urile pilot și pe benchmark, cu răspunsuri identice. Cele trei efecte:

- regulile devin date indexate: „ce reguli se aplică clasei c17" devine un lookup;
- evaluarea devine un singur hash-join în loc de 10^5 evaluări mici;
- memoria scade.

Mai bine decât ridicarea automată este ca LLM-ul să scrie direct forma generală, lucru pe care specificația îl cere deja (§4 din SPEC).

### 4.4 Contexte (de construit)

Pentru sute de milioane de fire, din multe surse, e nevoie de o partiționare semantică: **fiecare fir aparține unui context.** Contextul poate fi documentul, domeniul, jurisdicția, versiunea sau intervalul de valabilitate. Contextele formează o ierarhie cu importuri (ca microteoriile din Cyc), iar o interogare declară contextul în care se pune.

- Regulile vizibile sunt doar cele din contextul interogării și din ce importă acesta. Asta taie mulțimea de reguli relevante cu ordine de mărime, înainte de orice alt index.
- Contradicțiile dintre surse devin normale, nu erori: două manuale cu limite diferite coexistă în contexte diferite.
- Contextul e unitatea naturală de partiționare pe mai multe mașini.

Propunere de sintaxă: o linie `in-context <nume>` pe firele de cunoaștere, un fir `context` cu `imports $alt`, și `in $context` pe interogări. Motorul le tratează ca o a patra coloană a faptelor și ca un filtru pe indexul de reguli.

## 5. Închiderea: nu materializa tot

Regulile recursive (tranzitivitate, moștenire) pot produce mult mai multe fapte decât baza. În benchmark, 100.000 de apartenențe la zone devin circa 300.000 de fapte `located-in` (zonă, sit, regiune pentru fiecare entitate); pe ierarhii adânci sau pe grafuri raportul poate fi pătratic. Trei tehnici, de la simplu la complet:

1. **Con de dependență** (implementat): nu se calculează ce nu se cere.
2. **Magic sets / transformarea la cerere** (de construit): constantele interogării se propagă în reguli, iar `e17 limit ?` calculează limita doar pentru e17. Este tehnica standard pentru Datalog de mari dimensiuni; o alternativă cu același efect este tabling-ul SLG (XSB). La noi ar aduce interogarea punctuală de la 1 s la milisecunde.
3. **Reprezentări speciale pentru ierarhii** (de construit): `is-a` și `subclass-of` pe un arbore se pot răspunde în O(1) cu etichetare pre/post-ordine, fără a materializa n × adâncime fapte. Pe un DAG se folosește etichetarea 2-hop. Motorul poate detecta relațiile tranzitive declarate (prin firul `term`) și le poate servi astfel.

Regula practică: se materializează ce e ieftin și des folosit, restul se calculează la cerere, iar decizia se ia din statistici, nu la compilare.

## 6. Joinurile: ordinea contează mai mult decât orice

O regulă scrisă ca

```
when ?y in-zone ?z
when ?x in-zone ?z
when ?x alert yes
```

produce în ordinea scrisă toate perechile din aceeași zonă. Pornind de la cele câteva alerte, produce doar vecinii alertelor.

- **Implementat:** ordonare greedy după cardinalitatea estimată, cu constantele numărate exact din index și variabilele legate estimate din statistici. Atomul delta vine mereu primul în variantele semi-naive.
- **Măsurat:** fără ordonare, semi-naiv poate fi *mai lent* decât naiv (10,8 s față de 3,2 s la 20.000 de entități), pentru că fiecare fapt delta pornește un produs cartezian. Ordonarea este obligatorie.
- **De construit:**
  - joinuri worst-case optimal (Leapfrog Triejoin, Generic Join) pentru regulile ciclice, cum ar fi triunghiurile;
  - estimări din histograme;
  - cache de planuri per regulă;
  - un buget de fan-out per regulă, care oprește și raportează o regulă ce produce de 1000 de ori mai mult decât intrarea ei.

## 7. Lumile ipotetice și planurile

Prototipul Python copia întregul KB la fiecare `assume` și la fiecare variantă de metodă încercată. La 10^8 fapte asta e imposibil. Motorul Node face următoarele:

1. **Copy-on-write pe relație.** Bifurcarea unei lumi costă O(număr de relații). Prima scriere într-o relație partajată creează un strat delta peste relația înghețată (adăugări și ștergeri), iar lanțurile adânci se aplatizează.
2. **Conul afectat.** Relațiile atinse de schimbare și tot ce depinde de ele. Restul se partajează neschimbat cu lumea părinte.
3. **Continuare incrementală.** Dacă schimbarea e o adăugare pură și drumul până la relația afectată e monoton (fără negație, agregare sau excepții pe drum), faptele noi se propagă semi-naiv prin indexul de declanșare. Relațiile atinse prin negație sau agregare, și tot ce depinde de ele, se recalculează de la zero, leneș. Rezultatul măsurat: 31 ms față de 29 s.
4. **Lumi surori.** O lume creată dintr-un părinte nesaturat îl saturează întâi pe acesta (doar conul cerut) și continuă din el. Toate ipotezele despre aceeași bază împart munca.

De construit:

- **DRed** (delete and rederive) sau contorizarea derivărilor, pentru ștergeri incrementale. Acum o ștergere recalculează conul afectat (0,87 s).
- **ATMS pentru multe ipoteze.** Când trebuie comparate multe combinații de ipoteze, în loc de 2^n lumi fiecare fapt derivat poartă mulțimile minime de ipoteze din care rezultă (etichete de Kleer), iar o lume se evaluează prin filtrarea etichetelor.
- **Memoizare în planificare** pe (sarcină, argumente, amprenta lumii), plus adâncime și buget de ramificare. Descompunerea HTN cu metode ordonate e liniară fără backtracking și exponențială cu backtracking arbitrar.

## 8. Vocabularul: riscul real la scară

La 10^8 fapte scrise de un LLM din mii de documente, problema dominantă nu mai e timpul de calcul, ci faptul că același lucru e numit în trei feluri. Un join care nu se potrivește nu dă eroare, dă zero rânduri. Linterul prinde asta la scară mică („relația X nu apare nicăieri"), dar la scară mare e nevoie de:

1. **Firul `term`.** Declară relația cu descriere, domeniu, codomeniu, unitate, cardinalitate, inversă și dacă e tranzitivă. Compilatorul refuză relațiile nedeclarate sau cere declararea lor explicită.
2. **Un index de vocabular pentru LLM** (embeddings pe descrierile termenilor și pe entități). Compilatorul și agentul de interogare nu pot citi 10^8 fapte; primesc cei mai apropiați 50 de termeni existenți. În pilot, agenții citeau tot KB-ul, ceea ce nu scalează.
3. **Rezolvarea entităților.** Identificatori canonici, fire `same-as` verificate și un pas de deduplicare după fiecare lot compilat.
4. **Testul diferențial ca monitor.** Două compilări independente ale aceluiași document, comparate pe lumi aleatoare, semnalează unde textul e ambiguu sau unde o compilare a greșit, fără răspunsuri de referință.

## 9. Arhitectura propusă pe niveluri

| Scară | Ce ajunge |
|---|---|
| până la ~10^7 fapte | motorul de față, un proces, stoc în memorie; cu stoc compact (§3) până la ~10^8 |
| 10^8–10^9 | stoc CSR memorie-mapat, magic sets, DRed, contexte, statistici; un server mare |
| peste 10^9 | partiționare pe context, apoi pe subiect; evaluare distribuită semi-naivă (ca Soufflé paralel sau BigDatalog), reguli replicate |

Pe toate nivelurile rămân aceleași reguli de igienă:

- regulile se scriu general, iar familiile se ridică în date;
- fiecare interogare atinge doar conul ei;
- nicio lume nu copiază baza;
- recursia prin aritmetică trebuie refuzată la lint, pentru că poate inventa valori la infinit (acum motorul se oprește doar după 10.000 de runde);
- fiecare regulă trebuie să aibă un buget de fan-out măsurat.
