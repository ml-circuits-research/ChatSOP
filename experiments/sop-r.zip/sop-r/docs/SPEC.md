# SOP-R — a reasoning profile for SOP Lang (v0.1)

SOP-R is a small declarative language. Knowledge is written as **wires**. A wire is
assigned exactly once (single assignment) and may reference other wires.

```
@wireName wireType
  keyword value ...
  keyword value ...
```

* A line starting with `@` opens a wire: `@name type`. Every other line is `keyword value...`
  and belongs to the wire above it. `#` starts a comment.
* Terms inside a value:
  * **atom** — `tank-7`, `red`, `mountain-bike` (case-insensitive, no spaces; use `-`)
  * **number** — `12`, `3.5`
  * **quoted string** — `"any text"`
  * **variable** — `?x`, `?total_price` (letters, digits, `_` only — no `-` in variable names)
  * **wire reference** — `$otherWire`
* A **statement** is always exactly three terms: `subject relation object`.
  More complex facts are expressed with several statements about the same subject.
* Numbers carry no unit. Put the unit in the relation name or fix it by convention
  (`price-eur 12`, not `price 12 eur`).

The engine uses the **closed-world assumption**: what is neither stated nor derivable is false.

## 1. Knowledge wires (what goes into the knowledge base)

### 1.1 `fact`
Frame form — one subject, one line per statement (`relation value`, exactly ONE value term):

```
@bike-b1 fact
  about b1
  is-a city-bike
  daily-price 12
  kept-at depot-north
  has basket
  has child-seat          # a relation may be repeated (multi-valued)
  source "catalogue p.3"  # optional, ignored by reasoning
```

Free form — `say subject relation object`, useful for many small statements:

```
@taxonomy fact
  say city-bike subclass-of bike
  say e-bike subclass-of bike
  say cargo-e-bike subclass-of e-bike
```

Built in: `is-a` (instance → class) and `subclass-of` (class → class) are transitive and
inherited automatically (`b9 is-a cargo-e-bike` implies `b9 is-a e-bike` and `b9 is-a bike`).
No other relation is transitive unless you write a rule for it.

Reserved words that cannot be used as relation names in a frame: `about say source note overrides supersedes`.

### 1.2 `rule`
Derives new statements. All conditions must hold.

```
@r-deposit-default rule
  when ?b is-a bike              # positive condition (statement pattern with variables)
  then ?b deposit 50             # conclusion (one or more "then" lines)

@r-deposit-ebike rule
  when ?b is-a e-bike
  then ?b deposit 200
  overrides $r-deposit-default   # exception: wins over the default, see below

@r-weekly-price rule
  when ?b daily-price ?d
  let ?w = ?d * 6                # compute a value
  then ?b weekly-price ?w

@r-premium rule
  when ?b daily-price ?d
  test ?d >= 30                  # numeric / equality test
  unless ?b condition damaged    # negation: no such statement exists
  then ?b price-class premium
```

Lines: `when S R O`, `unless S R O`, `let ?v = expr`, `test expr`, `from $view`, `then S R O`,
`overrides $rule`, `supersedes $wire`, `source "..."`, `note "..."`.

* Expressions: `+ - * / ( )`, comparisons `= != < <= > >=`, `and`, `or`.
  **Operators must be surrounded by spaces** (`?a - ?b`, not `?a-?b`).
* Every variable used in `then`, `let`, `test` must be bound by a `when` line (or `let`/`from`).
  A variable that appears only in `unless` is a wildcard ("there is no ... at all").
* `unless` takes ONE statement pattern. To negate a combination, first derive a helper
  statement with another rule, then negate that.
* The relation position of a statement in a rule must be a constant (not a variable).
* Rules may be recursive (e.g. transitivity: `when ?a part-of ?b / when ?b part-of ?c / then ?a part-of ?c`).

**Defaults and exceptions — `overrides`.** `@B overrides $A` means: wherever B concludes
some statement `S R x`, rule A's conclusions `S R y` *for the same subject S and relation R*
are suppressed. A `fact` wire can also override a rule:

```
@b7-deposit fact
  say b7 deposit 0
  overrides $r-deposit-default
```

A wire may carry several `overrides` lines. Without `overrides`, a default rule and an
exception rule would both fire and the subject would get two values.

**Stratification restriction.** Negation (`unless`), aggregation (`from $group`) and
`overrides` must not be circular *at the level of relation names*: a rule that concludes
relation `R` must not depend — directly or through other rules — on `unless ... R ...`,
on an aggregate over `R`, or on an overriding rule whose conditions use `R`.
The linter reports "not stratifiable". The usual fix is to use more specific relation
names instead of one catch-all relation (e.g. `condition` and `price-class` rather than
a single `status` for everything).

### 1.3 Views inside the knowledge base: `find` and `group`
A `find` or `group` wire (see §2) may be stored in the knowledge base and used by a rule
through `from $view`. This is how rules use aggregates:

```
@v-bikes-per-depot group
  match ?b kept-at ?depot
  by ?depot
  count ?b as ?n

@r-depot-full rule
  from $v-bikes-per-depot
  test ?n > 40
  then ?depot status full
```

### 1.4 `constraint`
A pattern that must never hold. Constraints do not block anything; a `check` query lists violations.

```
@c-helmet constraint
  when ?r rents ?b
  when ?b is-a e-bike
  unless ?r has helmet
  message ?r rents e-bike ?b without a helmet
```

Lines: same conditions as a rule (`when`, `unless`, `let`, `test`, `from`) plus `message ...`.

### 1.5 `method`
Procedural knowledge: how to perform a task. A task may have several methods (variants);
the first one (in file order) whose conditions hold is used.

```
@m-return-clean method
  task return-bike ?b
  when ?b status clean                 # applicability conditions (when / unless / let / test)
  step "Park" ?b "in the rack"

@m-return-dirty method
  task return-bike ?b
  unless ?b status clean
  do wash ?b                           # sub-task (another method); runs at this position
  step "Park" ?b "in the rack"

@m-wash method
  task wash ?b
  forbid ?b is-a e-bike "e-bikes must not be pressure-washed"   # hard precondition (negative)
  step "Pressure-wash" ?b
  step "Dry" ?b
  add ?b status clean                  # effect on the world state

@m-rent method
  task rent ?who ?b
  when ?b deposit ?dep
  when ?who balance ?bal
  require ?who has id-card "customer must show an ID card"       # hard precondition (positive)
  require-test ?bal >= ?dep "balance does not cover the deposit" # hard numeric precondition
  do return-bike ?b
  step "Hand over" ?b "to" ?who
  add ?who rents ?b
  set ?who balance 0                   # set = remove every "?who balance *" then add
  remove ?b kept-at ?anywhere          # unbound variable in remove = wildcard
```

Lines, processed **in order**:

| line | meaning |
|---|---|
| `task name ?p1 ?p2 ...` | header: task name and parameters |
| `when / unless / let / test` | applicability: evaluated at the start; if they fail this variant is skipped; they also bind variables |
| `require S R O "msg"` | hard precondition, checked when reached; if it fails the plan is BLOCKED with the message. Unbound variables are bound by the first match |
| `forbid S R O "msg"` | blocked if the statement holds |
| `require-test expr "msg"` | blocked if the expression is false |
| `step ...` | a primitive action (quoted text and variables, concatenated) |
| `do task args...` | run a sub-task |
| `forall S R O do task args...` | run the sub-task once for every match of the pattern |
| `add / remove / set S R O` | change the world state at this point |

Use `when` for "which variant applies" and `require`/`forbid`/`require-test` for
"this must be true, otherwise the procedure is not allowed" — the difference matters because
only the latter produce an explanation of *why* something is not allowed.
Effects change base facts; rules are re-evaluated automatically after every change
(so derived statements stay consistent). `remove` cannot delete a derived statement.

### 1.6 Updating accumulated knowledge
The knowledge base is append-only. Later knowledge is added as new wires:

* `supersedes $oldWire` (any knowledge wire) — the old wire is switched off entirely and
  this wire replaces it. Use it when a value or rule has *changed*.
* `overrides $rule` — the old rule stays as the default; the new wire is an exception to it.

Because `supersedes` works on whole wires, put values that may change in their own small wire.

## 2. Query wires

### 2.1 `find`
```
@q1 find
  match ?b is-a e-bike          # "match" = positive pattern ("when" is accepted too)
  match ?b deposit ?dep
  not ?b condition damaged       # "not" = negation ("unless" is accepted too)
  let ?double = ?dep * 2
  test ?double > 100
  return ?b ?dep                 # optional projection (rows are de-duplicated)
```
Result: a set of rows (variable bindings). Extra lines: `from $wire` (join with the rows of
another find/group/plan/check wire on shared variable names; several `from` lines allowed),
`in $world` (evaluate in a hypothetical world, §2.3).
In query wires a variable may be used in relation position (`match b1 ?rel ?value`).

### 2.2 `group`
Same condition lines as `find`, plus grouping and aggregates:
```
@q2 group
  match ?b kept-at ?depot
  match ?b daily-price ?p
  by ?depot                      # optional; without "by" there is one global row
  count ?b as ?n                 # count of distinct values
  sum ?p as ?total
  max ?p as ?highest             # also: min, avg
```
`sum`/`avg` run over the distinct rows of the conditions, so keep the identifying variable
(here `?b`) in the conditions — never aggregate over a `find` that returned only the numbers.

Arg-max idiom (who has the highest total?):
```
@per group
  match ?b kept-at ?depot
  match ?b daily-price ?p
  by ?depot
  sum ?p as ?total
@best group
  from $per
  max ?total as ?total
@winner find
  from $per
  from $best                     # join on ?total keeps only the top row(s)
```

### 2.3 `assume` — hypothetical worlds
```
@w assume
  add b3 condition damaged
  remove b1 has basket
  set b1 daily-price 40          # replace the value
@q3 find
  in $w
  match ?b price-class premium
```
An `assume` wire forks the world; all rules are re-evaluated inside it. `in $w` on a
`find` / `group` / `check` / `plan` / `assume` wire evaluates it in that world.
Only base facts can be removed or replaced (derived statements change as a consequence).

### 2.4 `plan`
```
@p plan
  task rent alice b1
@after find
  in $p                          # the world as it is after the plan has run
  match alice rents ?b
```
Expands the task with the methods of the knowledge base and returns either the ordered list of
primitive steps, or `BLOCKED` with the reason (failed `require`/`forbid`/`require-test`, or no
applicable method). Rows: `?n ?step`, or `?status blocked ?reason`. `in $world` is allowed.

### 2.5 `check`
```
@v check
  in $w        # optional
```
Rows: one per constraint violation, with `?constraint`, `?message` and the constraint's variables.

### 2.6 `answer`
```
@a answer
  from $q1
  show ?b        # optional projection
  text "e-bikes with a high deposit"   # optional label
```
Each query file must end with one or more `answer` wires; they are what gets printed.
An empty result (0 rows) means "none / no".

## 3. Tooling
```
node bin/sopr.mjs lint  kb1.sop [kb2.sop ...]             # errors + warnings
node bin/sopr.mjs vocab kb1.sop [kb2.sop ...]             # relations, values, tasks, constraints
node bin/sopr.mjs run   kb1.sop [kb2.sop ...] -q query.sop
node bin/sopr.mjs why   kb1.sop [kb2.sop ...] -t "b1 price-class premium"   # derivation tree
node bin/sopr.mjs lift  kb1.sop [kb2.sop ...]             # rewrite families of same-shape rules
node bin/sopr.mjs stats kb1.sop [kb2.sop ...] [-q q.sop]  # sizes and timings
```
Several KB files are simply accumulated (in order). A query file may only contain query
wires (find, group, assume, plan, check, answer).

The linter reports errors (must be fixed) and warnings. The most important warning is
*"relation/constant ... is never asserted or derived anywhere"*: it almost always means the
same thing has been named in two different ways. Keep one consistent vocabulary: before
inventing a relation name, check whether one already exists (`vocab`).

When many rules differ only in their constants (one rule per class, per zone, per product...),
prefer ONE general rule over a table of facts (see §4); `lift` does this rewrite automatically.

## 4. Modelling guidelines
* One entity → one atom, used everywhere (`b1`, not `bike-1` in one place and `b1` in another).
* Classes are atoms too; `subclass-of` between classes, `is-a` from instance to class.
  Properties of a class (limits, default values) are statements about the class atom, or
  rules over `is-a`.
* General statements in the text ("every X ...", "X is Y when ...") become **rules**, not
  one fact per individual — new individuals added later must be covered automatically.
* A value that is computable from others (ratio, sum, status) should be **derived by a rule**,
  not stored.
* "Unless / except / instead" in the text → `unless` or `overrides`.
* "Must / may only / never" about a state of affairs → `constraint`; about performing a
  procedure → `require` / `forbid` / `require-test` inside the `method`.
* Procedures → `method` wires; referenced sub-procedures → `do`; "if ... otherwise ..." →
  two methods for the same task with complementary conditions.
