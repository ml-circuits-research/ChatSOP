# Semantic contract and verification scope

## Base semantics

For each positive SCC, evaluation computes the least set of tuples closed under its rules, using completed dependency SCCs as inputs. Rules do not introduce fresh constants, so the finite active-domain semantics is finite. Stratified `NONE` is evaluated only after its target SCC is complete. Input relations may also have rules; their initial facts are included in the fixpoint.

A successful answer is relative to this database snapshot and these rules. It is not evidence that a natural-language extraction or a premise is correct about the external world. Missing a fact is not an explicit negative claim. Closed-world NONE is appropriate only for relations whose completeness assumptions the application accepts.

## Accepted transformation contracts

| Transformation | Preservation argument | Runtime guard |
|---|---|---|
| Join permutation | Associativity/commutativity of pure conjunction and set join | Same literal-index permutation; filters are evaluated only when bound |
| Seminaive deltas | Every new recursive consequence uses at least one newly available premise; set union reaches the same least fixpoint | Finite function-free program; SCC schedule |
| Predicate slicing | Only definitions in the transitive dependency closure can affect the query | Syntactic dependency traversal, including negative edges |
| Positive demand rewrite | Propagated bindings restrict derivations to the query-relevant adorned calls | Positive slice; known constructive transformation; bounded number of adornments; fallback otherwise |
| Existential factoring | A disconnected, non-output component contributes only whether it has a witness | Variable-component analysis; set semantics; no side effects |
| Unique-definition inlining | Substitution of the entire defining conjunction is equivalent to the derived atom | Unique nonrecursive positive definition; no base facts; safe fresh names |
| 2D Pareto sweep | Sorting by objective one, then maintaining the best objective two identifies exactly the two-branch strict partial-order domination relation | Exact rule-shape recognition; same group; integer objectives; both strictness branches; source extensional |

These are constructive template arguments backed by independent checks, not SAT/SMT certificates for arbitrary synthesized programs. A finite randomized test alone is never labelled a universal proof.

## Pareto contract in particular

For an extensional relation of triples `(group,a,b)`, the recognized rule defines domination by another tuple in the same group with both objectives no worse and at least one strictly better. Minimization/maximization directions are inferred from the rule comparisons. Sorting puts potential dominators first. Maintaining the best second objective allows a linear scan after sorting. Duplicate exact input tuples have already collapsed under set semantics.

The compiler preserves the answer to **that explicit relation/query**. It does not infer that this relation safely prunes all future paths in a resource problem. Such a use additionally needs the simulation/monotonicity assumptions studied in E06. A domain can provide a mathematically inappropriate dominance rule; the relational engine will faithfully execute it rather than invent missing domain assumptions.

## Evidence

With provenance enabled, every retained derived tuple has one first witness. `explain` exports an acyclic graph containing input tuples, source locations, applied rules and premise links. `verifyExplanation` independently replays local unification and filters and checks source metadata and snapshot fingerprints. Negative premises are checked against the completed lower relation in the supplied evaluation snapshot.

This is not a self-contained proof of completeness of a negative answer: replaying absence still relies on the completed evaluation and its trusted kernel. For a demand/inlining/Pareto compilation, the transformation template is also in the trusted boundary. Certificates identify the template, its applicability and source fingerprints. No external proof assistant was used.

## Budgets and mutation

If a work, derivation or time budget is exceeded, status is `INCOMPLETE`, not `false`, `UNSAT`, or `COMPLETE`. Partial positive results may be present but are not exposed as a complete answer. The proof API refuses to certify an incomplete evaluation.

A Session update increments the epoch, clears result caches and rebuilds on demand. A fork has a separate identity and isolated facts. Results from a different epoch/session are `STALE`; cached proof/absence claims are not reused across changed worlds. This conservative strategy is correct but is not an incremental deletion-maintenance algorithm.

## Corrections to earlier conceptual claims

Historical reports are retained unchanged. The current contract is stricter than some earlier prose:

* A bounded search that finds no counterexample does not establish universal equivalence.
* Arbitrary monotone partition refinement can oversplit; it need not return the minimal behavioral quotient.
* A split that separates one counterexample does not by itself establish congruence for all future operations.
* Failure to prove a goal from a selected local theory does not establish that the full knowledge base cannot prove it.
* Comparing approximate answers or dropping dominated states is inappropriate when the semantics require all proofs, all solutions, or multiplicities.
* Learned guidance affects correctness only through the surrounding kernel contract. A malicious or very bad guide may prevent completion within budget; “still exact” means accepted answers/transformations are sound, not that success is guaranteed.

These distinctions are now enforced where the runtime supports them and explicitly marked elsewhere.
