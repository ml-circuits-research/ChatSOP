# Sources and attribution

All measurements in REPORT.md and RESULTS.md come from the shipped code, datasets and JSON result files. Historical claims are located in the preserved E00–E07 archive and are labelled separately.

The central relational algorithms are established techniques; this package does not claim to have invented Datalog, seminaive evaluation, tabling, magic sets, query optimization, Pareto frontiers or proof provenance.

Primary implementation/documentation references checked for this work:

1. Soufflé, **Magic-Set**: positive Datalog adornment and demand-rule transformation; limitations for negation and other constructs. https://souffle-lang.github.io/magicset
2. SWI-Prolog manual, **Tabled execution (SLG resolution)**: memoization, recursive goals, relationship to bottom-up Datalog and goal-oriented evaluation. https://www.swi-prolog.org/pldoc/man?section=tabling
3. Soufflé, **Provenance**: tuple explanations and proof trees. https://souffle-lang.github.io/provenance

The current implementation uses its own code. The independent SQLite baseline is Node's built-in SQLite binding; its exact Node/SQLite versions are reported in the results. Its hand-written queries are a strong family-specific reference and are not presented as an interchangeable general SOP engine.

No external “state of the art” performance claim is inferred from these references. No external prover was used to certify arbitrary generated rewrites. The supported transformation proof arguments and their guards are stated explicitly in SEMANTICS_AND_PROOFS.md.
