# Regression and reproducibility policy

`make regression` runs current `.mjs` tests and historical integrity/record checks. `make reproduce` also recreates current experimental measurements and a deterministic semantic fingerprint. Do not equate the number of named unit tests with the number of differential comparisons or saved historical assertions.

Keep the original archive unchanged. Append stages to the research log. Any port must identify whether it is a complete behavioral port, a limited adapter, or a newly tested analogy. Earlier negative results remain controls, not blemishes to delete.

Current tests cover recursion (including mutual/nonlinear recursion), explicit negatives, stratified absence, disjunction, projection, duplicated derivations, types, unsafe rules, missing data, proof corruption, stale data/schema, inlining capture, resource limits, Pareto guards, updates/forks, neural serialization and independent SQL/reference agreement. Seeded differential tests make each optimization compete against a separately implemented evaluator.

Test datasets are generated deterministically and saved as SOP text. Existing main test files are compared with their deterministic generation; modifications cause a failure. Stress files are never overwritten if they already exist: their SHA-256 is checked against the deterministic generator. Training and test seeds differ, and trained plan/model files are written before the relevant test generation.

`results/SEMANTIC.json` deliberately excludes wall times, memory readings, random Session UUIDs and transient logs. It includes answer hashes, completion statuses, operation counts, selected policies and neural evaluation outcomes. Exact byte equality of this file across fresh runs is the reproducibility criterion. Floating timing equality is neither expected nor claimed.

A negative result is recorded as such. Budget-exhausted runs are not counted as solved and never assigned a fabricated runtime speedup. New optimizations must preserve reference answers and pass adversarial guard tests. A counterexample outside a supported template must lead to fallback, rejection or `INCOMPLETE`, not silent semantic relaxation.

The historical 79-test rerun is separately documented in `results/legacy-regression-current.log`; it executed the preserved Python sources in the supplied environment. The 15 historical record checks are weaker: they validate retained result files only. Re-running all historical neural training requires the archived environment/dependencies and is not part of the new Node-only reproduction command.

## E09 SOP-native property layer

`make regression` now also runs `tools/sop-regression.mjs`. The 14 `.sop` files under `regression/cases/` are executable programs whose `#%` comments express answer, certificate, performance or expected-rejection properties. This layer is deliberately separate from unit tests: it is intended to remain readable as SOP research examples and to grow whenever a new reasoning property is claimed.

E09 also adds eight Node tests for lemma construction/certificate tampering, held-out dreaming, schema-local reuse, journal capture, promoted-only deployment and rejection of sound-but-unhelpful skills.

The historical archive is still authoritative for claims that the current Boolean SOP profile cannot express, especially E00 algebraic worlds, E01 latent algebra and E07 feature-grammar invention.
