# Dreaming and consolidation lifecycle

## Decision: not every task should invent new reasoning machinery

The online reasoner and the invention process have different safety/performance roles.

**Online task execution** should be conservative. It loads only already-promoted skills whose applicability fingerprints match, performs exact reasoning, records cost/failure traces, and returns `COMPLETE` or `INCOMPLETE`. Cheap plan choice may happen online because it changes only order/cost, not semantics.

**Dreaming/consolidation** is the expensive learning phase. It should normally run after a batch of tasks, during idle time, or after repeated expensive/incomplete episodes. It replays tasks, searches for reusable abstractions, verifies candidates, evaluates held-out cost, runs the cumulative regression suite, and only then promotes a skill.

A third path is **counterexample-triggered repair**. If a promoted structural skill later fails an applicability check or receives a counterexample, it must be quarantined for that scope immediately. The exact baseline remains available while dreaming attempts specialization or replacement.

This split prevents each user query from paying the full cost of algorithm invention and prevents a speculative discovery from silently changing truth.

## Lifecycle

```text
online tasks
   |
   +--> exact reasoning with promoted skills
   |        |
   |        +--> answers + proofs/status
   |        +--> episode journal
   |
   +--> repeated cost / INCOMPLETE / counterexample
                    |
                    v
              DREAM / CONSOLIDATE
                    |
        +-----------+-----------+
        |                       |
   candidate synthesis     candidate ranking
        |                       |
        +-----------+-----------+
                    v
             exact verification
                    |
               held-out replay
                    |
            cumulative regression
                    |
              cost evaluation
                    |
          +---------+----------+
          |                    |
       PROMOTE             REJECT/QUARANTINE
          |
          v
     persistent skill library
```

The implemented E09 lifecycle is represented by `EpisodeJournal`, `Dreamer`, `VerifiedSkillStore`, and `AdaptiveReasoner` in `src/dream.mjs`.

## What is actually synthesized in E09

The first integrated invention mechanism is deliberately small and fully checkable: one-step Horn resolution/composition. Given

```text
P(...) :- A(...)
Q(...) :- ..., P(...), ...
```

the dreamer may construct the redundant consequence

```text
Q(...) :- ..., A(...), ...
```

with alpha-renaming and unification. The certificate names the producer rule, consumer rule, body position and hashes of both original rules and the derived lemma. `verifyLemmaBundle()` reconstructs the lemma from the current schema; editing either the original rules or the lemma invalidates the skill.

A sound lemma is **not automatically useful**. It is replayed on training/held-out programs. In the included example, composing the recursive reachability rule with itself creates a longer jump. It increases some tuple work but collapses fixpoint depth from dozens of rounds to a few rounds. The configured cost model therefore explicitly states the trade-off it optimizes.

This is real lemma synthesis and persistent reuse, but it is not open-ended theorem discovery. The current constructor is supplied by the designer.

## Promotion contract

A persistent skill record contains at minimum:

```text
id
kind
status
scope
schema/query applicability
semantic contract
artifact
verification evidence
cost evidence
history
```

Current states are `candidate`, `promoted`, `rejected`, and (architecturally) `quarantined`.

Promotion requires:

1. syntactic/constructive certificate verification;
2. exact replay against the independent evaluator on available small cases;
3. exact held-out answers;
4. no unacceptable cost regression under the stated objective;
5. cumulative regression before a release artifact is accepted.

Testing is not substituted for a constructive proof when a constructive checker exists. Conversely, a local constructive proof of soundness does not prove that a skill is beneficial; cost is measured separately.

## Scope levels

The implemented store deploys **schema-local** skills. This is intentionally conservative.

Future levels should be explicit:

1. **task-local** — applies only to one snapshot/query;
2. **schema-local** — same rule schema and query, different facts;
3. **structural-template** — predicates/roles may be renamed, but a role mapping and applicability proof are required;
4. **domain skill** — e.g. dominance under a proved transition contract;
5. **general reasoning concept** — e.g. decomposition, quotienting, sufficient statistics, invariant induction.

E06 historically demonstrated structural transfer of dominance. That transfer is preserved in the archive but is not silently generalized by the current E09 store.

## When dreaming should run

Recommended triggers:

- the same schema/query has accumulated several replayable episodes;
- `INCOMPLETE` appears repeatedly under reasonable budgets;
- candidate visits, rounds or memory exceed a percentile threshold;
- many sibling tasks exhibit repeated derivation fragments;
- a counterexample invalidates a previously broader applicability condition;
- the system is idle and has a backlog of high-cost episodes.

A cheap online autotuner may still choose among already-verified plans per task. New semantic abstractions should normally be consolidated offline.

## Long-term target

The intended extension is a sequence of increasingly expressive dreamers:

```text
join/plan selection
 -> redundant lemmas
 -> verified rule rewrites
 -> quotient/equivalence discovery
 -> dominance/subsumption relations
 -> derived invariant/features
 -> decomposition/separators
 -> representation constructors
 -> composed algorithms
```

Every stage should compile the discovery into an inspectable skill and keep the exact fallback. ML may rank which candidate or constructor to try next. It should not be the authority that declares a pruning step true.

## E10 extension: multiple inventors and a separate deployment gate

E09 had one integrated semantic inventor: constructive Horn lemma composition. E10 keeps that path and adds a common interface for quotient, independent decomposition, Pareto recognition, demand specialization and advisory invariant discovery.

The trust pipeline now has two distinct promotion concepts:

1. **skill promotion** — the artifact is semantically admissible for its scope;
2. **deployment promotion** — a replay-verified subset of already trusted skills is cost-effective for a specific query/objective.

This distinction prevents a library from turning into an “enable everything” optimizer. The empty deployment remains a valid candidate.

Empirical invariant records have `scope = advisory-only`. They can seed future synthesis but are deliberately ignored by `VerifiedSkillStore.promoted()` when building execution settings.
