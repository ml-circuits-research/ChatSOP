# Skill composition and deployment

A skill has two distinct statuses: **trusted** and **deployed**. Trusted means the artifact passed its semantic gate. Deployed means a replay-verified composition selected it for a specific schema/query/objective.

This distinction is necessary because two individually correct shortcuts can interact badly in cost even though the answer remains exact.

## Record shape

Conceptually a reusable reasoning skill is:

```text
Skill = {
  applicability,
  transformation,
  semanticContract,
  certificate,
  evidence,
  costModel,
  scope
}
```

Current code stores this information in `VerifiedSkillStore` records. `deployment-plan` records contain a set of member skill IDs and concrete reasoner settings.

## Composer protocol

For every subset considered:

1. merge only compatible certified settings;
2. execute every replay task;
3. compare the answer set with the independent reference evaluator;
4. reject incomplete or semantically different candidates;
5. compute deterministic work/depth score;
6. promote only the best exact subset.

The empty subset is always a candidate. Therefore composition cannot be declared useful merely because some promoted skill exists.

## Objective dependence

The current objective is `candidateVisits + roundWeight * rounds`. A different product may choose latency, memory, proof size or verifier calls. The objective is part of evidence and must not be confused with semantic correctness.
