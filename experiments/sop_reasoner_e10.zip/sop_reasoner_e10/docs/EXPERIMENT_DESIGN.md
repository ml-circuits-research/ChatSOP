# Experimental design for a cumulative reasoning architecture

This document maps architectural claims to experiments that can falsify them. A new optimization should add evidence here and normally add a SOP-native regression case.

## 1. Semantic exactness

**Question:** Does an execution path preserve the answer set?

**Method:** compare against the independent nested-loop/reference evaluator on small and medium problems. For special domains, add a separate oracle such as SQLite or exhaustive enumeration.

**Failure criterion:** one wrong COMPLETE answer.

SOP regressions: R01–R05, R10–R14.

## 2. Safe refusal

**Question:** Does the engine refuse a shortcut when its proof obligations are not met?

**Method:** adversarially perturb a valid pattern: use a dominance relation with an objective-dependent bonus, negative recursion, a live variable that quotient would otherwise erase, or a stale/tampered certificate.

**Failure criterion:** unsafe optimization receives a trusted certificate.

SOP regressions: R08, R11, plus Node guard tests and E10 quotient guard tests.

## 3. Verified discovery

**Question:** Can dreaming find a useful optimization from repeated tasks rather than having it enabled manually?

**Method:** run `Dreamer` on replay programs with the optimization disabled in the baseline; require a promoted family and exact replay.

SOP regressions: R09, R16, R17, R18.

## 4. Advisory/trusted separation

**Question:** Can the system retain potentially useful empirical regularities without accidentally treating them as proof?

**Method:** discover an empirical functional dependency; require it to be visible via `advisories()` and absent from execution settings.

SOP regression: R19.

## 5. Composition

**Question:** Can separately valid skills be combined without assuming that all of them should be active?

**Method:** enumerate exact subsets, include the empty subset, compare replay cost and promote one deployment plan.

SOP regression: R20.

## 6. Transfer

**Question:** Do learned skills generalize to larger fact sets when rules/schema remain unchanged?

**Method:** train/dream on small worlds, freeze the store, evaluate a larger world that is never used for discovery or selection.

E10 benchmark: 106,800 facts, four query types.

## 7. Scale and locality

**Question:** Does a verified representation prevent the query phase from enumerating irrelevant combinations?

**Method:** compare tuple probes and completion status while separately reporting input parsing/indexing. Never describe low query probes as low ingestion complexity.

E08 million-fact stress and E10 multi-domain environment.

## 8. Algorithm invention (future)

A stronger result requires creating a new reusable abstraction not already exposed as a transformation family. Candidate experiments should require one or more of:

- synthesis of a new dominance relation from primitive comparisons;
- invention of a derived feature/invariant used in a proof;
- invention of a new quotient/state signature;
- invention of a new decomposition or separator;
- representation-language expansion triggered by counterexamples;
- composition of newly invented primitives into an exact algorithm.

The historical E06/E07 experiments provide evidence for several of these mechanisms, but they must be ported into the SOP Dreamer before being claimed as runtime capability.

## Regression rule

No new stage may delete a negative control or replace an older capability test with a smaller unrelated demo. `make regression` is the minimum gate; `make reproduce` is the release gate.
