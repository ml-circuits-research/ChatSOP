# SOP Lang reasoning + algorithm invention architecture

## The concrete problem

A SOP environment can contain millions of fact wires and many rule wires. A query should not cause blind closure over every combination. The reasoning subsystem therefore needs two products:

1. an exact answer/proof for the current query;
2. a growing library of verified ways to make future queries cheaper.

The second product is where the experimental line E00–E09 fits.

## Online representation

A useful query-local reasoning state is:

```text
Goal
LocalTheory
Frontier
DerivedFacts
ProofDAG
ApplicableSkills
CostState
```

`LocalTheory` is the query-relevant slice of the much larger knowledge base. In the current implementation this begins with dependency slicing and optional demand propagation. Future theory construction can rank facts/rules, introduce lemmas, or identify independent components, but any operation that removes possibilities needs a semantic justification.

A SOP-native example:

```text
@world facts
FACT edge a b
FACT edge b c
FACT edge c d

@base rule
WHEN edge ?x ?y
THEN path ?x ?y

@step rule
WHEN path ?x ?y
AND edge ?y ?z
THEN path ?x ?z

@answer query
GIVES ?y
MATCH path a ?y
```

The first executions may use ordinary seminaive recursion. Dreaming can later derive and certify a jump lemma from `@step` composed with itself. The lemma is an execution skill, not a new premise imported from an LLM.

## Avoiding combinatorial explosion

Different explosions need different abstractions.

| Explosion | Reasoning response | Evidence line |
|---|---|---|
| irrelevant global facts | goal-directed slice / demand | E08 |
| repeated recursive work | deltas, memoization, learned jump lemma | E08/E09 |
| disconnected body components | decomposition/existence factoring | E08 |
| many equivalent concrete states | quotient/canonicalization | E02/E04 historical |
| symmetry | canonical representative | E04 historical |
| dominated states | verified partial-order pruning | E06 historical + Pareto compiler E08 |
| poor coordinates | derived feature/invariant | E07 historical |
| bad solver composition | search over reasoning programs | E05 historical |
| too many possible new ideas | ML/heuristic proposal ranking, exact acceptance | E03–E08 lesson |

No single optimization should be called “the reasoner”. The engine should assemble a query-specific reasoning program from verified skills.

## A future reasoning skill in SOP terms

A persistent skill should be representable conceptually as:

```text
@skill-applicability rule
... conditions under which the transformation is sound ...

@skill-transformation rule
... derived relation / rewrite / decomposition ...

@skill-certificate facts
... checker kind, source hashes, proof obligations ...

@skill-cost facts
... distributions where the skill helped or hurt ...
```

The current runtime stores this metadata as `.mjs` objects rather than executable `@skill` blocks. This separation is intentional until the skill language is stable.

## How genuinely new reasoning algorithms could emerge

The desired loop is not “train a model to output answers”. It is:

```text
query failures / expensive traces
 -> propose a distinction, lemma, invariant, representation or program
 -> verify semantic contract
 -> measure cost
 -> compile
 -> reuse
 -> receive counterexamples
 -> specialize or replace
```

Examples of increasingly strong discoveries:

- a repeated proof fragment becomes a lemma;
- several histories become one quotient state because all relevant continuations agree;
- a Pareto relation proves that some frontier states can be pruned;
- a derived coordinate makes the pruning theorem true;
- independent subgraphs suggest separator decomposition;
- a sequence of primitives becomes a new named algorithmic skill.

The important architectural distinction is that a discovery changes the **language in which later reasoning happens**. A promoted skill is inspectable and persistent; it need not remain encoded only in neural weights.

## ML role

ML is most defensible where the candidate space is large:

```text
p(candidate | goal, theory, failed proofs, traces, skill library)
```

A model may prioritize which fact, rule, discriminator, invariant grammar, decomposition or skill composition to check. A bad ranking wastes time. It must not silently create a false theorem.

E03 is the permanent warning: roughly 98% quotient-state classification still failed exact compositional reasoning. Therefore approximate state prediction should not be allowed to prune exact search without a checker.

## Theory growth and forgetting

Not every discovery should become global. The skill store needs utility and scope.

A simple utility signal is expected saved reasoning cost over matched tasks minus verification/application overhead. Rare local lemmas may stay task-local. Repeatedly useful abstractions can be promoted to broader structural templates after re-verification.

Skills can also be deprecated or quarantined when:

- schemas change;
- applicability cannot be re-established;
- counterexamples appear;
- a stronger skill subsumes them;
- their cost model becomes consistently negative.

This is the algorithmic analogue of consolidation and forgetting: preserve semantic evidence, but remove low-value skills from active search indexes rather than deleting the research history.

## Separation from natural-language interpretation

Facts extracted from text can be wrong. The reasoning engine guarantees conclusions relative to supplied premises and declared semantics; it does not certify that an LLM correctly interpreted a book or document. SOP integration should retain source spans and confidence/provenance so that semantic extraction and logical execution can be evaluated separately.
