# Architecture and algorithmic rationale

## What the runtime does

The dataflow is: SOP text or typed fact wires → validated relational IR → query dependency slice → optional verified compilation → SCC schedule → indexed seminaive evaluation → answer set and optional witness DAG. A learning layer selects execution plans; it is not consulted to determine whether a tuple is true.

| Module | Responsibility |
|---|---|
| `parser.mjs`, `terms.mjs` | Syntax, typed values, safety and arity checks |
| `database.mjs` | Interned symbols, distinct tuple storage, lazily maintained hash indexes |
| `analyze.mjs` | Dependency slicing and iterative, linear-time SCC scheduling |
| `join.mjs` | Pure joins, filters, closed-world anti-joins, existential factoring and budgets |
| `engine.mjs` | SCC fixpoints, delta evaluation, compilation guards and result statuses |
| `magic.mjs` | Standard positive demand/adornment transformation |
| `skills.mjs`, `learn.mjs` | Verified join-plan permutations, rule inlining, empirical policy selection and neural proposal ranker |
| `dominance.mjs` | Guarded compilation of explicit 2D Pareto rules into a sort/sweep |
| `proof.mjs` | One witness DAG and independent local derivation replay |
| `session.mjs`, `sop-adapter.mjs` | Snapshot/epoch isolation, cached results, forks and SOP boundary |
| `reference.mjs` | Separate synchronous nested-loop evaluator used only as an oracle/control |

## Where work is removed

**Delta evaluation** applies recursive rules to newly obtained tuples rather than repeatedly joining only old information. Duplicates still collapse into the same tuple identity. This prevents repeated proof trees from becoming repeated stored answers, but does not count all alternative proofs.

**Binding indexes** turn a bound subgoal into a lookup. Index construction is not free: the benchmark records index-build rows separately, and reports cold loading as well as query time. A million-fact query that performs only 41 tuple probes still reads and indexes the corpus.

**Goal specialization** propagates query bindings into recursive rules using adornments and demand predicates. The implementation supports positive, function-free programs. If the relevant slice uses `NONE`, it conservatively falls back to ordinary stratified evaluation. The implementation is not a new discovery; it materializes an established technique behind a checkable interface.

**Existential factoring** separates disconnected body components that do not contribute any output variable. Such a component needs one witness, not a Cartesian product with every answer. A query returning both components cannot use this reduction. The output-Cartesian control demonstrates that distinction.

**Rule inlining** substitutes one unique nonrecursive positive definition, with capture-avoiding fresh variables and no base facts for that predicate. The compiler refuses cases outside these guards. The expansion retains the original definition fingerprint. It is a safe compilation template, not unrestricted lemma invention.

**Pareto compilation** recognizes an explicit complete pairwise definition and replaces its quadratic candidate join with a sort/sweep. Both strictness branches, grouping, objective directions, variable mapping and extensional-source conditions are checked. This integrates the relational dominance concept from E06 into a SOP reasoner. It does not justify dominance for an arbitrary domain whose transition semantics have not been provided.

## Learning changes plans, not answers

`learnPlans` searches join permutations on training instances. The certificate checker verifies that the literal multiset is unchanged. `learnExecutionPolicy` selects among safe execution configurations using integer tuple-probe counts. Its serialized policy includes the rule-schema hash and query. A changed schema/query causes fallback instead of silent policy reuse.

The neural `Ranker` predicts the cost of candidate plans. It cannot inject rules, discard tuples or change budgets through its policy interface. Its quality can affect ranking efficiency. Completion under an arbitrary bad policy is not guaranteed under a fixed budget; the runtime instead returns `INCOMPLETE`.

The first benchmark enabled every optimization. It exposed genuine regressions on dense/nonlinear/mutually recursive workloads. The follow-up experiment selects a policy on training instances only and retains the original fixed-policy results. This is not a universal non-regression theorem: a policy can still make a bad cost prediction on a different distribution.

## Trusted boundary

Trusted components are the supplied facts/rules as premises, the parser, the relational semantics, constructive optimization templates and local proof checker. Their implementation is tested but not formally verified in a proof assistant. Neural scores and empirical timing/cost models are untrusted hints. A schema/data fingerprint binds evidence to its source snapshot; it is not a digital signature or protection against an attacker changing both software and data.

No `eval`, `Function`, arbitrary imported user code or external calls occur inside SOP rules. Resource budgets bound inference work, not parsing time or OS memory allocation. Hostile unbounded input files still require a process/container memory limit.

## Real limits

An answer relation can itself have quadratic or worse cardinality; no optimizer can emit all its tuples in sub-output-size time. Dense recursion and cyclic joins remain hard. The engine is single-process, in-memory JavaScript. It has no disk spill, distributed joins, specialized triejoin, incremental deletion algorithm, approximate reasoning, external retrieval, full Prolog term unification or complete proof enumeration.

The current checkpoint demonstrates a coherent execution substrate and safe reuse of reasoning plans. It does not demonstrate a new general ML architecture or algorithms unknown to the designer of the transformation language.

## E09: online reasoning versus offline dreaming

The runtime now has a second control loop above exact query execution:

```text
facts/rules/query
    -> promoted skill lookup
    -> exact reason()
    -> answer/status/proof + episode
                         |
                         v
                  EpisodeJournal
                         |
                 batch / idle trigger
                         v
                      Dreamer
             / policy / plan / lemma \
                         |
       certificate + exact replay + held-out cost
                         |
                  VerifiedSkillStore
                         |
              promote / reject / quarantine
```

This separation is deliberate. A normal query should not search an open-ended algorithm space before answering. It uses verified knowledge and records evidence. Expensive synthesis happens when enough episodes exist or repeated failures justify it.

The first integrated semantic discovery is a redundant Horn composition lemma. It is a true new rule object derived from old rules, but its proof schema is supplied by the implementation. `engine.mjs` accepts a `lemmaBundle` only after reconstructive verification. The original rules remain available, so the lemma accelerates derivation but does not become an unproved pruning assumption.

Future quotient, dominance, invariant and representation discoveries should enter through the same lifecycle, each with a semantic contract appropriate to what it preserves (answer set, optimum, multiplicity, witness set, probability, etc.).

## E10 unified invention layer

The architecture now exposes `inventors.mjs` beside the exact kernel. Inventors do not have direct authority over truth. They emit candidates into the Dreamer lifecycle.

```text
SOP Program / Episodes
        |
        v
     Dreamer
        |
        +-- quotient proposal
        +-- decomposition proposal
        +-- dominance proposal
        +-- demand representation proposal
        +-- Horn lemma proposal
        +-- empirical invariant (advisory only)
        |
        v
 exact replay / structural verification
        |
        v
 VerifiedSkillStore
        |
        v
 SkillComposer
        |
        v
 deployment-plan
        |
        v
 exact reason()
```

`SkillComposer` is intentionally outside the semantic kernel. It may optimize work/depth but every candidate subset is rerun against exact reference answers before deployment.
