# SOP-R1: implemented relational syntax

## Meaning of a wire

A wire is a relation of variable bindings. `@name` declares its unique name. `USE $name` consumes that relation, with positional arguments. Logical variables use `?name`; constants are case-sensitive strings, booleans or safe integers. A new `@` block, `END`, or end-of-file closes a block. Keywords are uppercase; block types are lowercase or case-insensitive.

A fact wire is a source container, not a callable predicate. Its `FACT` lines populate named relations. ALL and ANY wires create callable derived relations. A rule wire materializes its `THEN` relation. A query wire returns its `GIVES` columns.

## Facts and sources

```text
@observations facts
SOURCE "document://report#section-4"
FACT depends moduleA moduleB
FACT author "Ada Lovelace" report1
FACT measured sensor7 42
FACT accepted claim3 true
FACT NOT accepted claim8 true
```

Bare constants can contain letters, digits, `_`, `.`, `:`, `/`, and `-`, but start with a letter or underscore. Quote constants with spaces, `#`, reserved-looking characters or a leading number when they must remain strings. Double-quoted strings use JSON escapes. `1`, `"1"`, and `true` are different values. Integers outside the JavaScript safe-integer range are rejected rather than silently rounded. There are no floats or arithmetic term constructors in this profile.

`SOURCE` assigns source metadata to subsequent facts in that fact wire. The parser retains the fact's wire name and line. Duplicate ground facts are one logical fact. The current provenance mode retains one source/witness, not every alternative source for a duplicate.

## Rules, AND, OR and filters

```text
@direct rule
WHEN depends ?x ?y
THEN reaches ?x ?y

@recursive rule
WHEN reaches ?x ?y
AND depends ?y ?z
THEN reaches ?x ?z

@authorized rule
WHEN employee ?person
AND clearance ?person
OR
MATCH contractor ?person
AND sponsor ?person
THEN authorized ?person
```

A branch is a conjunction of its condition lines. `OR` starts another branch; each branch becomes one Horn rule with the same head. `OR relation arguments` is a compact branch start. For complex expressions, use intermediate ALL/ANY wires rather than precedence-sensitive parentheses.

`MATCH`, `WHEN`, `AND`, and `USE` introduce positive relational conditions. `USE $wire` is the normal readable form for a wire reference. `$wire` is also accepted where a relation name is expected. `TEST` supports `==`, `!=`, `<`, `<=`, `>`, `>=`; ordered comparisons require integers. `TEST` filters already bound values and never generates new values.

## ALL and ANY wires

```text
@employeeRoute all
GIVES ?person
MATCH employee ?person
MATCH clearance ?person

@contractorRoute all
GIVES ?person
MATCH contractor ?person
MATCH sponsor ?person

@eligible any
GIVES ?person
USE $employeeRoute ?person
USE $contractorRoute ?person

@answer query
GIVES ?person
USE $eligible ?person
```

Each new `MATCH`/`USE` line in an ANY wire starts an alternative; `AND` explicitly continues the current alternative. `GIVES` is mandatory for ALL/ANY. It may project out existential variables. Projection uses set semantics.

## Explicit negation versus absence

```text
@rejected query
GIVES ?claim
MATCH NOT accepted ?claim true

@notRecorded query
GIVES ?claim
MATCH claim ?claim
NONE accepted ?claim true
```

The first asks for an explicit negative fact. The second uses closed-world absence in the current completed relation. They are deliberately different. Positive and explicit-negative facts may coexist; the kernel does not infer arbitrary statements from this conflict. This alone is not an implementation of a general paraconsistent logic.

`NONE` requires all its variables to be bound by positive conditions in the same branch. The signed predicate graph must be stratified: no cycle may contain a negative edge. Negative recursion is rejected before execution. Positive mutual recursion is supported.

## Queries

A query can have several positive conditions, filters, NONE, and OR branches. If `GIVES` is omitted, the positive variables of the first branch are returned in occurrence order; all returned variables must be positively bound in every branch. An explicit empty `GIVES` creates a Boolean/existence query. A successful zero-column query returns `[[]]`; a completed false query returns `[]`.

The CLI selects a query by wire name. Its `count` is the number of distinct output tuples, **not** the number of proofs, paths or satisfying assignments of an arbitrary external problem.

## Safety and restrictions

All head/output variables and all negative/filter variables must occur in a positive body atom in that branch. Arity must agree everywhere, even for empty relations. Wire names must be unique. Anonymous variables, nested terms, cut, arbitrary JavaScript, network/file calls inside rules and unbounded arithmetic recursion are not accepted.

This restriction is intentional: for a finite set of facts and function-free rules, the active-domain set of possible tuples is finite. The fixpoint is therefore well-defined and terminates mathematically, although it may exceed the configured execution budget.
