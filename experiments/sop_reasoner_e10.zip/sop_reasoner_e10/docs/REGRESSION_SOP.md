# SOP-native property regression

Every `regression/cases/*.sop` file is both valid SOP input and executable scientific memory. `#%` comments are ignored by the reasoner and consumed by `tools/sop-regression.mjs`.

## Core directives

```text
#% TEST "property"
#% QUERY "q"
#% OPTIONS {"demand":false}
#% COMPARE_REFERENCE true
#% EXPECT_COUNT 3
#% EXPECT_CERTIFICATE "..."
#% FORBID_CERTIFICATE "..."
#% BASELINE_OPTIONS {...}
#% EXPECT_WORK_RATIO_LE 0.5
```

## Dreaming directives

```text
#% DREAM true
#% DREAM_REPEAT 3
#% DREAM_POLICY false
#% DREAM_JOINS false
#% DREAM_LEMMAS false
#% DREAM_INVENTORS ["quotient","decomposition"]
#% DREAM_EXPECT_FAMILY "quotient"
#% DREAM_EXPECT_ADVISORY 1
#% DREAM_COMPOSE true
#% DREAM_EXPECT_DEPLOYMENT true
```

Available inventor labels in the harness are `quotient`, `decomposition`, `dominance`, `representation`, and `invariant`. Lemmas retain the separate `DREAM_LEMMAS` switch because their constructive proof path predates the generic execution-fragment interface.

## Scientific policy

1. Exact answer preservation is checked before performance.
2. `INCOMPLETE` is never treated as false.
3. A negative/refusal test is permanent evidence, not an inconvenience.
4. Deterministic operation counters are preferred to tiny wall-time differences.
5. A discovered empirical invariant may be retained as advisory knowledge without gaining pruning authority.
6. `make regression` is the minimum non-regression gate; `make reproduce` reruns all current benchmark phases including E10.
