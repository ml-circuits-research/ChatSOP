# Cumulative research log — E00 through E10

## Evidence policy

The original E00–E07 archive is preserved unchanged with its SHA-256 in `history/source_manifest.json`. Readable reports and results are in `history/records/`. Those records contain historical observations and interpretations; new results below do not retroactively turn earlier finite tests into general proofs. Precise runtime guarantees are in `SEMANTICS_AND_PROOFS.md`.

| Stage | Research object | Lasting result/limitation |
|---|---|---|
| E00 | Selectable algebraic worlds and learned local factors | Discrete execution can repair compositional drift; finite beta is not the tropical limit |
| E01 | Latent finite algebra and exactification | Global consistency helps, but tiny symbolic search is a strong baseline; jointly learning symbols/operators is fragile |
| E02 | Behavioral quotients for exact counting | Small quotients can replace enormous prefix trees; this was principally symbolic automata learning |
| E03 | MLP/tree quotient proposals + CEGIS | High classification accuracy did not establish an exact quotient on the largest case |
| E04 | Verified reusable reasoning skills | Several classical shortcuts can be rediscovered within a supplied language; neural guidance was not clearly necessary |
| E05 | Composition of #SAT primitives | Useful compositions emerged; a training-selected subsumption option slightly hurt held-out cost |
| E06 | Dominance relation synthesis and transfer | A role-level partial-order relation can become a reusable guarded pruning concept |
| E07 | Derived feature/invariant synthesis | Linear/quadratic guards repaired invalid pruning; grammar expansion was designer-supplied |
| E08 | SOP-native exact relational reasoner | The previous concepts now have an execution substrate and explicit boundaries |

## E08A — End-to-end relational runtime

The new implementation is all Node `.mjs`: SOP parser, exact set semantics, stratified negation, recursive SCCs, indexes, seminaive evaluation, an independent reference evaluator, witnesses, sessions and forks. The DSL supports facts/rules/queries, all/any wires, `@` outputs, `$` uses and `?` bindings.

The evaluation protocol fixes 14 workload families and three held-out seeds, plus separate small training instances. It compares scan/naive, indexed/seminaive, greedy/seminaive, a fixed verified bundle, learned permutations and an independent SQLite control where an encoding is supplied. Raw counters and answers are retained; incomplete runs remain visible.

## E08B — Regret of always enabling every optimization

Initial results showed that demand rewriting and other compilation overhead can hurt dense, nonlinear and mutually recursive workloads. Those measurements were not removed. A follow-up selects among 16 safe option combinations using training data only, then freezes the policy before constructing held-out instances.

This follow-up is explicitly marked as motivated by the initial failure. It is not an untouched preregistered confirmation. In the tested cases it selects demand for localized graph queries, existential factoring for irrelevant products, and the Pareto compiler for explicit dominance. It declines these transformations where they add work. All policies preserve exact answer sets by construction and guard checks.

## E08C — Neural proposal control

A 9-input, 12-hidden-unit neural ranker is trained on measured costs of legal three-way-join permutations, then frozen and tested on larger instances. A basic cardinality model is tested beside it. The actual results show whether neural guidance contributes beyond that heuristic; the report does not attribute classical indexing/compilation gains to ML.

## E08D — Million-fact and rule-depth tests

Stress data contain 100k and 1M edges in the same predicate, partitioned into small components. A bound query has a small answer. Loading and indexing remain linear in input size and are reported; low post-index probe counts do not imply sublinear cold ingestion. A separate 4,000-rule dependency chain test verifies that scheduling and proof-DAG traversal do not rely on the JavaScript recursion limit.

## E08E — Preservation audit

The unmodified historical archive was extracted outside the new runtime and its original unit tests executed. All 79 historical tests and 15 saved-capability checks passed. The new package retains the complete log. The default Node reproduction reruns the new suite and checks archival integrity/records, not the historical Python training code.

## Implementation corrections retained in this checkpoint

During initial validation, the SQLite triangle query used duplicate result-column names, so object-row conversion lost a column. Explicit aliases and a dedicated cross-family SQLite regression fixed the baseline; no mismatched result is reported as successful. Macro inlining was strengthened with collision-free fresh variables. Proof checking now verifies source metadata and dataset fingerprints and rejects stale evidence. SCC/proof graph traversal was made iterative to support deep rule chains. These are implementation corrections, not changes to task answers or performance thresholds.

## Conclusions warranted now

We have an executable SOP reasoning substrate with exact answers, guarded optimizations and reusable learned plans, plus concrete evidence about when those plans help or hurt. We do not yet have open-ended algorithm invention, a generally superior ML architecture, a mature Prolog replacement, or an external model-counting competition result. The next scientific question is whether a larger synthesis language can learn useful new verified rewrites beyond the current hand-supplied templates and beyond strong classical optimizers.

## E09 — Integrated dreaming, verified lemma consolidation, and SOP-native scientific regression

### Question
Can the exact SOP reasoner accumulate reusable reasoning knowledge from previous tasks without letting speculative learning corrupt truth, while preserving every earlier experimental conclusion as regression evidence?

### Implementation
E09 adds an explicit online/offline split.

- `EpisodeJournal` records query/schema/data fingerprints, completion and cost; small programs may be retained for exact replay.
- `VerifiedSkillStore` gives discoveries a lifecycle rather than treating any learned artifact as immediately trusted.
- `Dreamer` batches replayable tasks and may learn execution policies, join plans, and verified composition lemmas.
- `AdaptiveReasoner` applies only promoted schema/query-compatible skills online and journals the resulting episode.
- `lemmas.mjs` implements a first constructive lemma language: sound Horn shortcuts obtained by alpha-renamed resolution/composition of existing pure-positive rules.

A lemma is rebuilt from its producer/consumer rules during verification. Tampering, schema changes, or query mismatch invalidate reuse. Soundness alone is insufficient for promotion: the candidate must preserve exact replay and satisfy the configured held-out cost objective.

### Measured demonstration
On recursive reachability, composing the recursive rule with itself produces a longer verified jump. In the current held-out demo, this reduces fixpoint round depth dramatically while increasing raw tuple probes. This is intentionally reported as a trade-off: the skill is useful under the stated objective `candidateVisits + roundWeight * rounds`, not a universal performance win.

### Regression as scientific memory
Fourteen SOP-native cases now encode key desired properties as executable SOP programs with `#%` test comments. They protect exact fixed points, alternatives, absence semantics, incomplete budgets, non-explosion under explicit contradiction, factoring, Pareto compilation and refusal, dreaming/reuse, unavoidable Cartesian output, negation guards, selective joins and proof replay.

The historical E00–E07 archive remains immutable because several earlier claims cannot honestly be represented by the Boolean/set semantics of SOP-R1. The audit explicitly keeps E03's negative neural-quotient result and E07's negative controls.

### Lasting lesson
**Learning should be cumulative but promotion should be slow. Online reasoning uses verified skills; dreaming invents candidates from accumulated failures/traces; exact checks and regressions decide what becomes part of the future reasoning language.**

### What is still missing
Open-ended lemma/concept invention is not solved. E09's lemma constructor is designer supplied. Historical quotient, dominance, feature/invariant and representation-constructor synthesis have not yet been unified into one runtime synthesizer. The architecture for that unification is documented in `DREAMING_AND_CONSOLIDATION.md` and `SOP_REASONING_AND_INVENTION.md`.

## E10 — Unified inventors, quotient execution and verified skill composition

### Question
Can one persistent Dreamer manage heterogeneous reasoning improvements, transfer them from small SOP worlds to a much larger environment, and choose a safe subset for deployment without regressing E00–E09 evidence?

### Implementation
E10 adds `inventors.mjs` and a common proposal/verification interface. The integrated families are:

- quotient/canonicalization of existential coordinates local to one literal;
- independent existential decomposition;
- guarded Pareto dominance recognition;
- query-demand representation specialization;
- observed functional dependencies as advisory-only hypotheses;
- existing E09 Horn lemma synthesis under the same skill-store lifecycle.

`SkillComposer` separates “promoted/trusted” from “deployed”. It evaluates subsets of promoted exact skills, checks answers against the reference evaluator and promotes only the best subset under the declared deterministic cost objective.

### New runtime capability
A narrow but real quotient is now part of the `.mjs` kernel. If a variable appears in exactly one positive atom, is absent from the rule head and is unused by all other conditions, rows differing only in that coordinate are interchangeable existential witnesses under set semantics. R15 protects both exactness and the work reduction; a Node negative guard test ensures live variables are never erased.

### SOP-native scientific memory
The property suite grows from 14 to 20 cases. R16–R18 require the Dreamer itself to discover quotient, decomposition and dominance skills. R19 protects the trust boundary for empirical invariants. R20 requires exact skill composition and a promoted deployment plan.

### Large held-out environment
The E10 world contains exactly 106,800 facts in one SOP program. Skills are learned on three smaller worlds sharing only the rule schema, then frozen. On the large world, reachability without demand hits the fixed work budget while the learned deployment completes; quotient, decomposition and Pareto deployments all complete exactly with large reductions in tuple probes. Input parsing/indexing remains a separate cost.

### Lasting lesson
The architecture should accumulate many candidate “ways of thinking”, but deployment is task/objective-specific. Correctness certification and performance selection are separate gates. Empirical observations may seed later invention but must not silently become pruning rules.

### Remaining boundary
E10 still does not constitute open-ended algorithm invention. Feature grammar expansion, arbitrary dominance synthesis and general quotient discovery remain historical prototypes until ported as verified Dreamer plugins.
