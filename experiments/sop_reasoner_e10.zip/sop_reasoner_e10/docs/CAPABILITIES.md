# Cumulative capability matrix — E00 through E10

“Preserved” means original source/results remain in the immutable historical archive. “Integrated” means executable support in the current Node SOP runtime.

| Stage | Historical result | Preserved | Current integration |
|---|---|---|---|
| E00 | Selectable algebraic worlds, exactification, thermal-limit correction | yes | not a general semiring runtime |
| E01 | Hidden finite algebra; symbolic baseline; joint learning fragile | yes | not ported |
| E02 | Exact behavioral quotients | yes | E10 adds a narrow verified local-variable quotient; general L* not ported |
| E03 | Neural quotient proposals fail to become exact at largest case | yes, negative result required | approximate merging is forbidden as truth |
| E04 | Verified shortcuts/DP/symmetry/bounds | yes | certificate/store architecture |
| E05 | Algorithm composition and overfit control | yes | `SkillComposer` now integrated for relational skills |
| E06 | Dominance relation synthesis/transfer/specialization | yes | guarded Pareto recognition/compilation; arbitrary relation synthesis not ported |
| E07 | Linear/quadratic feature invention and negative controls | yes | generic feature invention not yet integrated |
| E08 | Exact SOP relational reasoner | yes/current | full current kernel |
| E09 | Offline dreaming and constructive Horn lemma synthesis | yes/current | integrated |
| E10 | Unified inventors, local quotient, advisory invariants, composition, large transfer | current | integrated |

## Current trust model

- **Exact runtime:** fixed-point relational semantics, stratified absence, explicit negation, proof witnesses, budgets.
- **Certified transforms:** demand specialization, factoring, local quotient, guarded Pareto, constructive Horn lemmas, verified join/policy artifacts.
- **Empirical advisory:** observed invariants/functional dependencies; never deployed as proof/pruning.
- **Historical only:** open-ended quotient learner, generic feature invention, representation-constructor search, general dominance synthesis, latent algebra learning.

## Regression layers

1. Node unit/differential/guard/proof/update tests.
2. SOP-native property programs under `regression/cases`.
3. Independent reference and SQLite controls where available.
4. Historical E00–E07 archive hash and saved-result audit; original 79 historical tests were rerun before packaging E09/E10.
5. E10 transfer benchmark from small worlds to a 106,800-fact held-out world.

Test count is evidence only for covered properties, not proof of general intelligence or open-ended invention.
