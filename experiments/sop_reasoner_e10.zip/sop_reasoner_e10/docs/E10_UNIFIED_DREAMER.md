# E10 — Unified Dreamer for verified reasoning skills

## Purpose

E10 turns the previous sequence of experiments into one cumulative architecture. Online query answering and offline invention are deliberately separated.

Online reasoning must be exact. It may use only promoted, schema/query-compatible skills. Offline dreaming may be speculative: it can propose lemmas, quotients, decompositions, dominance compilation, query specialization and empirical invariants. A proposal is not trusted because a model or heuristic suggested it. It must pass the appropriate verification gate.

The lifecycle is:

```text
query episodes
    ↓
EpisodeJournal
    ↓
Dreamer
    ├─ LemmaInventor
    ├─ QuotientInventor
    ├─ DecompositionInventor
    ├─ DominanceInventor
    ├─ RepresentationInventor
    └─ InvariantInventor (advisory only)
    ↓
exact replay / constructive certificate / held-out cost
    ↓
VerifiedSkillStore
    ↓
SkillComposer
    ↓
verified deployment plan
    ↓
AdaptiveReasoner
```

## Trust classes

### Certified execution skills

A certified execution skill may change how a query is evaluated only when its semantic preconditions are satisfied. Current examples:

- Horn composition lemma: a redundant consequence reconstructed from producer/consumer rules;
- quotient: a variable occurring in one positive literal only, never in the head/continuation, may be existentially projected under set semantics;
- decomposition: a body component sharing no variable with live/head components may be solved as an existence condition;
- Pareto dominance: only the fully guarded two-objective anti-join template is compiled;
- demand specialization: the existing exact magic-style query specialization.

### Empirical advisory knowledge

Some discoveries are useful hypotheses but not universal proofs. E10 stores functional dependencies observed over all replay datasets as `advisory-only`. They are visible to future inventors, but `VerifiedSkillStore.promoted()` never turns them into pruning filters. This boundary encodes the E03 lesson: high empirical accuracy is not enough for exact compositional reasoning.

## Quotient implemented in E10

For a rule such as:

```text
WHEN selected ?x
AND observation ?x ?detail
THEN visible ?x
```

`?detail` occurs nowhere else and cannot affect the head. Under set-answer semantics all rows with the same live coordinates are equivalent witnesses. The runtime may therefore inspect one representative instead of every detail row.

The guard is syntactic and complete for this narrow transformation. If the eliminated variable appears in the head, another literal, a test or a negative condition, the quotient is not offered.

## Skill composition

A promoted skill is not necessarily a good deployment choice in every task. E09 already showed that a lemma can reduce fixpoint depth while increasing tuple probes. E10 therefore adds `SkillComposer`.

The composer enumerates subsets of already-promoted exact skills, replays each subset, checks the exact answer set, and scores the declared objective:

```text
candidateVisits + roundWeight * rounds
```

Only the best exact subset becomes a `deployment-plan`. This prevents the common failure mode “enable every optimization because each passed separately”.

## E10 transfer experiment

The unified benchmark uses the same SOP schema in three small training worlds and one large held-out world. The large world contains exactly 106,800 extensional facts.

The Dreamer is run only on the small worlds. The resulting skill store and deployment plans are frozen. The large world is then evaluated without re-learning.

Queries test four different mechanisms:

- recursive reachability: demand specialization;
- observation projection: local quotient;
- independent existence: decomposition/factorization;
- Pareto anti-join: dominance compilation.

Empirical invariants are also retained in the library but are not allowed to influence truth.

## What E10 does not prove

E10 is not open-ended algorithm invention. Several inventors expose known exact transformation families. It demonstrates that a single dreaming/store/composition architecture can discover, verify, retain, select and transfer different types of reasoning skills without sacrificing exactness.

Historical E06/E07 experiments on relation synthesis and derived-feature invention remain relevant targets for future plugins. They are not silently re-labelled as integrated capabilities.
