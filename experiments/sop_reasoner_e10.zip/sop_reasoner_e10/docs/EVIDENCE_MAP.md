# Evidence map: experiment → architectural claim → regression

| Stage | Claim tested | Evidence retained | Executable guard |
|---|---|---|---|
| E00 | algebra/exactification | projection helps; beta=64 raw criterion failed | immutable archive |
| E01 | hidden algebra discovery | consolidation helps; symbolic search strong; joint encoder fragile | immutable archive |
| E02 | behavioral quotient | small exact quotient replaces large prefix tree | archive + E10 narrow quotient analogy |
| E03 | direct neural quotient | **negative:** ~98% accuracy was not exact | history audit |
| E04 | verified skills | classical shortcuts rediscovered in supplied language | certificates + R06/R07 |
| E05 | algorithm composition | useful composition; subsumption overfit retained | history + E10 `SkillComposer` |
| E06 | dominance invention/transfer | synthesized relation and adversarial specialization | Pareto compiler guards R07/R08; general synthesis historical |
| E07 | feature invention | linear/quadratic derived feature; hash negative control | historical audit |
| E08 | exact SOP reasoner | diverse workloads, reference/SQLite, million-fact stress | current tests/benchmarks |
| E09 | dreaming/lemma consolidation | constructive Horn shortcut and persistent lifecycle | dream tests + R09 |
| E10 | heterogeneous dreaming and deployment | quotient/decomposition/dominance discovery; advisory boundary; 106,800-fact transfer | R15–R20 + `results/e10.json` |

## SOP-native regression cases

R01–R14 retain the E09 scientific-memory suite. E10 adds:

- **R15** exact local quotient and deterministic work reduction;
- **R16** Dreamer discovers/promotes quotient rather than manual activation;
- **R17** Dreamer discovers independent existential decomposition;
- **R18** Dreamer discovers guarded dominance compilation;
- **R19** empirical invariant remains advisory and cannot silently prune;
- **R20** promoted skills are replay-composed before a deployment plan is trusted.

The original Count/Tropical/Parity/Det experiments, general L* learner, generic feature grammar and arbitrary dominance synthesis still require their historical implementations. Boolean SOP tests do not substitute for them.
