# E08 benchmark protocol and interpretation

## Experiments and independence

The main suite uses fourteen deterministic generators. Training size is 24 with seeds 0/1/2. Held-out test seeds are 101/202/303; sizes are fixed in `bench/config.json`. Generators write actual `.sop` files, so both parsing and reasoning are exercised. Expected outputs are computed by procedural oracles that do not call the reasoner. Small differential tests also use a separate nested-loop fixed-point evaluator. SQLite is a third, independently encoded check for the supported families.

The test samples are synthetic and selected to expose different execution behaviors. They are not a random sample of real enterprise workloads. Three seeds are useful repeatability checks, not a statistical demonstration of universal superiority.

| Family | Behavior exposed | Meaning of the size parameter |
|---|---|---|
| disconnected | Bound goal in disconnected graphs | Graph vertices |
| deep_recursion | Long recursive derivations | Chain vertices |
| dense_cycle | Cyclic closure and duplicate derivations | Graph vertices |
| nonlinear_recursion | A rule with more than one recursive atom | Graph vertices |
| selective_join | Strongly selective filter hidden by poor source ordering | Candidate keys |
| existential | Independent existence condition whose witnesses need not be multiplied | Relation rows |
| policy | Stratified absence and policy joins | Candidate people |
| temporal | Numeric comparisons and shared keys | Temporal records |
| triangles | Cyclic multiway join | Graph vertices |
| mutual_recursion | Predicate SCCs and repeated propagation | Graph vertices |
| rule_heavy | Irrelevant rules and schema-change fallback | Unrelated rule count |
| or_evidence | Multiple alternatives and deduplication | Candidate keys |
| output_cartesian | Output that really is quadratic and cannot be factored away | Each product relation size |
| pareto | Relational dominance followed by an anti-join | Input label count |

## Comparators

`scan_naive` is a pedagogical full-scan/full-fixpoint baseline, not the principal performance competitor. `indexed_semi` adds indexes and seminaive deltas but keeps rule source order. `greedy_semi` is the stronger internal baseline, adding cardinality-based join ordering. `verified` enables the supported safe transformations together. `learned` uses training-selected join permutations; it must not be confused with the later adaptive option selector.

SQLite uses hand-written, family-specific SQL and its own cold-loaded indexed database. Its load, solve and total times are reported separately in raw results. It does not parse SOP or synthesize these encodings. Conversely, SQLite is a mature native engine, not a JavaScript implementation. These asymmetries are kept explicit rather than interpreting every time ratio as architectural superiority.

A main run counts as solved only if COMPLETE and exactly equal to the independent answer set. The scan budget is 500k tuple probes; other main engine budgets are 5M. A limit hit is INCOMPLETE, not false and not a fabricated speedup. Unsupported comparator encodings are NOT_APPLICABLE, not failed logical answers.

## Adaptive follow-up and learning

After observing overhead from enabling all transformations, a separate follow-up selected among sixteen combinations of demand specialization, existential factoring, inlining and Pareto compilation. The selected policy minimizes work on small training instances, with stable ties. Larger test inputs are evaluated only after profiles are frozen. The experimental *question* was motivated by earlier test behavior; the profile parameters were not fitted to the new test labels. This is exploratory evidence, not an untouched preregistered study.

The all-JavaScript MLP control is distinct: 9 features, 12 tanh hidden units, three fixed model seeds. It ranks six legal permutations of three-way joins. Training uses 180 measured cost examples. Test compares its ranking with an analytical cardinality heuristic, lexical order, and the exact expected rank of random ordering. The current tie with the heuristic is a retained negative result about the necessity of neural guidance.

## Accounting

`candidateVisits` measures attempted tuples examined in joins/guards; it is not a full instruction or CPU-cycle counter. `indexBuildRows` is separate. A Pareto sort is not free just because it has few tuple probes; whole-call timing captures it. Output construction and sorting may dominate unavoidable large-answer workloads.

Main wall time includes loading a fresh relation store, compile/evaluate and output decoding/sorting. Parsing is separate. Adaptive training cost, policy trial counts and MLP training time are retained; a speedup after training should be amortized over enough later queries before being interpreted as a deployment saving. Fresh model training and validation are included in `make reproduce`.

The million-fact experiment uses one edge predicate and many eight-node components. It demonstrates input volume plus query localization. It does not establish efficient arbitrary all-pairs closure or difficult unstructured inference over a million facts. All million rows still have to be parsed, loaded and indexed in the cold experiment. Repeated identical query caching is tested separately and is not substituted for these cold measurements.

## Reproduction

Data are frozen against deterministic regeneration; raw SHA-256 hashes appear in `data/MANIFEST.json` and stress results. `tools/verify-clean.mjs` starts without any generated data or trained models and compares all 87 data/manifest files, 16 plan/model files and the semantic-result fingerprint. Wall times and RSS are deliberately not expected to be byte-identical. See `VERIFICATION.md`.
