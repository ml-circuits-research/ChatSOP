# Public API

All imports are from `src/index.mjs`. Modules have no runtime dependencies beyond Node built-ins.

## Parsing and execution

`parseSOP(text, source)` returns validated `{facts,rules,queries,arities}`. `loadSOP(path)` performs line-by-line input reading. `reason(program, queryName, options)` creates a fresh evaluation. Treat the supplied program and returned runtime database as immutable during a call. Callers should use Session or the typed adapter for reuse; each new evaluation constructs a clean relation store from its input premises.

Important options are `mode: 'semi'|'naive'`, `indexed`, `join: 'source'|'greedy'`, `factor`, `demand`, `fuse`, `dominance`, `provenance`, `bundle` (join plans), `policy` (execution strategy), `maxWork`, `maxDerived`, and `maxMs`. Default budgets are 100M tuple probes, 2M new tuples and 60 seconds of solve work. Parsing/loading are reported separately and are not covered by the solve timer.

The result contains `status`, `complete`, `stopReason`, `columns`, `rows`, `count`, `stats` and `plan`. `publicResult(result)` removes the internal relation store and executed-rule IR for JSON output. `candidateVisits` counts attempted input tuples at joins and guards, not all CPU operations. `indexBuildRows` accounts for rows visited to construct lookup structures. Compare whole-call wall time, loading, output cardinality and memory as well as these counters.

## Learning and reuse

`learnPlans(trainingPrograms, queryName)` synthesizes per-rule join permutations. All training programs must have the same rule-schema fingerprint. `verifyPlanBundle` checks the schema and each permutation. `SkillLibrary` stores and serializes accepted bundles.

`learnExecutionPolicy(trainingPrograms, queryName)` compares the 16 combinations of demand specialization, existential factoring, safe inlining and Pareto compilation. It minimizes training tuple probes, breaking ties by stable candidate order. The result is a plain serializable policy. `reason(program, queryName, {policy})` checks its schema/query and only accepts allowlisted execution options. Stale policies fall back; untrusted extra fields are rejected.

A caller must separate training/validation from held-out evaluation. The API cannot determine whether caller-supplied training data were leaked from a test set. The shipped benchmark performs that separation explicitly.

`Ranker` is a small tanh network with `fit`, `predict` and `fromJSON`. It can score candidate plans. Its scalar output is never used as a logical assertion. `bench/neural.mjs` shows training, model freezing and comparison against an analytical heuristic.

## Session, forks and evidence

```js
const session = new Session(program);
const result = session.query('answer', { provenance: true, policy });
const copy = session.fork();
copy.assertFact('edge', ['beta', 'newNode'], 'update://1');
copy.retractFact('edge', ['alpha', 'beta']);
console.log(copy.validateSnapshot(result.snapshot)); // STALE: another session
```

Repeated identical queries in one unchanged session reuse their completed result. `assertFact`/`retractFact` invalidate caches. A fork currently copies the logical program rather than sharing a persistent storage engine. Updates are deliberately conservative and may be expensive for large databases.

`explain(result, answerIndex, {maxNodes})` exports one witness. `verifyExplanation(program, result, evidence)` checks it against its source/evaluation snapshot. Evidence is optional: keeping it for a large materialized closure adds memory cost. See the precise limits in `SEMANTICS_AND_PROOFS.md`.

## Typed SOP adapter

```js
const interpreter = new SOPReasonerInterpreter(`
@answer query
GIVES ?to
MATCH edge alpha ?to
`, {
  factWires: [{
    name: 'network', source: 'book://chapter-2',
    facts: [{ relation: 'edge', values: ['alpha', 'beta'], line: 17 }]
  }]
});
const output = interpreter.evaluate({
  query: 'answer', provenance: true,
  budget: { maxWork: 100000, maxDerived: 10000 }
});
```

The adapter returns `outputWire`, a list of binding objects, status, epoch, cost metadata and optional evidence. It does not call an LLM, fetch external facts, or parse arbitrary natural language. Those remain separate interpreters with their own validation obligations.

## E09 dreaming API

### `EpisodeJournal`

```js
const journal = new EpisodeJournal({capturePrograms:true, maxFacts:10000});
```

Records schema/data fingerprints, query, completion and deterministic work counters. Small programs can be retained for exact replay; large corpora should be replayed from their canonical dataset rather than duplicated into the journal.

### `VerifiedSkillStore`

Persistent lifecycle records for candidates and promoted skills. `store.promoted(program, query)` returns only exact schema/query matches in the current implementation.

### `Dreamer`

```js
const dreamer = new Dreamer({store});
const report = dreamer.consolidate(trainingPrograms, 'answer', {
  learnPolicy: true,
  learnJoins: true,
  learnLemmas: true
});
```

A candidate lemma must have a reconstructible Horn-resolution certificate, exact replay and sufficient cost benefit before promotion.

### `AdaptiveReasoner`

```js
const adaptive = new AdaptiveReasoner({store, journal});
const result = adaptive.run(program, 'answer');
// later, when enough replayable episodes exist:
const reports = adaptive.dream();
```

Online execution never deploys `candidate` or `rejected` records.

### Lemma bundle

`reason(program, query, {lemmaBundle})` accepts `verified-lemma-bundle-v1`. The engine calls `verifyLemmaBundle()` before use. A schema change, query mismatch or edited lemma/certificate causes rejection rather than fallback to unverified execution.
