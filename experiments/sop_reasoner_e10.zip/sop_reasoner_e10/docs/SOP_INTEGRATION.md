# Concrete integration into a SOP Lang environment

## Placement

The reasoner is a bounded interpreter for a declarative subcircuit, not a replacement for SOP Lang. A surrounding agent can obtain facts from text, databases or other interpreters. Once those facts have explicit relation schemas and sources, SOP-R1 evaluates fact/rule/query wires and emits answer bindings with evidence and a completion status.

An ordinary acyclic SOP scheduler should treat each mutually recursive rule SCC as one fixed-point computation. It must not attempt to topologically execute every recursive rule once. In this implementation `schedule()` performs that SCC grouping. The external output wire is sealed only after completion; internally its relation may acquire deltas until the fixpoint is reached.

## Example with evidence and alternatives

```text
@sourceFacts facts
SOURCE "research://paper-A#claims"
FACT supports observation1 premise1
FACT implies premise1 conclusion1
FACT implies conclusion1 conclusion2
FACT retracted observation9

@directSupport rule
WHEN supports ?observation ?claim
THEN justified ?observation ?claim

@propagate rule
WHEN justified ?observation ?claim
AND implies ?claim ?next
THEN justified ?observation ?next

@currentSupport all
GIVES ?observation ?claim
MATCH justified ?observation ?claim
NONE retracted ?observation

@answer query
GIVES ?observation
USE $currentSupport ?observation conclusion2
```

This is an executable example, not a promise that the engine can infer the scientific validity of `implies`. Here NONE uses the explicit closed-world assumption that the `retracted` relation is complete for the source snapshot. The proof explains which fact and rule instances were used.

## How the implemented engine controls combinations

A bound query, such as a particular claim/entity, can propagate its demand into recursive relations. Joins use bound-variable indexes. Within recursion, delta evaluation avoids blindly repeating joins over only old data. If a subcomponent contributes only an existence condition, the compiler seeks one witness rather than enumerating its Cartesian product with every answer. Duplicate derived bindings are stored once.

A recurring nonrecursive derived relation can be inlined under a verified guard. Repeated workload episodes can train join permutations or a configuration policy, stored by schema fingerprint. These are reusable algorithmic plans, not prompt instructions. A fresh schema or changed guard triggers fallback. The historical E06 dominance relation now has a concrete path: express it as SOP comparisons, recognize its exact complete shape, compile its evaluation into an efficient sweep, and retain rule-compatible witnesses.

These mechanisms address different causes of explosion. They do not guarantee a small search space when the logical output or required intermediate relation is genuinely huge. The dense-closure, triangle and Cartesian-output workloads preserve this limitation in the regression suite.

## Lifecycle and data changes

The adapter returns `outputWire`, `bindings`, `status`, `snapshot`, `plan`, `stats` and optional `evidence`. The surrounding runtime should publish bindings as complete only for `COMPLETE`. On `INCOMPLETE`, it can enlarge the budget, choose another safe plan or mark the goal unresolved. It must not convert a partial empty result into a negative fact.

Each fact/rule environment belongs to a snapshot. Adding/removing facts invalidates caches and absence claims. Forked agents obtain isolated Session identities. The current implementation rebuilds after updates; a future incremental-maintenance subsystem must preserve these semantics before replacing that conservative implementation.

## Reusable skill representation

A persistent object should include a semantic kind, rule-schema fingerprint, query scope, checked applicability conditions, executable plan, certificate-template identifier and training cost record. This package implements that structure for join plans and execution policies. Compilation templates for demand, inlining, factoring and Pareto have their own guards and proof arguments.

The cost model may change which verified plan is chosen. It cannot change truth, remove a body condition, reinterpret NONE, merge arbitrary entities or discard provenance obligations. Application code must re-check applicability at each changed schema/data regime rather than trusting the name of a previously successful skill.

## What would count as a new reasoning algorithm

Current plan selection, demand rewriting, factoring and Pareto evaluation instantiate known algorithms. Future synthesis can propose a new relational macro, invariant or quotient, but acceptance must specify what is preserved: an answer set, a minimum, a witness, or a multiplicity. A valid quotient for Boolean reachability is not automatically valid for counting paths or retaining every proof.

A realistic next extension is verified synthesis of relational rewrites from traces, with a small language of constructive proof steps. A candidate can be tested against an independent evaluator, but testing is not a universal proof. Unproved candidates may guide search or run in a separate speculative branch; they must not remove required alternatives in the rigorous branch.

Representation-constructor invention, arbitrary-domain dominance proofs, neural state-quotient learning and automatic ingestion of millions of natural-language facts are **not implemented in this checkpoint**. Their earlier experimental sources and proposed contracts are retained in the history rather than being silently declared complete.

## E09 integration: from per-query execution to cumulative reasoning

A production SOP runtime should not run full invention on every query. Use three tempos:

1. **Online query:** retrieve promoted skills, build the local theory, reason exactly, return answer/proof/status, append an episode.
2. **Fast local adaptation:** optionally choose among already-safe plans when a task repeats. This may change ordering but not semantics.
3. **Dreaming/consolidation:** batch expensive or repeated episodes; synthesize lemmas/abstractions/programs; verify and benchmark them; promote only after regression.

The current `.mjs` implementation realizes this pattern with `AdaptiveReasoner`. The store is deliberately schema-local. Cross-schema concept transfer, such as E06's dominance-role transfer, should become a separate structural-template layer with role mapping and fresh verification rather than a loose similarity lookup.

For a large fact/rule environment the long-term path is:

```text
query
 -> relevance/theory construction
 -> promoted decomposition/quotient/lemma skills
 -> SCC/fixpoint execution
 -> proof and counterexamples
 -> journal
 -> offline theory/algorithm consolidation
```

A newly synthesized lemma can become another rule available to later SOP reasoning. A synthesized quotient can become a new canonical state relation. An invariant can become a checked guard for pruning. A composed algorithm can become a macro-interpreter. They should all share the same persistent lifecycle and regression policy even though their proof obligations differ.

## E10: reasoning online, consolidation offline

For SOP deployments with many fact/rule wires, the recommended architecture is not to invent during every query. Online execution uses a frozen deployment plan. Each task can journal its schema, query, completion state, cost counters and provenance. During an idle or explicit consolidation cycle, `Dreamer` groups compatible episodes and asks multiple inventors for candidate shortcuts.

A candidate can become a persistent skill only after the semantic gate appropriate to its class. The store can retain more trusted skills than any one query deploys. `SkillComposer` then learns which subset is appropriate for a particular query/objective.

This supports a cumulative “dreaming” model:

```text
facts/rules + query
    → exact online reasoning
    → episode/failure/cost traces
    → offline invention
    → exact verification
    → persistent skill library
    → replay-verified composition
    → next online query
```

In a larger SOP ecosystem, future inventors can consume advisory invariants, proof failures, frequently repeated subgoals and expensive join frontiers to propose new lemmas, state signatures, dominance relations, separators or derived features. Until such a proposal receives a valid certificate it remains advisory and cannot delete proof paths.
