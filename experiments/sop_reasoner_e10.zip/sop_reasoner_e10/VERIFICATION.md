# Clean reproduction verification — E10

**PASS.** E10 was regenerated in a fresh directory with no pre-existing generated datasets, learned plans, neural checkpoints, or E10 skill store.

| Check | Result |
|---|---|
| Node tests | 202/202 PASS |
| SOP-native scientific regressions | 20/20 PASS |
| Historical saved-record audit | 15/15 PASS |
| Historical unit tests rerun before packaging | 79/79 PASS |
| Semantic fingerprint | `f952f65baf286a46ed3bd539fea53a35bdb911359751663d5b031af6158e4d0a` (identical) |
| Generated data | 91/91 byte-identical |
| Deterministic checkpoints/skill bundles | 17/17 byte-identical |
| Original E00–E07 archive | SHA-256 unchanged |

The fresh run regenerated the E08 benchmark, adaptive policies, neural ranking control, 100k/1M-fact stress data, E09 dreaming demo, all 20 SOP regressions and the E10 106,800-fact multi-domain world. It reproduced the same semantic fingerprint.

## Runner note

The hosted execution environment used for this delivery throttles a long command after several CPU-heavy child processes. Consequently the release was validated **phase-by-phase**, with each phase in a fresh runner invocation, rather than claiming a successful single-shot orchestration here. The repository still provides `make reproduce`; the individual commands are also documented and are what were used for the clean verification. This note is an orchestration limitation, not a hidden failed experiment.

This is clean-directory reproducibility on the same Node/OS/hardware environment, not an independent-machine replication.
