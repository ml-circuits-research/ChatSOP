# SOP Verified Reasoner — rezultate E10

## E10 unified environment

| Query | Expected | Baseline status | Baseline probes | Learned status | Learned probes | Learned rounds | Certificates |
|---|---:|---|---:|---|---:|---:|---|
| reach | 40 | INCOMPLETE | 300001 | COMPLETE | 167 | 43 | positive-demand-transform-v1 |
| visible | 1 | COMPLETE | 25002 | COMPLETE | 3 | 2 | existential-variable-quotient-v1 |
| eligible | 500 | COMPLETE | 251000 | COMPLETE | 1001 | 2 | — |
| pareto | 900 | COMPLETE | 1623600 | COMPLETE | 2700 | 1 | pareto-2d-antijoin-v1 |

Training fact counts: 327, 397, 467. Large world: 106800. Skill records: {"total":18,"promoted":14,"rejected":4,"deployments":4}.

## Main E08 benchmark retained

| Family | Mode | COMPLETE / INCOMPLETE / other | Exact completed | Tuple probes | Wall ms |
|---|---|---|---|---:|---:|
| disconnected | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| disconnected | indexed_semi | 3 / 0 / 0 | 3/3 | 9771.00 ± 0.00 | 12.27 ± 3.95 |
| disconnected | greedy_semi | 3 / 0 / 0 | 3/3 | 9091.00 ± 0.00 | 16.19 ± 4.95 |
| disconnected | verified | 3 / 0 / 0 | 3/3 | 61.00 ± 0.00 | 2.40 ± 1.99 |
| disconnected | learned | 3 / 0 / 0 | 3/3 | 9771.00 ± 0.00 | 14.30 ± 5.40 |
| disconnected | sqlite | 3 / 0 / 0 | 3/3 | — | 1.74 ± 0.26 |
| deep_recursion | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| deep_recursion | indexed_semi | 3 / 0 / 0 | 3/3 | 103036.00 ± 0.00 | 100.97 ± 3.83 |
| deep_recursion | greedy_semi | 3 / 0 / 0 | 3/3 | 102718.00 ± 0.00 | 116.29 ± 6.60 |
| deep_recursion | verified | 3 / 0 / 0 | 3/3 | 1284.00 ± 0.00 | 3.25 ± 1.08 |
| deep_recursion | learned | 3 / 0 / 0 | 3/3 | 102718.00 ± 0.00 | 125.13 ± 17.29 |
| deep_recursion | sqlite | 3 / 0 / 0 | 3/3 | — | 1.41 ± 0.33 |
| dense_cycle | scan_naive | 1 / 2 / 0 | 1/1 | 399895.00 ± 0.00 | 49.30 ± 0.00 |
| dense_cycle | indexed_semi | 3 / 0 / 0 | 3/3 | 7638.00 ± 64.21 | 10.03 ± 0.66 |
| dense_cycle | greedy_semi | 3 / 0 / 0 | 3/3 | 6964.00 ± 55.11 | 8.43 ± 1.56 |
| dense_cycle | verified | 3 / 0 / 0 | 3/3 | 14612.00 ± 127.35 | 16.99 ± 3.13 |
| dense_cycle | learned | 3 / 0 / 0 | 3/3 | 7638.00 ± 64.21 | 12.11 ± 3.52 |
| dense_cycle | sqlite | 3 / 0 / 0 | 3/3 | — | 5.16 ± 0.83 |
| nonlinear_recursion | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| nonlinear_recursion | indexed_semi | 3 / 0 / 0 | 3/3 | 13678.67 ± 91.14 | 14.27 ± 10.20 |
| nonlinear_recursion | greedy_semi | 3 / 0 / 0 | 3/3 | 14355.33 ± 82.98 | 8.71 ± 0.67 |
| nonlinear_recursion | verified | 3 / 0 / 0 | 3/3 | 16785.33 ± 242.00 | 12.71 ± 0.79 |
| nonlinear_recursion | learned | 3 / 0 / 0 | 3/3 | 13678.67 ± 91.14 | 15.45 ± 1.91 |
| nonlinear_recursion | sqlite | 3 / 0 / 0 | 3/3 | — | 0.55 ± 0.14 |
| selective_join | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| selective_join | indexed_semi | 3 / 0 / 0 | 3/3 | 532593.00 ± 0.00 | 190.87 ± 17.79 |
| selective_join | greedy_semi | 3 / 0 / 0 | 3/3 | 179.00 ± 0.00 | 5.52 ± 2.51 |
| selective_join | verified | 3 / 0 / 0 | 3/3 | 181.00 ± 0.00 | 4.51 ± 0.46 |
| selective_join | learned | 3 / 0 / 0 | 3/3 | 179.00 ± 0.00 | 4.90 ± 0.79 |
| selective_join | sqlite | 3 / 0 / 0 | 3/3 | — | 51.28 ± 1.31 |
| existential | scan_naive | 3 / 0 / 0 | 3/3 | 360600.00 ± 0.00 | 145.44 ± 5.77 |
| existential | indexed_semi | 3 / 0 / 0 | 3/3 | 360600.00 ± 0.00 | 135.94 ± 2.93 |
| existential | greedy_semi | 3 / 0 / 0 | 3/3 | 360600.00 ± 0.00 | 130.03 ± 0.26 |
| existential | verified | 3 / 0 / 0 | 3/3 | 603.00 ± 0.00 | 1.42 ± 0.08 |
| existential | learned | 3 / 0 / 0 | 3/3 | 601.00 ± 0.00 | 2.20 ± 0.92 |
| existential | sqlite | 3 / 0 / 0 | 3/3 | — | 2.26 ± 0.06 |
| policy | scan_naive | 3 / 0 / 0 | 3/3 | 116571.00 ± 0.00 | 37.50 ± 3.15 |
| policy | indexed_semi | 3 / 0 / 0 | 3/3 | 20571.00 ± 0.00 | 19.59 ± 1.21 |
| policy | greedy_semi | 3 / 0 / 0 | 3/3 | 19035.00 ± 0.00 | 31.94 ± 2.79 |
| policy | verified | 3 / 0 / 0 | 3/3 | 19035.00 ± 0.00 | 35.17 ± 6.01 |
| policy | learned | 3 / 0 / 0 | 3/3 | 20571.00 ± 0.00 | 33.69 ± 5.39 |
| policy | sqlite | 3 / 0 / 0 | 3/3 | — | 11.82 ± 0.42 |
| temporal | scan_naive | 3 / 0 / 0 | 3/3 | 119614.00 ± 3121.16 | 18.34 ± 5.55 |
| temporal | indexed_semi | 3 / 0 / 0 | 3/3 | 8310.00 ± 216.69 | 6.37 ± 2.13 |
| temporal | greedy_semi | 3 / 0 / 0 | 3/3 | 8310.00 ± 216.69 | 7.15 ± 1.86 |
| temporal | verified | 3 / 0 / 0 | 3/3 | 8312.00 ± 216.69 | 5.87 ± 0.71 |
| temporal | learned | 3 / 0 / 0 | 3/3 | 8310.00 ± 216.69 | 6.51 ± 2.66 |
| temporal | sqlite | 3 / 0 / 0 | 3/3 | — | 1.03 ± 0.04 |
| triangles | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| triangles | indexed_semi | 3 / 0 / 0 | 3/3 | 2669.33 ± 224.38 | 2.30 ± 0.50 |
| triangles | greedy_semi | 3 / 0 / 0 | 3/3 | 2244.33 ± 149.70 | 2.45 ± 0.19 |
| triangles | verified | 3 / 0 / 0 | 3/3 | 2246.33 ± 149.70 | 2.68 ± 0.39 |
| triangles | learned | 3 / 0 / 0 | 3/3 | 2669.33 ± 224.38 | 2.43 ± 0.51 |
| triangles | sqlite | 3 / 0 / 0 | 3/3 | — | 1.82 ± 0.21 |
| mutual_recursion | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| mutual_recursion | indexed_semi | 3 / 0 / 0 | 3/3 | 963.00 ± 0.00 | 1.89 ± 0.12 |
| mutual_recursion | greedy_semi | 3 / 0 / 0 | 3/3 | 963.00 ± 0.00 | 2.58 ± 0.83 |
| mutual_recursion | verified | 3 / 0 / 0 | 3/3 | 3593.00 ± 0.00 | 4.73 ± 1.32 |
| mutual_recursion | learned | 3 / 0 / 0 | 3/3 | 963.00 ± 0.00 | 3.48 ± 1.34 |
| mutual_recursion | sqlite | 0 / 0 / 3 | 0/0 | — | — |
| rule_heavy | scan_naive | 3 / 0 / 0 | 3/3 | 2.00 ± 0.00 | 3.95 ± 2.00 |
| rule_heavy | indexed_semi | 3 / 0 / 0 | 3/3 | 2.00 ± 0.00 | 2.95 ± 0.73 |
| rule_heavy | greedy_semi | 3 / 0 / 0 | 3/3 | 2.00 ± 0.00 | 3.19 ± 0.73 |
| rule_heavy | verified | 3 / 0 / 0 | 3/3 | 3.00 ± 0.00 | 2.94 ± 0.81 |
| rule_heavy | learned | 0 / 0 / 3 | 0/0 | — | — |
| rule_heavy | sqlite | 0 / 0 / 3 | 0/0 | — | — |
| or_evidence | scan_naive | 3 / 0 / 0 | 3/3 | 11334.00 ± 0.00 | 17.11 ± 0.31 |
| or_evidence | indexed_semi | 3 / 0 / 0 | 3/3 | 11334.00 ± 0.00 | 13.85 ± 1.97 |
| or_evidence | greedy_semi | 3 / 0 / 0 | 3/3 | 11334.00 ± 0.00 | 11.61 ± 1.12 |
| or_evidence | verified | 3 / 0 / 0 | 3/3 | 11341.00 ± 0.00 | 12.70 ± 2.72 |
| or_evidence | learned | 3 / 0 / 0 | 3/3 | 11334.00 ± 0.00 | 13.81 ± 2.64 |
| or_evidence | sqlite | 3 / 0 / 0 | 3/3 | — | 13.96 ± 1.37 |
| output_cartesian | scan_naive | 3 / 0 / 0 | 3/3 | 22650.00 ± 0.00 | 38.63 ± 1.69 |
| output_cartesian | indexed_semi | 3 / 0 / 0 | 3/3 | 22650.00 ± 0.00 | 41.78 ± 4.68 |
| output_cartesian | greedy_semi | 3 / 0 / 0 | 3/3 | 22650.00 ± 0.00 | 42.03 ± 6.30 |
| output_cartesian | verified | 3 / 0 / 0 | 3/3 | 22652.00 ± 0.00 | 44.28 ± 4.14 |
| output_cartesian | learned | 3 / 0 / 0 | 3/3 | 22650.00 ± 0.00 | 47.72 ± 1.52 |
| output_cartesian | sqlite | 3 / 0 / 0 | 3/3 | — | 26.73 ± 3.41 |
| pareto | scan_naive | 0 / 3 / 0 | 0/0 | — | — |
| pareto | indexed_semi | 3 / 0 / 0 | 3/3 | 1218800.00 ± 0.00 | 885.00 ± 8.01 |
| pareto | greedy_semi | 3 / 0 / 0 | 3/3 | 1218800.00 ± 0.00 | 872.33 ± 22.59 |
| pareto | verified | 3 / 0 / 0 | 3/3 | 6600.00 ± 0.00 | 7.52 ± 1.44 |
| pareto | learned | 3 / 0 / 0 | 3/3 | 1218800.00 ± 0.00 | 906.53 ± 14.72 |
| pareto | sqlite | 3 / 0 / 0 | 3/3 | — | 6.01 ± 0.07 |

## Adaptive policy retained

| Family | Correct | Probes mean | Wall ms mean |
|---|---:|---:|---:|
| disconnected | 3/3 | 60.00 ± 0.00 | 1.24 ± 0.24 |
| deep_recursion | 3/3 | 1283.00 ± 0.00 | 5.65 ± 0.93 |
| dense_cycle | 3/3 | 6964.00 ± 55.11 | 8.41 ± 1.30 |
| nonlinear_recursion | 3/3 | 14355.33 ± 82.98 | 8.09 ± 1.42 |
| selective_join | 3/3 | 179.00 ± 0.00 | 4.50 ± 0.22 |
| existential | 3/3 | 601.00 ± 0.00 | 1.83 ± 0.46 |
| policy | 3/3 | 19035.00 ± 0.00 | 32.34 ± 0.83 |
| temporal | 3/3 | 8310.00 ± 216.69 | 5.41 ± 0.52 |
| triangles | 3/3 | 2244.33 ± 149.70 | 4.07 ± 1.13 |
| mutual_recursion | 3/3 | 963.00 ± 0.00 | 2.39 ± 0.76 |
| rule_heavy | 3/3 | 2.00 ± 0.00 | 2.16 ± 0.38 |
| or_evidence | 3/3 | 11334.00 ± 0.00 | 16.10 ± 2.60 |
| output_cartesian | 3/3 | 22650.00 ± 0.00 | 53.17 ± 10.02 |
| pareto | 3/3 | 6600.00 ± 0.00 | 7.21 ± 1.89 |

## Neural ranking control retained

Training samples: 180; held-out evaluations: 36. The MLP ties the analytical heuristic on this control; it is not required for correctness.

## Stress retained

- 100000 facts / indexed-budgeted: INCOMPLETE, probes=250001, indexRows=100000, engineWallMs=581.2297269999999
- 100000 facts / verified: COMPLETE, probes=41, indexRows=100009, engineWallMs=135.27558900000008
- 100000 facts / sqlite: COMPLETE, probes=—, indexRows=—, engineWallMs=—
- 1000000 facts / indexed-budgeted: INCOMPLETE, probes=250001, indexRows=0, engineWallMs=1693.841446
- 1000000 facts / verified: COMPLETE, probes=41, indexRows=1000009, engineWallMs=1415.108037
- 1000000 facts / sqlite: COMPLETE, probes=—, indexRows=—, engineWallMs=—

## Regression

- Node: 202/202
- SOP: 20/20
- Historical audit: 15/15
- Semantic SHA-256: `f952f65baf286a46ed3bd539fea53a35bdb911359751663d5b031af6158e4d0a`
