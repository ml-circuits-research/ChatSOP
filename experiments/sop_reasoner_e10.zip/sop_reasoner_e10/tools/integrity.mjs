/** Integrity receipt for the supplied release. Not a cryptographic signature. */
import { readdir, readFile, writeFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('..', import.meta.url));
const manifestName = 'RELEASE_MANIFEST.json';
async function walk(dir, prefix = '') {
  const out = [];
  for (const entry of (await readdir(dir, { withFileTypes: true })).sort((a,b) => a.name.localeCompare(b.name))) {
    const rel = prefix + entry.name;
    if (rel === manifestName) continue;
    if (entry.isDirectory()) out.push(...await walk(join(dir,entry.name), rel + '/'));
    else out.push(rel);
  }
  return out;
}
const sha = buffer => createHash('sha256').update(buffer).digest('hex');
if (process.argv.includes('--write')) {
  const entries = [];
  for (const file of await walk(root)) {
    const bytes = await readFile(resolve(root, file));
    entries.push({ file, bytes: bytes.length, sha256: sha(bytes) });
  }
  await writeFile(resolve(root, manifestName), JSON.stringify({ algorithm: 'SHA-256', entries }, null, 2) + '\n');
  console.log(`Release receipt written for ${entries.length} files.`);
} else {
  const manifest = JSON.parse(await readFile(resolve(root, manifestName), 'utf8'));
  for (const e of manifest.entries) {
    const bytes = await readFile(resolve(root, e.file));
    if (bytes.length !== e.bytes || sha(bytes) !== e.sha256) throw new Error(`Release file changed: ${e.file}`);
  }
  console.log(`Release integrity PASS: ${manifest.entries.length}/${manifest.entries.length} files unchanged.`);
}
