import {readFile,writeFile} from 'node:fs/promises';import {createHash} from 'node:crypto';import {fileURLToPath} from 'node:url';import {resolve} from 'node:path';
const root=fileURLToPath(new URL('..',import.meta.url)),load=async f=>JSON.parse(await readFile(resolve(root,'results',f),'utf8'));
const main=await load('benchmark.json'),adaptive=await load('adaptive.json'),neural=await load('neural.json'),stress=await load('stress.json'),dream=await load('dream.json'),sopRegression=await load('sop-regression.json'),e10=await load('e10.json');
const semantic={
 benchmark:main.map(r=>({family:r.family,seed:r.seed,mode:r.mode,status:r.status,correct:r.correct,hash:r.answerHash,work:r.stats?.candidateVisits})),
 adaptive:adaptive.test.map(r=>({family:r.family,seed:r.seed,hash:r.answerHash,work:r.work,options:r.options})),
 neural:neural.results,
 stress:stress.results.map(r=>({n:r.n,mode:r.mode,status:r.status,rows:r.rows,hash:r.sha256,work:r.stats?.candidateVisits,indexRows:r.stats?.indexBuildRows})),
 dream:{exact:dream.exact,promoted:dream.promoted,rejected:dream.rejected,baseline:dream.baseline,dreamed:dream.dreamed,ratios:dream.ratios},
 sopRegression:sopRegression.results.map(r=>({name:r.name,status:r.status,count:r.count,candidateVisits:r.candidateVisits,rounds:r.rounds,baseline:r.baseline,dream:r.dream?{promoted:r.dream.promoted.length,rejected:r.dream.rejected.length}:null})),
 e10:{factCount:e10.factCount,trainingFacts:e10.trainingFacts,skillCounts:e10.skillCounts,results:e10.results.map(r=>({query:r.query,expected:r.expected,exact:r.exact,baseline:{status:r.baseline.status,count:r.baseline.count,candidateVisits:r.baseline.candidateVisits,rounds:r.baseline.rounds},learned:{status:r.learned.status,count:r.learned.count,candidateVisits:r.learned.candidateVisits,rounds:r.learned.rounds,quotientSkipped:r.learned.quotientSkipped,certificates:r.learned.certificates},deployment:r.deployment?{members:r.deployment.members,objective:r.deployment.objective,settings:r.deployment.settings}:null})),advisories:e10.advisories.map(a=>({family:a.family,query:a.query,artifact:a.artifact}))}
};
const text=JSON.stringify(semantic,null,2)+'\n';await writeFile(resolve(root,'results/SEMANTIC.json'),text);const hash=createHash('sha256').update(text).digest('hex');await writeFile(resolve(root,'results/SEMANTIC.sha256'),hash+'\n');console.log(`Deterministic result fingerprint: ${hash}`);
