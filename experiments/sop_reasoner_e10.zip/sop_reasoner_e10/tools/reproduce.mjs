import {spawn} from 'node:child_process';
import {readdirSync,writeFileSync,mkdirSync,openSync,closeSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('..',import.meta.url));mkdirSync(resolve(root,'results'),{recursive:true});
const tests=readdirSync(resolve(root,'tests')).filter(n=>n.endsWith('.test.mjs')).map(n=>`tests/${n}`);
const phases=[
  ['tests',['--test',...tests]],
  ['history-audit',['tools/history-audit.mjs']],
  ['sop-regression',['tools/sop-regression.mjs']],
  ['dream',['tools/dream-demo.mjs']],
  ['stress',['--expose-gc','bench/stress.mjs']],
  ['e10',['bench/e10.mjs']],
  ['benchmark',['--expose-gc','bench/run.mjs']],
  ['adaptive',['--expose-gc','bench/adaptive.mjs']],
  ['neural',['bench/neural.mjs']],
  ['semantic',['tools/semantic.mjs']]
];
async function run(name,args,{log=true,timeoutMs=120000}={}){
  const path=resolve(root,`results/${name}-current.log`),fd=log?openSync(path,'w'):null,started=performance.now();
  console.log(`Running ${name}`);
  try{
    const status=await new Promise((resolveStatus,reject)=>{
      const child=spawn(process.execPath,args,{cwd:root,stdio:log?['ignore',fd,fd]:'inherit'});
      const timer=setTimeout(()=>{child.kill('SIGTERM');reject(new Error(`${name} exceeded ${timeoutMs} ms`));},timeoutMs);
      child.on('error',e=>{clearTimeout(timer);reject(e);});child.on('exit',(code,signal)=>{clearTimeout(timer);if(signal)reject(new Error(`${name} killed by ${signal}`));else resolveStatus(code??1);});
    });
    const elapsed=performance.now()-started;console.log(`Finished ${name} in ${(elapsed/1000).toFixed(2)} s`);if(status!==0)throw new Error(`${name} exited ${status}; see ${path}`);return {name,elapsedMs:elapsed,status};
  }finally{if(fd!==null)closeSync(fd);}
}
const requestedPhase=process.argv.includes('--phase')?process.argv[process.argv.indexOf('--phase')+1]:null;
if(requestedPhase){
  const selected=phases.find(([name])=>name===requestedPhase);
  if(!selected)throw new Error(`Unknown phase ${requestedPhase}. Valid phases: ${phases.map(([name])=>name).join(', ')}`);
  const [name,args]=selected;
  const timing=await run(name,args);
  console.log(`Phase ${name} passed in ${(timing.elapsedMs/1000).toFixed(2)} seconds.`);
}else{
  const started=performance.now(),timings=[];for(const [name,args] of phases)timings.push(await run(name,args));
  const summary={status:'PASS',phases:timings,totalMs:performance.now()-started,node:process.version,scope:'Node runtime, SOP-native property regressions, unified E10 dreaming/composition, current benchmarks and historical integrity checks; no retraining of archived Python experiments'};
  writeFileSync(resolve(root,'results/REPRODUCTION.json'),JSON.stringify(summary,null,2)+'\n');
  await run('report',['tools/report.mjs']);
  console.log(`All current phases passed in ${(summary.totalMs/1000).toFixed(2)} seconds.`);
}
