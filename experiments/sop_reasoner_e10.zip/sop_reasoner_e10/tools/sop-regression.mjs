import {readFileSync,readdirSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,basename} from 'node:path';
import {parseSOP,reason,reference,explain,verifyExplanation,Dreamer,VerifiedSkillStore,QuotientInventor,DecompositionInventor,DominanceInventor,RepresentationInventor,InvariantInventor} from '../src/index.mjs';

const root=new URL('../regression/cases/',import.meta.url);
function value(s){s=s.trim();if(!s)return true;try{return JSON.parse(s);}catch{return s;}}
export function directives(text){const d={};for(const line of text.split(/\r?\n/)){const m=line.match(/^\s*#%\s+([A-Z0-9_]+)(?:\s+(.*))?$/);if(m)d[m[1]]=value(m[2]||'');}return d;}
const key=rows=>JSON.stringify(rows);
function certs(r){return new Set(r.plan?.certificates?.map(c=>c.kind)||[]);}
function assert(ok,msg){if(!ok)throw new Error(msg);}
function score(r){return r.stats.candidateVisits+32*r.stats.rounds;}

export function runCase(path){const text=readFileSync(path,'utf8'),d=directives(text),name=d.TEST||basename(path);let program;
  try{program=parseSOP(text,path);}catch(e){if(d.EXPECT_ERROR){assert(String(e.message).includes(d.EXPECT_ERROR),`${name}: error did not contain ${d.EXPECT_ERROR}: ${e.message}`);return {name,status:'PASS',expectedError:true};}throw e;}
  if(d.EXPECT_ERROR)throw new Error(`${name}: expected parser/runtime error ${d.EXPECT_ERROR}`);
  const query=d.QUERY||program.queries[0]?.name;assert(query,`${name}: missing query`);const options=d.OPTIONS||{};let r;
  try{r=reason(program,query,options);}catch(e){if(d.EXPECT_RUNTIME_ERROR){assert(String(e.message).includes(d.EXPECT_RUNTIME_ERROR),`${name}: runtime error mismatch ${e.message}`);return {name,status:'PASS',expectedRuntimeError:true};}throw e;}
  if(d.EXPECT_STATUS!==undefined)assert(r.status===d.EXPECT_STATUS,`${name}: status ${r.status} != ${d.EXPECT_STATUS}`);
  if(d.EXPECT_COUNT!==undefined)assert(r.count===d.EXPECT_COUNT,`${name}: count ${r.count} != ${d.EXPECT_COUNT}`);
  if(d.EXPECT_ROWS!==undefined)assert(key(r.rows)===key(d.EXPECT_ROWS),`${name}: rows mismatch ${key(r.rows)} != ${key(d.EXPECT_ROWS)}`);
  if(d.COMPARE_REFERENCE){const ref=reference(program,query);assert(r.complete,`${name}: optimized execution incomplete`);assert(key(r.rows)===key(ref.rows),`${name}: differs from independent reference`);}
  if(d.EXPECT_CERTIFICATE)assert(certs(r).has(d.EXPECT_CERTIFICATE),`${name}: missing certificate ${d.EXPECT_CERTIFICATE}`);
  if(d.FORBID_CERTIFICATE)assert(!certs(r).has(d.FORBID_CERTIFICATE),`${name}: forbidden certificate ${d.FORBID_CERTIFICATE} applied`);
  if(d.VERIFY_PROOF){assert(r.complete&&r.count>0,`${name}: proof needs completed nonempty answer`);const p=explain(r);assert(verifyExplanation(program,r,p).valid,`${name}: proof replay failed`);}
  let baseline=null;
  if(d.BASELINE_OPTIONS){baseline=reason(program,query,d.BASELINE_OPTIONS);assert(baseline.complete===r.complete||r.complete,`${name}: unexpected completion relation`);if(d.EXPECT_WORK_RATIO_LE!==undefined){const ratio=r.stats.candidateVisits/Math.max(1,baseline.stats.candidateVisits);assert(ratio<=d.EXPECT_WORK_RATIO_LE,`${name}: work ratio ${ratio} > ${d.EXPECT_WORK_RATIO_LE}`);}}
  let dream=null;
  if(d.DREAM){const store=new VerifiedSkillStore(),dreamer=new Dreamer({store,roundWeight:d.DREAM_ROUND_WEIGHT??32,minGain:d.DREAM_MIN_GAIN??.03,maxPromotedLemmas:d.DREAM_MAX_LEMMAS??2});const repeats=d.DREAM_REPEAT??3,programs=Array.from({length:repeats},()=>program);
    const inventorMap={quotient:new QuotientInventor(),decomposition:new DecompositionInventor(),dominance:new DominanceInventor(),representation:new RepresentationInventor(),invariant:new InvariantInventor()};
    let inventors=null;if(Array.isArray(d.DREAM_INVENTORS))inventors=d.DREAM_INVENTORS.map(x=>inventorMap[x]).filter(Boolean);else if(d.DREAM_INVENTORS===true)inventors=Object.values(inventorMap);
    dream=dreamer.consolidate(programs,query,{learnPolicy:d.DREAM_POLICY??false,learnJoins:d.DREAM_JOINS??false,learnLemmas:d.DREAM_LEMMAS??true,learnInventors:!!d.DREAM_INVENTORS,inventors,compose:d.DREAM_COMPOSE??false,maxWork:d.DREAM_MAX_WORK??5_000_000,baselineOptions:d.DREAM_BASE_OPTIONS||{demand:false,factor:false,quotient:false,fuse:false,dominance:false}});
    if(d.DREAM_MIN_PROMOTED!==undefined)assert(dream.promoted.length>=d.DREAM_MIN_PROMOTED,`${name}: promoted ${dream.promoted.length} < ${d.DREAM_MIN_PROMOTED}`);
    if(d.DREAM_EXPECT_FAMILY!==undefined){const want=Array.isArray(d.DREAM_EXPECT_FAMILY)?d.DREAM_EXPECT_FAMILY:[d.DREAM_EXPECT_FAMILY];for(const family of want)assert(store.records.some(r=>r.status==='promoted'&&r.family===family),`${name}: missing promoted family ${family}`);}
    if(d.DREAM_EXPECT_ADVISORY!==undefined)assert(store.advisories(program,query).length>=d.DREAM_EXPECT_ADVISORY,`${name}: advisory count too small`);
    if(d.DREAM_EXPECT_DEPLOYMENT)assert(store.records.some(r=>r.status==='promoted'&&r.kind==='deployment-plan'),`${name}: missing promoted deployment plan`);
    const skills=store.promoted(program,query),after=reason(program,query,{...(d.DREAM_BASE_OPTIONS||{demand:false}),...skills});const ref=reference(program,query);assert(after.complete&&key(after.rows)===key(ref.rows),`${name}: dreamed skill changed semantics`);
    if(d.DREAM_EXPECT_ROUND_RATIO_LE!==undefined){const before=reason(program,query,d.DREAM_BASE_OPTIONS||{demand:false});const ratio=after.stats.rounds/Math.max(1,before.stats.rounds);assert(ratio<=d.DREAM_EXPECT_ROUND_RATIO_LE,`${name}: dreamed round ratio ${ratio} > ${d.DREAM_EXPECT_ROUND_RATIO_LE}`);}
    if(d.DREAM_EXPECT_COST_RATIO_LE!==undefined){const before=reason(program,query,d.DREAM_BASE_OPTIONS||{demand:false});const ratio=score(after)/Math.max(1,score(before));assert(ratio<=d.DREAM_EXPECT_COST_RATIO_LE,`${name}: dreamed score ratio ${ratio} > ${d.DREAM_EXPECT_COST_RATIO_LE}`);}
  }
  return {name,status:'PASS',query,count:r.count,candidateVisits:r.stats.candidateVisits,rounds:r.stats.rounds,baseline:baseline?{candidateVisits:baseline.stats.candidateVisits,rounds:baseline.stats.rounds}:null,dream};
}

export function runAll(dirPath=new URL('../regression/cases/',import.meta.url)){
  const dir=dirPath.pathname,files=readdirSync(dir).filter(x=>x.endsWith('.sop')).sort(),results=[];for(const f of files){try{results.push(runCase(join(dir,f)));}catch(e){results.push({name:f,status:'FAIL',error:e.stack||String(e)});}}
  return {kind:'sop-regression-v1',cases:results.length,passed:results.filter(r=>r.status==='PASS').length,failed:results.filter(r=>r.status==='FAIL').length,results};
}
if(import.meta.url===`file://${process.argv[1]}`){const out=runAll();mkdirSync(new URL('../results/',import.meta.url),{recursive:true});writeFileSync(new URL('../results/sop-regression.json',import.meta.url),JSON.stringify(out,null,2)+'\n');for(const r of out.results)console.log(`${r.status} ${r.name}${r.error?` :: ${r.error.split('\n')[0]}`:''}`);console.log(`${out.passed}/${out.cases} SOP regression cases passed`);if(out.failed)process.exitCode=1;}
