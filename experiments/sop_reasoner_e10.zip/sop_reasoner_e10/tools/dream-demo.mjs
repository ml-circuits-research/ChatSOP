import {writeFileSync,mkdirSync} from 'node:fs';
import {parseSOP,reason,reference,Dreamer,VerifiedSkillStore,AdaptiveReasoner,EpisodeJournal} from '../src/index.mjs';

function chain(n){const facts=Array.from({length:n-1},(_,i)=>`FACT edge ${i} ${i+1}`).join('\n');return parseSOP(`@facts facts\nSOURCE "synthetic://dream-chain"\n${facts}\n@base rule\nWHEN edge ?x ?y\nTHEN path ?x ?y\n@step rule\nWHEN path ?x ?y\nAND edge ?y ?z\nTHEN path ?x ?z\n@q query\nGIVES ?y\nMATCH path 0 ?y`);}
const train=[24,32,40].map(chain),store=new VerifiedSkillStore(),journal=new EpisodeJournal(),adaptive=new AdaptiveReasoner({store,journal});
const report=adaptive.dreamer.consolidate(train,'q',{learnPolicy:false,learnJoins:false,learnLemmas:true});
const heldout=chain(96),base=reason(heldout,'q',{demand:false}),fast=adaptive.run(heldout,'q',{demand:false},{phase:'heldout-after-dream'}),oracle=reference(heldout,'q',{maxWork:200_000_000});
const exact=JSON.stringify(fast.rows)===JSON.stringify(oracle.rows);
const rejected=store.records.filter(r=>r.status==='rejected').length,promoted=store.records.filter(r=>r.status==='promoted').length;
const result={kind:'dreaming-integration-demo-v1',trainingSizes:[24,32,40],heldoutSize:96,report,promoted,rejected,exact,
  baseline:{candidateVisits:base.stats.candidateVisits,rounds:base.stats.rounds,derived:base.stats.derived},
  dreamed:{candidateVisits:fast.stats.candidateVisits,rounds:fast.stats.rounds,derived:fast.stats.derived,certificates:fast.plan.certificates.map(c=>c.kind)},
  ratios:{rounds:fast.stats.rounds/base.stats.rounds,candidateVisits:fast.stats.candidateVisits/base.stats.candidateVisits},
  journalEntries:journal.entries.length,store:store.toJSON()};
if(!exact||!promoted||fast.stats.rounds>=base.stats.rounds)throw new Error('Dreaming integration demo failed');
mkdirSync(new URL('../results/',import.meta.url),{recursive:true});writeFileSync(new URL('../results/dream.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(`Dreaming demo exact=${exact}, promoted=${promoted}, rounds ${base.stats.rounds} -> ${fast.stats.rounds}, candidateVisits ${base.stats.candidateVisits} -> ${fast.stats.candidateVisits}`);
