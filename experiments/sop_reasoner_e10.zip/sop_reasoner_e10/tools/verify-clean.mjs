/** Regenerate from source in a new directory without carrying over datasets/models. */
import { cp, mkdir, mkdtemp, readdir, readFile, writeFile, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';

const root = fileURLToPath(new URL('..', import.meta.url));
const scratch = await mkdtemp(join(tmpdir(), 'sop-r1-verify-'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function files(dir, prefix = '') {
  const out = [];
  for (const entry of (await readdir(dir, { withFileTypes: true })).sort((a,b) => a.name.localeCompare(b.name))) {
    const name = prefix + entry.name;
    if (entry.isDirectory()) out.push(...await files(join(dir, entry.name), name + '/'));
    else out.push(name);
  }
  return out;
}
const started = performance.now();
try {
  for (const name of ['src', 'bin', 'bench', 'tests', 'tools', 'docs', 'examples', 'regression', 'history', 'package.json', 'Makefile', 'README.md'])
    await cp(resolve(root, name), join(scratch, name), { recursive: true });
  await mkdir(join(scratch, 'results'), { recursive: true });
  // This is historical audit evidence, not a newly trained model or input dataset.
  await cp(resolve(root, 'results/legacy-regression-current.log'), join(scratch, 'results/legacy-regression-current.log'));
  const child = spawnSync(process.execPath, ['tools/reproduce.mjs'], {
    cwd: scratch, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024
  });
  await writeFile(resolve(root, 'results/clean-reproduction.log'), (child.stdout || '') + (child.stderr || ''));
  if (child.status !== 0) throw new Error(`Fresh reproduction failed: ${child.stderr || child.stdout}`);
  const compare = async rel => {
    const [original, fresh] = await Promise.all([readFile(resolve(root, rel)), readFile(join(scratch, rel))]);
    if (!original.equals(fresh)) throw new Error(`Deterministic file differs: ${rel}`);
    return { file: rel, sha256: hash(original) };
  };
  const semantic = await compare('results/SEMANTIC.json');
  const datasets = [];
  for (const f of await files(resolve(root, 'data'))) datasets.push(await compare('data/' + f));
  const checkpoints = [];
  for (const f of await files(resolve(root, 'results'))) {
    if (f === 'neural-rankers.json' || f === 'adaptive-policies.json' || f === 'e10-skills.json' || /^skills-.+\.json$/.test(f))
      checkpoints.push(await compare('results/' + f));
  }
  const originalArchive = await compare('history/E00-E07-original-master.zip');
  const current = JSON.parse(await readFile(resolve(root, 'results/REPRODUCTION.json'), 'utf8'));
  const fresh = JSON.parse(await readFile(join(scratch, 'results/REPRODUCTION.json'), 'utf8'));
  const report = {
    status: 'PASS', sameEnvironment: true, regeneratedDataAndModels: true,
    semantic, datasets, checkpoints, originalArchive,
    originalRunMs: current.totalMs, freshRunMs: fresh.totalMs,
    verificationWallMs: performance.now() - started,
    node: process.version,
    note: 'Fresh directory, no pre-existing data/models, same Node binary/OS/hardware. Not an independent-machine replication; old Python training is not rerun.'
  };
  await writeFile(resolve(root, 'results/CLEAN_REPRODUCTION.json'), JSON.stringify(report, null, 2) + '\n');
  const md = `# Clean reproduction verification\n\n**PASS.** Current experiments were rerun in a new directory, starting without generated data, learned plans, models or measurement files.\n\n` +
    `| Check | Result |\n|---|---|\n| Semantic answers, statuses, work counters, dreaming/composition decisions, SOP regressions, policy choices and neural evaluation outcomes | Byte-identical |\n| Data files and manifest | ${datasets.length}/${datasets.length} byte-identical |\n| Learned plan/model files | ${checkpoints.length}/${checkpoints.length} byte-identical |\n| Original E00–E07 archive | SHA-256 unchanged |\n| First full run | ${(current.totalMs/1000).toFixed(2)} s |\n| Fresh full run | ${(fresh.totalMs/1000).toFixed(2)} s |\n\n` +
    `Semantic SHA-256: \`${semantic.sha256}\`.\n\n` +
    `All current tests and all current benchmark/learning/stress phases passed in both runs. Wall-clock timings and RSS are intentionally excluded from deterministic equality. Both runs use ${process.version} on the same machine and environment; this is reproducibility in a clean working directory, not independent external replication.\n\n` +
    `The original 79 historical unit tests were executed separately before packaging, as recorded in \`results/legacy-regression-current.log\`. This clean Node run verifies archive integrity and 15 retained historical records; it does not re-run old Python neural training.\n\n` +
    `Run again with \`node tools/verify-clean.mjs\` after \`make reproduce\`. Individual hashes are in \`results/CLEAN_REPRODUCTION.json\`.\n`;
  await writeFile(resolve(root, 'VERIFICATION.md'), md);
  console.log(`Fresh reproduction PASS: ${datasets.length} data files; ${checkpoints.length} plan/model files; semantic results identical.`);
} finally {
  await rm(scratch, { recursive: true, force: true });
}
