import test from 'node:test';
import assert from 'node:assert/strict';
import {parseSOP,reason,reference,Session,explain,verifyExplanation,learnPlans,verifyPlanBundle,SkillLibrary} from '../src/index.mjs';
const run=(s,opts={})=>reason(parseSOP(s),'q',opts);
const basic=`@f facts
FACT edge a b
FACT edge b c
FACT edge c b
@base rule
WHEN edge ?x ?y
THEN path ?x ?y
@rec rule
WHEN path ?x ?y
AND edge ?y ?z
THEN path ?x ?z
@q query
GIVES ?y
MATCH path a ?y`;
const variants=[{demand:false,factor:false,join:'source',indexed:false,mode:'naive'}, {demand:false,factor:false,join:'source'}, {demand:false}, {},{fuse:true}, {demand:true,indexed:false}, {demand:false,mode:'naive'}];
for(const [i,opts]of variants.entries())test(`recursive cycles exact variant ${i}`,()=>{const p=parseSOP(basic);assert.deepEqual(reason(p,'q',opts).rows,reference(p,'q').rows);});
test('all any and explicit NOT',()=>{const s=`@f facts
FACT p a
FACT q b
FACT NOT p c
@a all
GIVES ?x
MATCH p ?x
@b any
GIVES ?x
USE $a ?x
MATCH q ?x
@q query
GIVES ?x
USE $b ?x`;assert.deepEqual(run(s).rows,[['a'],['b']]);});
test('OR branches with conjunction',()=>{const s=`@f facts
FACT a 1
FACT b 1
FACT c 2
@r rule
WHEN a ?x
AND b ?x
OR c ?x
THEN good ?x
@q query
MATCH good ?x`;assert.deepEqual(run(s).rows,[[1],[2]]);});
test('negation waits for recursive stratum',()=>{const s=basic.replace('@q query','@n rule\nWHEN edge ?x ?y\nNONE path ?y ?x\nTHEN one_way ?x ?y\n@q query').replace('MATCH path a ?y','MATCH one_way a ?y');assert.deepEqual(run(s).rows,[['b']]);assert.equal(run(s).plan.demandApplied,false);});
test('negation cycle rejected',()=>assert.throws(()=>run(`@f facts
FACT d a
@a rule
WHEN d ?x
NONE b ?x
THEN a ?x
@b rule
WHEN d ?x
NONE a ?x
THEN b ?x
@q query
MATCH a ?x`),/negation/));
test('unsafe head rejected',()=>assert.throws(()=>parseSOP('@r rule\nWHEN a ?x\nTHEN b ?z'),/Unsafe/));
test('unsafe negation rejected',()=>assert.throws(()=>parseSOP('@q query\nMATCH a ?x\nNONE b ?y'),/Unsafe/));
test('arity mismatch rejected',()=>assert.throws(()=>parseSOP('@f facts\nFACT a 1\nFACT a 1 2'),/Arity/));
test('wire duplicate rejected',()=>assert.throws(()=>parseSOP('@f facts\nFACT a 1\n@f facts\nFACT a 2'),/Duplicate/));
test('quoted strings preserve hash and spaces',()=>assert.deepEqual(run('@f facts\nFACT p "a # b"\n@q query\nMATCH p ?x').rows,[['a # b']]));
test('typed constants do not alias',()=>assert.deepEqual(run('@f facts\nFACT p 1\nFACT p "1"\nFACT p true\n@q query\nMATCH p ?x').rows.sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))),[['1'],[1],[true]].sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)))));
test('unsafe numeric magnitude rejected',()=>assert.throws(()=>parseSOP('@f facts\nFACT p 9007199254740993'),/safe range/));
test('comparison types checked',()=>assert.throws(()=>run('@f facts\nFACT p abc\n@q query\nMATCH p ?x\nTEST ?x < 4'),/integer/));
test('ground boolean query has zero columns',()=>assert.deepEqual(run('@f facts\nFACT p a\n@q query\nMATCH p a').rows,[[]]));
test('empty answers are complete',()=>{const r=run('@f facts\nFACT p a\n@q query\nMATCH p b');assert.equal(r.status,'COMPLETE');assert.deepEqual(r.rows,[]);});
test('repeated variables unified',()=>assert.deepEqual(run('@f facts\nFACT p a b\nFACT p a a\n@q query\nMATCH p ?x ?x').rows,[['a']]));
test('duplicate facts and derivations use set semantics',()=>assert.deepEqual(run('@f facts\nFACT p a\nFACT p a\n@r rule\nWHEN p ?x\nTHEN p ?x\n@q query\nMATCH p ?x').rows,[['a']]));
test('EDB and IDB relation coexist with demand',()=>{const p=parseSOP(basic.replace('FACT edge a b','FACT path a d\nFACT edge a b'));assert.deepEqual(reason(p,'q').rows,reference(p,'q').rows);});
test('constant head demand transformation',()=>{const s='@f facts\nFACT p b\n@r rule\nWHEN p ?y\nTHEN edge a ?y\n@q query\nMATCH edge a ?x';assert.deepEqual(run(s).rows,[['b']]);});
test('repeated head variables demand transformation',()=>assert.deepEqual(run('@f facts\nFACT p a\n@r rule\nWHEN p ?x\nTHEN eq ?x ?x\n@q query\nMATCH eq a ?y').rows,[['a']]));
test('existential decomposition prevents irrelevant product',()=>{const facts=Array.from({length:50},(_,i)=>`FACT a ${i}\nFACT b ${i}`).join('\n');const p=parseSOP(`@f facts\n${facts}\n@q query\nGIVES ?x\nMATCH a ?x\nMATCH b ?y`);const a=reason(p,'q',{demand:false,factor:false}),b=reason(p,'q',{demand:false});assert.deepEqual(a.rows,b.rows);assert.ok(a.stats.candidateVisits>b.stats.candidateVisits*20);});
test('empty existential component kills all rows',()=>assert.deepEqual(run('@f facts\nFACT a 1\n@q query\nGIVES ?x\nMATCH a ?x\nMATCH empty ?y').rows,[]));
test('ground test-only rule prohibited without domain binding',()=>assert.throws(()=>parseSOP('@q query\nGIVES ?x\nTEST ?x > 0'),/Unsafe/));
test('work budget returns INCOMPLETE, never complete false',()=>{const r=run(basic,{maxWork:1});assert.equal(r.status,'INCOMPLETE');assert.equal(r.complete,false);});
for(const demand of [false,true])test(`proof replay and corruption ${demand}`,()=>{const p=parseSOP(basic);const r=reason(p,'q',{provenance:true,demand});const proof=explain(r);assert.equal(verifyExplanation(p,r,proof).valid,true);proof.nodes.find(n=>n.kind==='fact').tuple[0]='fake';assert.equal(verifyExplanation(p,r,proof).valid,false);});
test('negative proof requires completed snapshot',()=>{const p=parseSOP('@f facts\nFACT p a\n@q query\nMATCH p ?x\nNONE no ?x');const r=reason(p,'q',{provenance:true});assert.equal(verifyExplanation(p,r,explain(r)).valid,true);});
test('fork isolates facts; epochs reject stale handles',()=>{const s=new Session(parseSOP(basic));const old=s.query('q'),fork=s.fork();fork.assertFact('edge',['c','d']);assert.ok(fork.query('q').rows.some(r=>r[0]==='d'));assert.ok(!s.query('q').rows.some(r=>r[0]==='d'));assert.equal(fork.validateSnapshot(old.snapshot),'STALE');s.retractFact('edge',['a','b']);assert.equal(s.validateSnapshot(old.snapshot),'STALE');assert.deepEqual(s.query('q').rows,[]);});
test('same snapshot reuses cache',()=>{const s=new Session(parseSOP(basic));assert.equal(s.query('q').cacheHit,false);assert.equal(s.query('q').cacheHit,true);});
test('learned plans preserve rule semantics and reject malicious dropping',()=>{const p=parseSOP(basic),b=learnPlans([p],'q');assert.equal(verifyPlanBundle(p,b).valid,true);const lib=new SkillLibrary();lib.register(p,b);assert.deepEqual(reason(p,'q',{bundle:lib.lookup(p),demand:false}).rows,reference(p,'q').rows);b.plans['rec#0']=[0];assert.equal(verifyPlanBundle(p,b).valid,false);assert.throws(()=>reason(p,'q',{bundle:b}),/INVALID/);});
test('stale schema skill rejected',()=>{const p=parseSOP(basic),b=learnPlans([p],'q');b.schema='tampered';assert.throws(()=>reason(p,'q',{bundle:b}),/STALE/);});
test('fusion avoids variable capture and checks EDB guard',()=>{const s=`@f facts
FACT a p q
FACT b q r
FACT c r s
@inner rule
WHEN a ?x ?internal
AND b ?internal ?y
THEN ab ?x ?y
@outer rule
WHEN ab ?internal ?y
AND c ?y ?z
THEN abc ?internal ?z
@q query
MATCH abc ?x ?z`;const p=parseSOP(s);assert.deepEqual(reason(p,'q',{fuse:true}).rows,reference(p,'q').rows);const p2=parseSOP(s.replace('FACT a p q','FACT ab z r\nFACT a p q'));assert.deepEqual(reason(p2,'q',{fuse:true}).rows,reference(p2,'q').rows);});
