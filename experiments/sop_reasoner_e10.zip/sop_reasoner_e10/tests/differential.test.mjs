import test from 'node:test';
import assert from 'node:assert/strict';
import {parseSOP,reason,reference,explain,verifyExplanation} from '../src/index.mjs';
import {makeCase,sizes,rng,fact} from '../bench/families.mjs';
const variants=[{demand:false,indexed:false,mode:'naive',join:'source',factor:false},{demand:false,join:'source',factor:false},{demand:false},{},{fuse:true}];
for(const name of Object.keys(sizes))for(const seed of [0,1,2])test(`family ${name} seed ${seed}: five plans + independent oracle`,()=>{
  const c=makeCase(name,name==='rule_heavy'?12:name==='selective_join'?24:8,seed),p=parseSOP(c.text);
  assert.deepEqual(reference(p,'q',{maxWork:20_000_000}).rows,c.expected);
  for(const opts of variants){const r=reason(p,'q',{...opts,provenance:true});assert.equal(r.status,'COMPLETE');assert.deepEqual(r.rows,c.expected);if(r.count){const proof=explain(r);assert.equal(verifyExplanation(p,r,proof).valid,true);}}
});
for(let seed=0;seed<60;seed++)test(`random recursive rule program seed ${seed}`,()=>{
  const random=rng(seed),facts=[];for(let i=0;i<6;i++)for(let j=0;j<6;j++)if(random()<.22)facts.push(fact('edge',i,j));
  for(let i=0;i<6;i++)if(random()<.3)facts.push(fact('banned',i));
  const nonlinear=seed%3===0,neg=seed%2===0,bound=seed%4!==0;
  const text=`@facts facts\n${facts.join('\n')}\n@base rule\nWHEN edge ?a ?b\nTHEN p ?a ?b\n@rec rule\nWHEN p ?a ?b\nAND ${nonlinear?'p':'edge'} ?b ?c\nTHEN p ?a ?c\n@q query\nGIVES ${bound?'?y':'?x ?y'}\nMATCH p ${bound?'0':'?x'} ?y\n${neg?'NONE banned ?y':''}`;
  const p=parseSOP(text),expected=reference(p,'q',{maxWork:30_000_000}).rows;
  for(const opts of variants)assert.deepEqual(reason(p,'q',opts).rows,expected);
});
