import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseSOP,reason,reference,quotientOpportunities,
  Dreamer,VerifiedSkillStore,QuotientInventor,DecompositionInventor,DominanceInventor,RepresentationInventor,InvariantInventor,SkillComposer
} from '../src/index.mjs';

const rowsKey=x=>JSON.stringify(x);
function quotientProgram(n=100){const obs=Array.from({length:n},(_,i)=>`FACT observation target d${i}`).join('\n');return parseSOP(`@facts facts\nFACT selected target\n${obs}\n@r rule\nWHEN selected ?x\nAND observation ?x ?detail\nTHEN seen ?x\n@q query\nGIVES ?x\nMATCH seen ?x`);}
function factorProgram(n=30){const a=Array.from({length:n},(_,i)=>`FACT person p${i}`).join('\n'),b=Array.from({length:n},(_,i)=>`FACT badge b${i}`).join('\n');return parseSOP(`@facts facts\n${a}\n${b}\n@r rule\nWHEN person ?p\nAND badge ?b\nTHEN eligible ?p\n@q query\nGIVES ?p\nMATCH eligible ?p`);}
function reachProgram(n=16,noise=4){const facts=[];for(let i=0;i<n-1;i++)facts.push(`FACT edge root${i?'_'+i:''} root_${i+1}`);for(let c=0;c<noise;c++)for(let i=0;i<8;i++)facts.push(`FACT edge n${c}_${i} n${c}_${i+1}`);return parseSOP(`@facts facts\n${facts.join('\n')}\n@base rule\nWHEN edge ?x ?y\nTHEN path ?x ?y\n@step rule\nWHEN path ?x ?y\nAND edge ?y ?z\nTHEN path ?x ?z\n@q query\nGIVES ?y\nMATCH path root ?y`);}
function invariantProgram(seed=0){return parseSOP(`@facts facts\nFACT sensor s0 z0\nFACT sensor s1 z1\nFACT sensor s2 z0\nFACT sensor s3 z1\nFACT sensor s4 z0\nFACT selected target\nFACT observation target d${seed}\n@r rule\nWHEN selected ?x\nAND observation ?x ?d\nTHEN seen ?x\n@q query\nGIVES ?x\nMATCH seen ?x`);}

const pareto=parseSOP(`@facts facts
FACT label g 1 9
FACT label g 2 8
FACT label g 3 12
FACT label g 4 7
@dominance rule
WHEN label ?node ?costA ?resourceA
AND label ?node ?costB ?resourceB
TEST ?costA < ?costB
TEST ?resourceA <= ?resourceB
OR
MATCH label ?node ?costA ?resourceA
AND label ?node ?costB ?resourceB
TEST ?costA <= ?costB
TEST ?resourceA < ?resourceB
THEN dominated ?node ?costB ?resourceB
@q query
GIVES ?node ?cost ?resource
MATCH label ?node ?cost ?resource
NONE dominated ?node ?cost ?resource`);

test('E10 quotient eliminates irrelevant literal coordinates exactly',()=>{
  const p=quotientProgram(500),base=reason(p,'q',{demand:false,factor:false,quotient:false}),fast=reason(p,'q',{demand:false,factor:false,quotient:true});
  assert.equal(rowsKey(fast.rows),rowsKey(reference(p,'q').rows));assert.equal(fast.count,1);assert.ok(fast.stats.quotientSkipped>=499);assert.ok(fast.stats.candidateVisits*20<base.stats.candidateVisits);
  assert.ok(fast.plan.certificates.some(c=>c.kind==='existential-variable-quotient-v1'));
});

test('E10 quotient guard refuses variables that affect output/continuation',()=>{
  const p=parseSOP(`@facts facts\nFACT obs a 1\nFACT obs a 2\n@r rule\nWHEN obs ?x ?d\nTHEN seen ?x ?d\n@q query\nGIVES ?x ?d\nMATCH seen ?x ?d`);
  assert.equal(quotientOpportunities(p.rules).length,0);const a=reason(p,'q',{quotient:false,demand:false}),b=reason(p,'q',{quotient:true,demand:false});assert.equal(rowsKey(a.rows),rowsKey(b.rows));assert.equal(b.count,2);
});

test('E10 unified inventors discover quotient/decomposition/dominance/representation',()=>{
  const q=new QuotientInventor().propose([quotientProgram(20)],'q');assert.equal(q.length,1);
  const d=new DecompositionInventor().propose([factorProgram(10)],'q');assert.equal(d.length,1);
  const dom=new DominanceInventor().propose([pareto],'q');assert.equal(dom.length,1);
  const rep=new RepresentationInventor().propose([reachProgram(10,2)],'q');assert.equal(rep.length,1);
});

test('E10 empirical invariants are retained advisory-only and never deployed',()=>{
  const store=new VerifiedSkillStore(),dreamer=new Dreamer({store,minGain:0});const ps=[0,1,2].map(invariantProgram);
  const report=dreamer.consolidate(ps,'q',{learnPolicy:false,learnJoins:false,learnLemmas:false,learnInventors:true,inventors:[new InvariantInventor()]});
  assert.ok(report.promoted.length>0);assert.ok(store.records.some(r=>r.kind==='observed-invariant'&&r.status==='promoted'&&r.scope==='advisory-only'));
  const settings=store.promoted(ps[0],'q');assert.deepEqual(settings,{});assert.ok(store.advisories(ps[0],'q').length>0);
});

test('E10 skill composer selects an exact subset instead of enabling every promoted skill',()=>{
  const store=new VerifiedSkillStore(),train=[20,24,28].map(n=>reachProgram(n,20));const dreamer=new Dreamer({store,minGain:0,roundWeight:32,maxPromotedLemmas:1});
  dreamer.consolidate(train,'q',{learnPolicy:false,learnJoins:false,learnLemmas:true,learnInventors:true,inventors:[new RepresentationInventor()],compose:false,maxWork:2_000_000});
  const composer=new SkillComposer({store,roundWeight:32});const c=composer.compose(train,'q',{maxWork:2_000_000});assert.ok(c.recordId);assert.ok(c.best.exact);
  const held=reachProgram(40,40),r=reason(held,'q',{...store.promoted(held,'q'),maxWork:2_000_000}),o=reference(held,'q',{maxWork:100_000_000});assert.equal(rowsKey(r.rows),rowsKey(o.rows));assert.ok(r.complete);
});
