import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {parseSOP,reason,reference,explain,verifyExplanation} from '../src/index.mjs';import {rng,fact} from '../bench/families.mjs';
const example=readFileSync(new URL('../examples/pareto.sop',import.meta.url),'utf8');
for(let seed=0;seed<25;seed++)test(`Pareto compiler exact mixed signs seed ${seed}`,()=>{
  const random=rng(seed);let data='@labels facts\n';for(let i=0;i<40;i++)data+=fact('label',i%4,Math.floor(random()*20),Math.floor(random()*20))+'\n';
  let rules=example.slice(example.indexOf('@dominance'));
  if(seed%2)rules=rules.replaceAll('?costA < ?costB','?costA > ?costB').replaceAll('?costA <= ?costB','?costA >= ?costB');
  if(seed%3===0)rules=rules.replaceAll('?resourceA < ?resourceB','?resourceA > ?resourceB').replaceAll('?resourceA <= ?resourceB','?resourceA >= ?resourceB');
  const p=parseSOP(data+rules),r=reason(p,'q',{dominance:true,provenance:true});assert.deepEqual(r.rows,reference(p,'q').rows);assert.ok(r.plan.certificates.some(c=>c.kind==='pareto-2d-antijoin-v1'));
  if(r.count)assert.equal(verifyExplanation(p,r,explain(r)).valid,true);
});
test('Pareto guard rejects incomplete/non-strict relation',()=>{const p=parseSOP(example.replace('TEST ?costA < ?costB','TEST ?costA <= ?costB'));const r=reason(p,'q',{dominance:true});assert.ok(!r.plan.certificates.some(c=>c.kind==='pareto-2d-antijoin-v1'));assert.deepEqual(r.rows,reference(p,'q').rows);});
test('Pareto guard rejects extra input dominated facts',()=>{const p=parseSOP(example.replace('@labels facts','@labels facts\nFACT dominated checkpoint 2 8'));const r=reason(p,'q',{dominance:true});assert.ok(!r.plan.certificates.some(c=>c.kind==='pareto-2d-antijoin-v1'));assert.deepEqual(r.rows,reference(p,'q').rows);});
test('Pareto guard rejects bonus/objective-dependent condition',()=>{const p=parseSOP(example.replace('THEN dominated','TEST ?resourceA > 5\nTHEN dominated'));const r=reason(p,'q',{dominance:true});assert.ok(!r.plan.certificates.some(c=>c.kind==='pareto-2d-antijoin-v1'));assert.deepEqual(r.rows,reference(p,'q').rows);});
