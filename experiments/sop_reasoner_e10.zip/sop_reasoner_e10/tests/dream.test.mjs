import test from 'node:test';
import assert from 'node:assert/strict';
import {parseSOP,reason,reference,composeLemma,synthesizeCompositionLemmas,makeLemmaBundle,verifyLemmaBundle,Dreamer,VerifiedSkillStore,EpisodeJournal,AdaptiveReasoner} from '../src/index.mjs';

function chain(n){
  const facts=Array.from({length:n-1},(_,i)=>`FACT edge ${i} ${i+1}`).join('\n');
  return parseSOP(`@facts facts\n${facts}\n@base rule\nWHEN edge ?x ?y\nTHEN path ?x ?y\n@step rule\nWHEN path ?x ?y\nAND edge ?y ?z\nTHEN path ?x ?z\n@q query\nGIVES ?y\nMATCH path 0 ?y`);
}

test('constructive Horn composition yields an exact redundant lemma',()=>{
  const p=chain(18),c=composeLemma(p,'step#0','step#0',0);assert.equal(c.valid,true);assert.equal(c.rule.body.length,3);
  const skill={kind:'verified-composition-lemma-v1',schema:(synthesizeCompositionLemmas(p,'q').find(x=>x.rule.id===c.rule.id)).schema,query:'q',rule:c.rule,certificate:c.certificate,status:'candidate'};
  const bundle=makeLemmaBundle(p,'q',[skill]);const r=reason(p,'q',{demand:false,lemmaBundle:bundle});assert.deepEqual(r.rows,reference(p,'q').rows);assert.ok(r.stats.rounds<reason(p,'q',{demand:false}).stats.rounds);
});

test('tampered lemma certificate is rejected',()=>{
  const p=chain(12),skill=synthesizeCompositionLemmas(p,'q').find(x=>x.certificate.producer==='step#0'&&x.certificate.consumer==='step#0');
  const b=makeLemmaBundle(p,'q',[skill]);b.skills[0].rule.body.pop();assert.equal(verifyLemmaBundle(p,b,'q').valid,false);assert.throws(()=>reason(p,'q',{lemmaBundle:b}),/LEMMA_CERTIFICATE_MISMATCH|INVALID/);
});

test('dreaming promotes a shortcut on varied training instances and extrapolates',()=>{
  const store=new VerifiedSkillStore(),d=new Dreamer({store,roundWeight:32,minGain:.03});const report=d.consolidate([chain(24),chain(32),chain(40)],'q',{learnPolicy:false,learnJoins:false,learnLemmas:true});
  assert.ok(report.promoted.length>=1);const testp=chain(64),skills=store.promoted(testp,'q'),base=reason(testp,'q',{demand:false}),fast=reason(testp,'q',{demand:false,...skills});
  assert.deepEqual(fast.rows,reference(testp,'q').rows);assert.ok(fast.stats.rounds<base.stats.rounds/2);
});

test('schema mismatch prevents automatic reuse of a learned skill',()=>{
  const store=new VerifiedSkillStore(),d=new Dreamer({store});d.consolidate([chain(20),chain(24),chain(28)],'q',{learnPolicy:false,learnJoins:false,learnLemmas:true});
  const changed=parseSOP(`@facts facts\nFACT edge 0 1\n@base rule\nWHEN edge ?x ?y\nTHEN path ?x ?y\n@q query\nGIVES ?y\nMATCH path 0 ?y`);
  assert.deepEqual(store.promoted(changed,'q'),{});
});

test('journal captures replayable episodes but not oversized programs',()=>{
  const j=new EpisodeJournal({maxFacts:5}),small=chain(5),large=chain(20);j.record(small,'q',reason(small,'q'),{},{});j.record(large,'q',reason(large,'q'),{},{});
  assert.ok(j.entries[0].program);assert.equal(j.entries[1].program,null);
});

test('adaptive reasoner deploys only promoted skills and journals execution',()=>{
  const store=new VerifiedSkillStore(),j=new EpisodeJournal(),a=new AdaptiveReasoner({store,journal:j});a.dreamer.consolidate([chain(24),chain(32),chain(40)],'q',{learnPolicy:false,learnJoins:false,learnLemmas:true});
  const p=chain(56),r=a.run(p,'q',{demand:false},{task:'heldout'});assert.deepEqual(r.rows,reference(p,'q').rows);assert.equal(j.entries.length,1);assert.equal(j.entries[0].meta.task,'heldout');assert.ok(r.plan.certificates.some(c=>c.kind==='verified-lemma-bundle-v1'));
});

test('skill store preserves candidate/rejected/promoted lifecycle',()=>{
  const p=chain(8),store=new VerifiedSkillStore(),r=store.add({kind:'manual-test',schema:'x',query:'q',artifact:{a:1}});assert.equal(r.status,'candidate');store.setStatus(r.id,'rejected','counterexample');assert.equal(store.records[0].status,'rejected');assert.equal(store.records[0].history.length,2);
});

test('a lemma may be sound but rejected when it does not improve the cost model',()=>{
  const p=chain(5),store=new VerifiedSkillStore(),d=new Dreamer({store,roundWeight:0,minGain:.90,maxPromotedLemmas:2});const report=d.consolidate([p,p,p],'q',{learnPolicy:false,learnJoins:false,learnLemmas:true});
  assert.equal(report.promoted.length,0);assert.ok(report.rejected.length>0);
});
