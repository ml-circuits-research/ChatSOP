import {mkdir,open,readFile,writeFile} from 'node:fs/promises';import {createReadStream} from 'node:fs';
import {fileURLToPath} from 'node:url';import {resolve} from 'node:path';import {createHash} from 'node:crypto';
import {loadSOP,reason} from '../src/index.mjs';import {reachRules} from './families.mjs';import {sqliteBaseline} from './sqlite.mjs';
const root=fileURLToPath(new URL('..',import.meta.url));
const hashFile=async path=>{const h=createHash('sha256');for await(const b of createReadStream(path))h.update(b);return h.digest('hex');};
const config={sizes:[100000,1000000],componentWidth:8,maxWork:10000000,seeds:'deterministic-ring-components',explanation:'Every fact belongs to the SAME edge predicate. Query targets one 8-node component. Global parsing/loading/index costs are reported.'};
await mkdir(resolve(root,'data/stress'),{recursive:true});const rows=[];
for(const n of config.sizes){
  const path=resolve(root,`data/stress/edges-${n}.sop`);let fh=null;try{fh=await open(path,'wx');}catch(e){if(e.code!=='EEXIST')throw e;}const generated=createHash('sha256');const emit=async text=>{generated.update(text);if(fh)await fh.write(text);};
  try{await emit('@facts facts\nSOURCE "synthetic://same-predicate-rings"\n');
    for(let start=0;start<n;start+=10000){let chunk='';for(let i=start;i<Math.min(start+10000,n);i++)chunk+=`FACT edge ${i} ${Math.floor(i/8)*8+(i+1)%8}\n`;await emit(chunk);}
    await emit(`${reachRules}\n@q query\nGIVES ?y\nMATCH path 0 ?y\n`);
  }finally{if(fh)await fh.close();}
  if(await hashFile(path)!==generated.digest('hex'))throw new Error('Frozen stress dataset changed');
  const checksum=await hashFile(path),parseStart=performance.now(),p=await loadSOP(path),parseMs=performance.now()-parseStart;
  for(const mode of ['indexed-budgeted','verified']){
    global.gc?.();const started=performance.now();
    const r=reason(p,'q',{demand:mode==='verified',factor:mode==='verified',join:'greedy',maxWork:mode==='verified'?10000000:250000,maxMs:30000});
    const expected=Array.from({length:8},(_,i)=>[i]);if(r.complete&&JSON.stringify(r.rows)!==JSON.stringify(expected))throw new Error('Stress answer mismatch');
    rows.push({n,mode,sha256:checksum,status:r.status,stopReason:r.stopReason,rows:r.rows,parseMs,engineWallMs:performance.now()-started,stats:r.stats,rssMB:process.memoryUsage().rss/1048576});
  }
  global.gc?.();const sql=await sqliteBaseline(p,'WITH RECURSIVE reach(y) AS (SELECT c1 FROM edge WHERE c0=0 UNION SELECT e.c1 FROM reach p JOIN edge e ON p.y=e.c0) SELECT y FROM reach');
  if(sql.status==='COMPLETE'&&JSON.stringify(sql.rows)!==JSON.stringify(Array.from({length:8},(_,i)=>[i])))throw new Error('Stress SQL mismatch');
  rows.push({n,mode:'sqlite',sha256:checksum,parseMs,...sql});console.log(`stress ${n} facts complete`);
}
await writeFile(resolve(root,'results/stress.json'),JSON.stringify({config,results:rows,peakRssMB:process.resourceUsage().maxRSS/1024},null,2));
