/** Synthetic workloads with independent, procedural answer oracles.
 * Generators do NOT call the reasoner to construct expected answers. */
export function rng(seed=0){let a=seed>>>0;return ()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};}
const rowsort=rows=>rows.sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
export const fact=(name,...values)=>`FACT ${name} ${values.map(x=>JSON.stringify(x)).join(' ')}`;
const program=(facts,rules)=>`@data facts\nSOURCE "synthetic://deterministic"\n${facts.join('\n')}\n${rules}\n`;
export const reachRules=`@base rule
WHEN edge ?x ?y
THEN path ?x ?y
@step rule
WHEN path ?x ?y
AND edge ?y ?z
THEN path ?x ?z`;
export function bfs(edges,start){const a=new Map();for(const [x,y]of edges){if(!a.has(x))a.set(x,[]);a.get(x).push(y);}const seen=new Set(),queue=[start];for(let i=0;i<queue.length;i++)for(const y of a.get(queue[i])||[])if(!seen.has(y)){seen.add(y);queue.push(y);}return [...seen];}
export const sizes={disconnected:480,deep_recursion:320,dense_cycle:32,nonlinear_recursion:36,selective_join:3000,existential:600,policy:1600,temporal:360,triangles:40,mutual_recursion:240,rule_heavy:800,or_evidence:4000,output_cartesian:150};
export function makeCase(name,n,seed=0){
  const random=rng(seed),facts=[],edges=[];let text,expected,sql=null,control=false;
  const edge=(a,b)=>{edges.push([a,b]);facts.push(fact('edge',a,b));};
  if(['disconnected','deep_recursion','dense_cycle','nonlinear_recursion'].includes(name)){
    if(name==='disconnected'){for(let i=0;i<n;i++)if(i%12<11&&i+1<n){edge(i,i+1);if(i%12<10&&i+2<n)edge(i,i+2);}}
    if(name==='deep_recursion')for(let i=0;i<n-1;i++)edge(i,i+1);
    if(name==='dense_cycle'){for(let i=0;i<n;i++){edge(i,(i+1)%n);for(let j=0;j<n;j++)if(i!==j&&random()<.12)edge(i,j);}control=true;}
    if(name==='nonlinear_recursion'){for(let i=0;i<n-1;i++){edge(i,i+1);if(i+2<n&&random()<.5)edge(i,i+2);}}
    const q=name==='dense_cycle'?`@q query\nGIVES ?x ?y\nMATCH path ?x ?y`:`@q query\nGIVES ?y\nMATCH path 0 ?y`;
    let rules=reachRules;if(name==='nonlinear_recursion')rules=rules.replace('AND edge ?y ?z','AND path ?y ?z');
    text=program(facts,`${rules}\n${q}`);
    expected=name==='dense_cycle'?Array.from({length:n},(_,x)=>bfs(edges,x).map(y=>[x,y])).flat():bfs(edges,0).map(y=>[y]);
    sql=name==='dense_cycle'?`WITH RECURSIVE path(x,y) AS (SELECT c0,c1 FROM edge UNION SELECT p.x,e.c1 FROM path p JOIN edge e ON p.y=e.c0) SELECT x,y FROM path`:`WITH RECURSIVE reach(y) AS (SELECT c1 FROM edge WHERE c0=0 UNION SELECT e.c1 FROM reach p JOIN edge e ON p.y=e.c0) SELECT y FROM reach`;
  }else if(name==='selective_join'){
    const g=17,chosen=n-1;for(let i=0;i<n;i++){facts.push(fact('r',i,i%g));facts.push(fact('s',i%g,i));}facts.push(fact('chosen',chosen));
    text=program(facts,`@q query\nGIVES ?x\nMATCH r ?x ?y\nMATCH s ?y ?z\nMATCH chosen ?z`);
    expected=Array.from({length:n},(_,i)=>i).filter(i=>i%g===chosen%g).map(i=>[i]);
    sql='SELECT DISTINCT r.c0 FROM chosen c JOIN s ON s.c1=c.c0 JOIN r ON r.c1=s.c0';
  }else if(name==='existential'){
    for(let i=0;i<n;i++){facts.push(fact('person',i));facts.push(fact('witness',i));}
    text=program(facts,'@q query\nGIVES ?x\nMATCH person ?x\nMATCH witness ?y');expected=Array.from({length:n},(_,i)=>[i]);
    sql='SELECT c0 FROM person WHERE EXISTS (SELECT 1 FROM witness)';
  }else if(name==='policy'){
    for(let i=0;i<n;i++){facts.push(fact('member',i,i%16));if(i%7===0)facts.push(fact('denied',i,0));}
    for(let role=0;role<16;role++)for(let resource=0;resource<4;resource++)facts.push(fact('grant',role,resource));
    text=program(facts,'@permission rule\nWHEN member ?u ?role\nAND grant ?role ?resource\nNONE denied ?u ?resource\nTHEN can ?u ?resource\n@q query\nGIVES ?u ?resource\nMATCH can ?u ?resource');
    expected=[];for(let u=0;u<n;u++)for(let resource=0;resource<4;resource++)if(resource!==0||u%7!==0)expected.push([u,resource]);
    sql='SELECT m.c0,g.c1 FROM member m JOIN "grant" g ON m.c1=g.c0 WHERE NOT EXISTS (SELECT 1 FROM denied d WHERE d.c0=m.c0 AND d.c1=g.c1)';
  }else if(name==='temporal'){
    const events=[];for(let i=0;i<n;i++){const row=[i%15,Math.floor(random()*n)];events.push(row);facts.push(fact('event',...row));}
    text=program(facts,'@q query\nGIVES ?entity\nMATCH event ?entity ?a\nMATCH event ?entity ?b\nTEST ?a < ?b');
    expected=[];for(let e=0;e<15;e++){const times=events.filter(r=>r[0]===e).map(r=>r[1]);if(new Set(times).size>1)expected.push([e]);}
    sql='SELECT DISTINCT a.c0 FROM event a JOIN event b ON a.c0=b.c0 WHERE a.c1<b.c1';control=true;
  }else if(name==='triangles'){
    for(let i=0;i<n;i++)for(let j=0;j<n;j++)if(i!==j&&random()<.18)edge(i,j);
    text=program(facts,'@q query\nGIVES ?x ?y ?z\nMATCH edge ?x ?y\nMATCH edge ?y ?z\nMATCH edge ?z ?x');
    const has=new Set(edges.map(r=>r.join(',')));expected=[];for(let x=0;x<n;x++)for(let y=0;y<n;y++)if(has.has(`${x},${y}`))for(let z=0;z<n;z++)if(has.has(`${y},${z}`)&&has.has(`${z},${x}`))expected.push([x,y,z]);
    sql='SELECT DISTINCT a.c0 AS x,a.c1 AS y,b.c1 AS z FROM edge a JOIN edge b ON a.c1=b.c0 JOIN edge c ON c.c0=b.c1 AND c.c1=a.c0';control=true;
  }else if(name==='mutual_recursion'){
    for(let i=0;i<n-1;i++)edge(i,i+1);facts.push(fact('seed',0));
    text=program(facts,'@base rule\nWHEN seed ?x\nTHEN p ?x\n@pq rule\nWHEN p ?x\nTHEN q ?x\n@qp rule\nWHEN q ?x\nAND edge ?x ?y\nTHEN p ?y\n@q query\nMATCH p ?x');
    expected=Array.from({length:n},(_,i)=>[i]);
  }else if(name==='rule_heavy'){
    let rules='';for(let i=0;i<n;i++){facts.push(fact(`raw${i}`,i));rules+=`@r${i} rule\nWHEN raw${i} ?x\nTHEN cooked${i} ?x\n`;}
    text=program(facts,`${rules}@q query\nMATCH cooked0 ?x`);expected=[[0]];
  }else if(name==='or_evidence'){
    for(let i=0;i<n;i++){facts.push(fact('a',i));if(i%2===0)facts.push(fact('b',i));if(i%3===0)facts.push(fact('c',i));}
    text=program(facts,'@union any\nGIVES ?x\nMATCH a ?x\nMATCH b ?x\nMATCH c ?x\n@q query\nGIVES ?x\nUSE $union ?x');expected=Array.from({length:n},(_,i)=>[i]);
    sql='SELECT c0 FROM a UNION SELECT c0 FROM b UNION SELECT c0 FROM c';
  }else if(name==='output_cartesian'){
    for(let i=0;i<n;i++){facts.push(fact('a',i));facts.push(fact('b',i));}
    text=program(facts,'@q query\nGIVES ?x ?y\nMATCH a ?x\nMATCH b ?y');expected=[];for(let x=0;x<n;x++)for(let y=0;y<n;y++)expected.push([x,y]);
    sql='SELECT a.c0 AS x,b.c0 AS y FROM a CROSS JOIN b';control=true;
  }else throw new Error(`Unknown family ${name}`);
  return {name,n,seed,text,expected:rowsort(expected),sql,control,factCount:facts.length};
}

export function paretoCase(n,seed=0){
  const random=rng(seed),facts=[],labels=[];
  for(let i=0;i<n;i++){const row=[i%8,Math.floor(random()*n)+1,Math.floor(random()*n)+1];labels.push(row);facts.push(fact('label',...row));}
  const rules=`@dominance rule
WHEN label ?g ?a ?b
AND label ?g ?c ?d
TEST ?a < ?c
TEST ?b <= ?d
OR
MATCH label ?g ?a ?b
AND label ?g ?c ?d
TEST ?a <= ?c
TEST ?b < ?d
THEN dominated ?g ?c ?d
@q query
GIVES ?g ?c ?d
MATCH label ?g ?c ?d
NONE dominated ?g ?c ?d`;
  // Independent pairwise definition. No sweep/compiler calls in the oracle.
  const expected=labels.filter(b=>!labels.some(a=>a[0]===b[0]&&a[1]<=b[1]&&a[2]<=b[2]&&(a[1]<b[1]||a[2]<b[2])));
  const unique=[...new Map(expected.map(t=>[JSON.stringify(t),t])).values()];
  return {name:'pareto',n,seed,text:program(facts,rules),expected:rowsort(unique),control:false,factCount:n,
    sql:'SELECT DISTINCT b.c0,b.c1,b.c2 FROM label b WHERE NOT EXISTS (SELECT 1 FROM label a WHERE a.c0=b.c0 AND a.c1<=b.c1 AND a.c2<=b.c2 AND (a.c1<b.c1 OR a.c2<b.c2))'};
}
