import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';import {fileURLToPath} from 'node:url';import os from 'node:os';import {createHash} from 'node:crypto';
import {parseSOP,reason,learnPlans} from '../src/index.mjs';import {digest} from '../src/analyze.mjs';
import {makeCase,paretoCase,sizes} from './families.mjs';import {sqliteBaseline} from './sqlite.mjs';
const root=fileURLToPath(new URL('..',import.meta.url));
const config={version:1,seeds:[101,202,303],trainingSeeds:[0,1,2],trainingN:24,sizes:{...sizes,pareto:2200},
  maxWork:5_000_000,scanMaxWork:500_000,maxMs:20000,notes:['All sizes/configurations fixed before the first main benchmark.','Performance claims use only complete paired runs.','SQLite uses hand-written per-family SQL and separate load timings.','Set answers, not proof counts.']};
const modes={
  scan_naive:{mode:'naive',indexed:false,join:'source',factor:false,demand:false,maxWork:config.scanMaxWork},
  indexed_semi:{join:'source',factor:false,demand:false},
  greedy_semi:{join:'greedy',factor:false,demand:false},
  verified:{join:'greedy',factor:true,demand:true,fuse:true,dominance:true},
  learned:{join:'source',factor:true,demand:false}
};
export async function frozen(path,text){await mkdir(resolve(path,'..'),{recursive:true});try{const old=await readFile(path,'utf8');if(old!==text)throw new Error(`Frozen file changed: ${path}`);}catch(e){if(e.code!=='ENOENT')throw e;await writeFile(path,text);}}
await mkdir(resolve(root,'results'),{recursive:true});await frozen(resolve(root,'bench/config.json'),JSON.stringify(config,null,2)+'\n');
const make=(name,n,seed)=>name==='pareto'?paretoCase(n,seed):makeCase(name,n,seed);
const bundles={},training=[];const begin=performance.now();
// Freeze all learned plans before constructing test instances.
for(const name of Object.keys(config.sizes)){
  const train= config.trainingSeeds.map(seed=>make(name,config.trainingN,seed));
  for(const c of train)await frozen(resolve(root,`data/train/${name}-${c.seed}.sop`),c.text);
  const started=performance.now();const bundle=learnPlans(train.map(c=>parseSOP(c.text)),'q',{maxLiterals:3,maxCandidates:24,maxWork:500000});
  bundles[name]=bundle;await writeFile(resolve(root,`results/skills-${name}.json`),JSON.stringify(bundle,null,2));
  training.push({family:name,trainMs:performance.now()-started,trials:bundle.trace.length,selected:bundle.plans,schema:bundle.schema});
}
await writeFile(resolve(root,'results/training.json'),JSON.stringify(training,null,2));
const results=[];const hashes=[];
for(const [family,n]of Object.entries(config.sizes))for(const seed of config.seeds){
  const c=make(family,n,seed);const file=`data/test/${family}-${seed}.sop`;await frozen(resolve(root,file),c.text);hashes.push({file,sha256:createHash('sha256').update(c.text).digest('hex'),oracleHash:digest(c.expected)});
  const parseStart=performance.now(),p=parseSOP(c.text,file),parseMs=performance.now()-parseStart;
  for(const [mode,settings]of Object.entries(modes)){
    if(global.gc)global.gc();const started=performance.now();let row;
    if(mode==='learned'&&family==='rule_heavy'){row={status:'NOT_APPLICABLE',reason:'rule schema grows with benchmark size; old plan deliberately not reused'};}
    else{
      const r=reason(p,'q',{maxWork:config.maxWork,maxMs:config.maxMs,...settings,...(mode==='learned'?{bundle:bundles[family]}:{})});
      const wallMs=performance.now()-started;
      const expected=new Set(c.expected.map(JSON.stringify));const sound=r.rows.every(t=>expected.has(JSON.stringify(t))),correct=r.complete&&digest(r.rows)===digest(c.expected);
      if(!sound||r.complete&&!correct)throw new Error(`WRONG ANSWER ${family}/${seed}/${mode}`);
      row={status:r.status,stopReason:r.stopReason,correct,sound,count:r.count,answerHash:digest(r.rows),wallMs,stats:r.stats,certificates:r.plan.certificates.map(c=>c.kind),demand:r.plan.demandApplied};
    }
    results.push({family,n,seed,mode,facts:c.factCount,rules:p.rules.length,parseMs,control:c.control,...row});
  }
  const sql=await sqliteBaseline(p,c.sql);if(sql.status==='COMPLETE'&&digest(sql.rows)!==digest(c.expected))throw new Error(`SQL mismatch ${family}`);
  const {rows,...sqlMeta}=sql;results.push({family,n,seed,mode:'sqlite',facts:c.factCount,rules:p.rules.length,parseMs,control:c.control,...sqlMeta,...(rows?{correct:true,answerHash:digest(rows)}:{})});
  await writeFile(resolve(root,'results/benchmark.json'),JSON.stringify(results,null,2));
  console.log(`${family} seed=${seed} answers=${c.expected.length} verified=${results.find(r=>r.family===family&&r.seed===seed&&r.mode==='verified')?.status}`);
}
await writeFile(resolve(root,'data/MANIFEST.json'),JSON.stringify(hashes,null,2));
await writeFile(resolve(root,'results/environment.json'),JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,cpu:os.cpus()[0]?.model,logicalCores:os.cpus().length,totalMemory:os.totalmem(),durationMs:performance.now()-begin,peakRssMB:process.resourceUsage().maxRSS/1024,config},null,2));
console.log(`Completed ${results.length} rows in ${((performance.now()-begin)/1000).toFixed(2)} s`);
