import {writeFile} from 'node:fs/promises';import {resolve} from 'node:path';import {fileURLToPath} from 'node:url';
import {parseSOP,reason,Ranker} from '../src/index.mjs';import {permutations} from '../src/skills.mjs';import {rng,fact} from './families.mjs';import {digest,schemaHash} from '../src/analyze.mjs';
const root=fileURLToPath(new URL('..',import.meta.url));
const orders=[...permutations([0,1,2])];
function problem(n,seed){
  const random=rng(seed),group=3+Math.floor(random()*12),selectLeft=seed%2===0,facts=[];
  for(let i=0;i<n;i++){facts.push(fact('r',i,i%group));facts.push(fact('s',i%group,i));}
  const chosen=[];for(let i=0;i<n;i++)if(random()<.08){chosen.push(i);facts.push(fact('selected',i));}if(!chosen.length){chosen.push(0);facts.push(fact('selected',0));}
  const text=`@f facts\n${facts.join('\n')}\n@q query\nGIVES ?x ?z\nMATCH r ?x ?y\nMATCH s ?y ?z\nMATCH selected ${selectLeft?'?x':'?z'}`;
  const p=parseSOP(text),selected=new Set(chosen),expected=[];
  for(let x=0;x<n;x++)for(let z=0;z<n;z++)if(x%group===z%group&&selected.has(selectLeft?x:z))expected.push([x,z]);
  expected.sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return {p,expected};
}
function features(program,order){
  const rule=program.rules[0],relations=new Map();for(const f of program.facts){if(!relations.has(f.pred))relations.set(f.pred,[]);relations.get(f.pred).push(f.terms);}
  const bound=new Set(),x=[];let estimate=1,cost=0;
  for(const index of order){const l=rule.body[index],rows=relations.get(l.pred)||[],positions=l.terms.map((t,i)=>bound.has(t.var)?i:-1).filter(i=>i>=0);
    let fanout=rows.length;for(const pos of positions)fanout/=Math.max(1,new Set(rows.map(r=>r[pos])).size);
    cost+=estimate*fanout;estimate*=Math.max(fanout,.0001);
    x.push(Math.log1p(rows.length)/10,positions.length/l.terms.length,Math.log1p(fanout)/10);l.terms.forEach(t=>bound.add(t.var));
  }
  return {x,heuristic:Math.log1p(cost)};
}
function measure(p,order){return reason(p,'q',{demand:false,factor:false,join:'source',plans:{'q#0':order},maxWork:5_000_000});}
const samples=[];let trainingTrials=0;const start=performance.now();
for(let seed=0;seed<30;seed++){
  const {p,expected}=problem(24+(seed%3)*8,seed);
  for(const order of orders){const r=measure(p,order);if(!r.complete||digest(r.rows)!==digest(expected))throw new Error('Neural training oracle failure');samples.push({x:features(p,order).x,y:Math.log1p(r.stats.candidateVisits)/10});trainingTrials++;}
}
const models=[0,1,2].map(seed=>new Ranker(9,12,seed).fit(samples,{epochs:500,lr:.015}));const trainMs=performance.now()-start;
// Freeze before constructing held-out tasks. Network outputs only rank legal permutations.
await writeFile(resolve(root,'results/neural-rankers.json'),JSON.stringify(models,null,2));
const results=[];
for(let seed=101;seed<113;seed++){
  const {p,expected}=problem(180+(seed%3)*60,seed),costs=[];
  for(const order of orders){const r=measure(p,order);if(!r.complete||digest(r.rows)!==digest(expected))throw new Error('Neural test oracle failure');costs.push(r.stats.candidateVisits);}
  const optimum=Math.min(...costs),qualifies=i=>costs[i]<=optimum*1.10;
  const heuristic=orders.map((o,i)=>({i,score:features(p,o).heuristic})).sort((a,b)=>a.score-b.score||a.i-b.i).map(r=>r.i);
  const lexical=[0,1,2,3,4,5];const rank=ordering=>ordering.findIndex(qualifies)+1;
  const randomMean=(orders.length+1)/(costs.filter(c=>c<=optimum*1.1).length+1);
  models.forEach((m,modelSeed)=>{const proposal=orders.map((o,i)=>({i,score:m.predict(features(p,o).x)})).sort((a,b)=>a.score-b.score||a.i-b.i).map(r=>r.i);
    results.push({taskSeed:seed,modelSeed,optimum,costs,neuralRank:rank(proposal),heuristicRank:rank(heuristic),lexicalRank:rank(lexical),randomExpectedRank:randomMean,neuralRegret:costs[proposal[0]]/optimum,heuristicRegret:costs[heuristic[0]]/optimum,correct:true});
  });
}
await writeFile(resolve(root,'results/neural.json'),JSON.stringify({trainingTrials,trainingSamples:samples.length,trainMs,model:'9 inputs; 12 tanh hidden; scalar log-cost; 3 seeds; all .mjs',note:'All six test costs are measured for offline evaluation only, never fed to the trained rankers. Tuple probes exclude feature extraction and neural inference; do not infer end-to-end speedup from rank alone.',results},null,2));
console.log('Neural proposer: 36 held-out task/seed rows.');
