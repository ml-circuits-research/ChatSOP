import {mkdir,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {
  parseSOP,reason,Dreamer,VerifiedSkillStore,SkillComposer,
  QuotientInventor,DecompositionInventor,DominanceInventor,RepresentationInventor,InvariantInventor
} from '../src/index.mjs';

const root=fileURLToPath(new URL('..',import.meta.url));
const rowsKey=rows=>JSON.stringify(rows);

function world({chain=16,noiseComponents=8,noiseLength=8,observations=100,people=20,pareto=50,sensors=50,large=false}={}){
  const facts=[];
  for(let i=0;i<chain;i++)facts.push(`FACT edge ${i===0?'root':`r${i}`} r${i+1}`);
  for(let c=0;c<noiseComponents;c++)for(let i=0;i<noiseLength;i++)facts.push(`FACT edge c${c}_${i} c${c}_${i+1}`);
  facts.push('FACT selected target');for(let i=0;i<observations;i++)facts.push(`FACT observation target d${i}`);
  for(let i=0;i<people;i++){facts.push(`FACT person p${i}`);facts.push(`FACT badge b${i}`);}
  // Tradeoff curve: lower cost always has higher resource; no row dominates another.
  for(let i=0;i<pareto;i++)facts.push(`FACT label checkpoint ${i+1} ${pareto-i+1}`);
  for(let i=0;i<sensors;i++)facts.push(`FACT sensor s${i} zone${i%17}`);
  const text=`# E10 ${large?'large':'training'} multi-domain SOP world\n@facts facts\nSOURCE "synthetic://e10-world"\n${facts.join('\n')}\n\n`+
`@reach-base rule\nWHEN edge ?x ?y\nTHEN path ?x ?y\n@reach-step rule\nWHEN path ?x ?y\nAND edge ?y ?z\nTHEN path ?x ?z\n@reach query\nGIVES ?y\nMATCH path root ?y\n\n`+
`@visible-rule rule\nWHEN selected ?x\nAND observation ?x ?detail\nTHEN visible ?x\n@visible query\nGIVES ?x\nMATCH visible ?x\n\n`+
`@eligible-rule rule\nWHEN person ?p\nAND badge ?b\nTHEN eligible ?p\n@eligible query\nGIVES ?p\nMATCH eligible ?p\n\n`+
`@dominance rule\nWHEN label ?node ?costA ?resourceA\nAND label ?node ?costB ?resourceB\nTEST ?costA < ?costB\nTEST ?resourceA <= ?resourceB\nOR\nMATCH label ?node ?costA ?resourceA\nAND label ?node ?costB ?resourceB\nTEST ?costA <= ?costB\nTEST ?resourceA < ?resourceB\nTHEN dominated ?node ?costB ?resourceB\n@pareto query\nGIVES ?node ?cost ?resource\nMATCH label ?node ?cost ?resource\nNONE dominated ?node ?cost ?resource\n`;
  return {text,factCount:facts.length,expected:{reach:chain,visible:1,eligible:people,pareto}};
}

function largeWorld(){
  // Exactly 106,800 extensional facts.
  return world({chain:40,noiseComponents:4996,noiseLength:10,observations:25000,people:500,pareto:900,sensors:29899,large:true});
}

await mkdir(resolve(root,'data/e10'),{recursive:true});await mkdir(resolve(root,'results'),{recursive:true});
const trainSpecs=[
  {chain:12,noiseComponents:8,noiseLength:8,observations:100,people:20,pareto:50,sensors:60},
  {chain:16,noiseComponents:10,noiseLength:8,observations:120,people:25,pareto:60,sensors:70},
  {chain:20,noiseComponents:12,noiseLength:8,observations:140,people:30,pareto:70,sensors:80}
];
const train=trainSpecs.map(world);for(let i=0;i<train.length;i++)await writeFile(resolve(root,`data/e10/train-${i}.sop`),train[i].text);
const programs=train.map(x=>parseSOP(x.text,`data/e10/train.sop`)),store=new VerifiedSkillStore();
const reports={},compositions={};
const config={minGain:.01,roundWeight:32,maxPromotedLemmas:1};

async function learn(query,{lemmas=false,inventors=[]}={}){
  const dreamer=new Dreamer({store,...config});reports[query]=dreamer.consolidate(programs,query,{learnPolicy:false,learnJoins:false,learnLemmas:lemmas,learnInventors:true,inventors,compose:false,maxWork:5_000_000});
  const composer=new SkillComposer({store,roundWeight:config.roundWeight});compositions[query]=composer.compose(programs,query,{maxWork:5_000_000});
}
await learn('reach',{lemmas:true,inventors:[new RepresentationInventor()]});
await learn('visible',{inventors:[new QuotientInventor(),new InvariantInventor()]});
await learn('eligible',{inventors:[new DecompositionInventor()]});
await learn('pareto',{inventors:[new DominanceInventor()]});

const big=largeWorld();if(big.factCount!==106800)throw new Error(`E10 fact count ${big.factCount} != 106800`);await writeFile(resolve(root,'data/e10/large-world.sop'),big.text);
const p=parseSOP(big.text,'data/e10/large-world.sop');
const baselineOptions={demand:false,factor:false,quotient:false,fuse:false,dominance:false};
const budgets={reach:300_000,visible:1_000_000,eligible:1_000_000,pareto:2_000_000};
const results=[];
for(const query of ['reach','visible','eligible','pareto']){
  const base=reason(p,query,{...baselineOptions,maxWork:budgets[query],maxMs:30_000});
  const settings=store.promoted(p,query);const fast=reason(p,query,{...baselineOptions,...settings,maxWork:5_000_000,maxMs:30_000});
  const exact=fast.complete&&fast.count===big.expected[query];if(!exact)throw new Error(`E10 wrong result ${query}: ${fast.status}/${fast.count} expected ${big.expected[query]}`);
  results.push({query,expected:big.expected[query],baseline:{status:base.status,count:base.count,candidateVisits:base.stats.candidateVisits,rounds:base.stats.rounds,totalMs:base.stats.totalMs},
    learned:{status:fast.status,count:fast.count,candidateVisits:fast.stats.candidateVisits,rounds:fast.stats.rounds,totalMs:fast.stats.totalMs,quotientSkipped:fast.stats.quotientSkipped,certificates:fast.plan.certificates.map(c=>c.kind)},
    deployment:store.records.filter(r=>r.status==='promoted'&&r.kind==='deployment-plan'&&r.query===query).at(-1)?.artifact||null,
    exact});
}
const advisories=store.records.filter(r=>r.status==='promoted'&&r.scope==='advisory-only').map(r=>({id:r.id,family:r.family,query:r.query,artifact:r.artifact}));
const out={kind:'e10-unified-dreamer-benchmark-v1',factCount:big.factCount,trainingFacts:train.map(x=>x.factCount),config,reports,compositions,results,advisories,skillCounts:{total:store.records.length,promoted:store.records.filter(r=>r.status==='promoted').length,rejected:store.records.filter(r=>r.status==='rejected').length,deployments:store.records.filter(r=>r.status==='promoted'&&r.kind==='deployment-plan').length},store:store.toJSON()};
await writeFile(resolve(root,'results/e10.json'),JSON.stringify(out,null,2)+'\n');await writeFile(resolve(root,'results/e10-skills.json'),JSON.stringify(store.toJSON(),null,2)+'\n');
console.log(`E10 large world: ${big.factCount} facts; promoted ${out.skillCounts.promoted}/${out.skillCounts.total} records`);for(const r of results)console.log(`${r.query}: baseline ${r.baseline.status} probes=${r.baseline.candidateVisits}; learned ${r.learned.status} probes=${r.learned.candidateVisits} rounds=${r.learned.rounds}`);
