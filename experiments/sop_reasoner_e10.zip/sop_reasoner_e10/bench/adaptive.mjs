import {readFile,writeFile,mkdir} from 'node:fs/promises';import {fileURLToPath} from 'node:url';import {resolve} from 'node:path';
import {parseSOP,reason} from '../src/index.mjs';import {digest,schemaHash} from '../src/analyze.mjs';import {makeCase,paretoCase,sizes} from './families.mjs';
const root=fileURLToPath(new URL('..',import.meta.url));
const families={...sizes,pareto:2200};
// Follow-up motivated by the measured overhead of blindly enabling every optimization.
// Candidate set and ranking objective are frozen here; selection still reads training only.
const candidates=[];for(const demand of [false,true])for(const factor of [false,true])for(const fuse of [false,true])for(const dominance of [false,true])candidates.push({demand,factor,fuse,dominance,join:'greedy'});
const make=(name,n,seed)=>name==='pareto'?paretoCase(n,seed):makeCase(name,n,seed);
const training=[],selected={},test=[];
for(const name of Object.keys(families)){
  const ps=[0,1,2].map(s=>parseSOP(make(name,24,s).text));const trials=[],start=performance.now();
  for(let id=0;id<candidates.length;id++){let work=0,correct=true;for(const p of ps){const r=reason(p,'q',{...candidates[id],maxWork:1_000_000});work+=r.stats.candidateVisits;if(!r.complete)correct=false;}
    trials.push({id,work,complete:correct});
  }
  trials.sort((a,b)=>Number(b.complete)-Number(a.complete)||a.work-b.work||a.id-b.id);
  const chosen=trials[0];selected[name]={kind:'verified-policy-selection-v1',schema:schemaHash(ps[0]),options:candidates[chosen.id],trainingOnly:true};
  training.push({family:name,chosen,policy:selected[name],trials,trainMs:performance.now()-start});
}
await writeFile(resolve(root,'results/adaptive-policies.json'),JSON.stringify(selected,null,2));
for(const [name,n]of Object.entries(families))for(const seed of [101,202,303]){
  const c=make(name,n,seed),p=parseSOP(c.text);const applicable=schemaHash(p)===selected[name].schema;
  // A changed schema never silently inherits a policy. Fallback to standard indexing/greedy.
  const options=applicable?selected[name].options:{demand:false,factor:false,fuse:false,dominance:false,join:'greedy'};
  global.gc?.();const started=performance.now(),r=reason(p,'q',{...options,maxWork:5_000_000,maxMs:20000});
  if(!r.complete||digest(r.rows)!==digest(c.expected))throw new Error('Adaptive correctness failure');
  test.push({family:name,n,seed,status:r.status,correct:true,answerHash:digest(r.rows),work:r.stats.candidateVisits,wallMs:performance.now()-started,options,applicable,stats:r.stats});
}
await writeFile(resolve(root,'results/adaptive.json'),JSON.stringify({kind:'follow-up-ablation',objective:'tuple probes; ties choose fewer/earlier transformations',candidates,training,test},null,2));
console.log('Adaptive policies: 42/42 held-out queries exact; selected only from training.');
