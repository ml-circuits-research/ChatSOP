# SOP regression corpus

These `.sop` programs are executable examples plus property regressions. `#%` comments describe the expected scientific property; ordinary SOP parsing ignores them.

Run:

```sh
node tools/sop-regression.mjs
# or
make sop-regression
```

The machine-readable output is `results/sop-regression.json`. See `docs/REGRESSION_SOP.md` and `docs/EVIDENCE_MAP.md` for rationale and historical mapping.
