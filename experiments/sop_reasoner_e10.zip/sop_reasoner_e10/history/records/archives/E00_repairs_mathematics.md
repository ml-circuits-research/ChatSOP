# Repairs that preserve the experimental question

## Temperature is an approximation parameter, not an exact minimum switch

For energies E_i on a finite set Omega, let E*=min E_i and F_beta=-log(sum exp(-beta E_i))/beta. Factoring out exp(-beta E*) gives

`0 <= E* - F_beta <= log(|Omega|)/beta`.

For n Ising spins, |Omega|=2^n. Thus beta=n*log(2)/0.0009 guarantees a soft-min approximation error below .001 for any fixed learned energy table. This bound controls approximation to the learned minimum, not its agreement with the true energy; the latter is measured separately. At n=32, beta=24645.233086575834. Degeneracy is not removed or hidden. The original beta=64 results remain reported.

When the true energy is integer and the energy model is exact, rounding F_beta is also justified whenever n*log(2)/beta<.5. At n=32 and beta=64, the bound is .346574. This explains why rounding can succeed even though the raw .001 condition fails. For learned noninteger factors, rounding has no unconditional guarantee of correctness against the true energy; the empirical rounded accuracy is labelled as such.

## Count and the logarithmic chart are observationally equivalent

For strictly positive factors w_i, set e_i=-log(w_i). Products of w_i become sums of e_i, and sums become negative log-sum-exp. Missing factors map from zero to +infinity. Count and LogBeta(1) are therefore two coordinate representations of the same positive partition calculation. A statistical test cannot uniquely distinguish identical functions. Strict name selection and equivalence-class selection are both reported.

## Parity has two different training and execution domains

Encode a bit b by s=(-1)^b. XOR becomes multiplication of signs. AND becomes `(1+a+b-a*b)/2`. These operations satisfy the F2 laws on {-1,+1}. Their polynomial extension to the interval [-1,+1] is differentiable, but it is not a semiring on that interval: distributivity already fails at a=b=c=0. The relaxed model therefore need not behave like exact parity in a deeper circuit.

Nearest-sign projection is performed without looking at extrapolation labels. On the finite observed edge alphabet, a projected local table that is exactly canonical, combined with the supplied contraction schedule, recovers the algebraic algorithm. This supports an inductive correctness argument for that compiled algorithm; it does not show that the network discovered a new contraction schedule.

## The determinant is a global primitive

A program selects a scalar world, local-factor template and a typed global construction. The determinant backend accepts either a Laplacian minor or a matrix of path sums. Compatible, ordered boundary terminals are essential for interpreting the LGV determinant as an unsigned number of vertex-disjoint path tuples. Arbitrary terminal permutations would instead produce signed sums. The original grammar therefore needs a path-matrix constructor in addition to the Laplacian constructor.

## Operator learning separates representation from structural restriction

An unrestricted real n-by-n matrix has n^2 parameters. A circulant real matrix has n. A full-vector example supplies n scalar responses, so the noiseless generic vector-example scales are n and one, not n^2 and n. With Gaussian noise, finite-sample accuracy additionally depends on conditioning and variance.

The DFT diagonalizes a circulant operator. Restricting the transformed matrix to be diagonal supplies the structural prior; an unrestricted basis rotation does not remove parameters. A time-domain model tying coefficients by cyclic displacement describes the same model family and therefore achieves the same least-squares fit. The explicit tied-design control agrees with the DFT solution to floating-point precision. Three tested dimensions support an empirical benefit, not a proof of an asymptotic statistical law.

## Transfer and optimizer budget are different quantities

With a fixed number of epochs, a larger dataset receives more optimizer steps. A pretrained model can reach a strict numerical tolerance with fewer new examples because it is closer to the solution, even when an adequately optimized scratch model needs no additional information. Both the original fixed-epoch comparison and an L-BFGS convergence control are retained.

On T8, source training observes only weight one. Both local laws phi(w)=1 and phi(w)=w agree there, but disagree on weights two and three. Consequently the correct weighted extension is not identifiable from unweighted examples alone. The determinant structure can transfer, while the unseen-weight law still needs information or an explicitly supplied structural prior.
