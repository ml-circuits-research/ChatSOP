# Verified Reasoning Research Program

This repository is the cumulative record of the experimental line that began with selectable algebraic worlds and evolved toward verified algorithmic concept and representation invention.

The central architectural hypothesis is now:

> **Machine learning proposes what distinction, abstraction, representation, lemma, decomposition, or reasoning program is worth trying; an exact layer decides what is semantically valid; accepted discoveries are compiled into persistent reusable reasoning skills.**

This repository is intentionally cumulative. New experiments must not replace earlier ones. They add new tests, new capabilities and new failure modes while preserving all previous regression tests.

## Current status

- 8 experiment stages preserved (E00–E07).
- 79 historical unit/integration tests currently pass.
- Semantic capability assertions are checked separately by `tools/check_claims.py`.
- Earlier negative results are retained, especially the failure of direct neural quotient classification and the finite-temperature beta=64 issue.

## Commands

```bash
make regression          # all historical test suites + semantic capability checks
make claims              # capability-level assertions only
make list                # list experiments
```

`make reproduce-all` is deliberately separate because some earlier experiments are substantially more expensive and regenerate data/results.

## Documents

- `docs/RESEARCH_LOG.md` — chronological experiment log, including failures and what changed.
- `docs/CAPABILITY_MATRIX.md` — what the system has actually demonstrated and what remains unproved.
- `docs/ARCHITECTURE.md` — proposed reusable Verified Reasoning Engine architecture.
- `docs/SOP_LANG_INTEGRATION.md` — concrete design for integration with SOP Lang facts, rules, wires and queries.
- `docs/REGRESSION_POLICY.md` — rules preventing capability loss and post-hoc rewriting of results.
- `docs/NEXT_EXPERIMENTS.md` — prioritized path toward open-ended algorithm invention.

## Experiments

| ID | Focus |
|---|---|
| E00 | Selectable algebraic worlds, exact execution, projection and limits |
| E01 | Hidden algebra learning and exactification |
| E02 | Exact behavioral quotient discovery for model counting |
| E03 | Negative result: neural quotient proposal + CEGIS is inferior to symbolic active learning at scale |
| E04 | Generic verified reasoning skills: DP state, symmetry, memoization, pruning, Bellman state |
| E05 | Composition of verified reasoning primitives into complete algorithms |
| E06 | Invention of a dominance relation, transfer, and counterexample-driven specialization |
| E07 | Invention of derived features/invariants and failure-driven representation-language expansion |

The original E00 protocol failure is preserved under `archives/` rather than being erased by the repaired experiment.
