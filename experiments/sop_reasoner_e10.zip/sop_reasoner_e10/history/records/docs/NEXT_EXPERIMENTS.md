# Next experiments

## E08 — Autonomous representation-constructor selection

### Objective
Remove the hand-coded decision “linear failed -> try quadratic”. Present several qualitatively different constructors and require the engine to infer which representational capacity is missing from counterexamples.

Candidate constructors:

- products / polynomial terms;
- modulo / parity coordinates;
- min/max and lattice features;
- absolute differences/order statistics;
- set counts/sums;
- graph quotients;
- separator coordinates;
- change-of-basis transforms;
- reusable learned subprograms.

### PASS condition
Across several hidden domains requiring different constructors, the engine should choose a constructor family substantially more efficiently than blind enumeration, synthesize a certified feature/skill, and reject irrelevant constructor families on negative controls.

### Critical baseline
A symbolic grammar enumerator with the same constructors and verifier budget. ML is useful only if it reduces discovery cost or reaches useful candidates outside the symbolic baseline budget.

---

## E09 — SOP-native combinatorial reasoning benchmark

Create a large typed fact/rule environment with exact synthetic ground truth and repeated query families. Test:

- local theory construction;
- rule scheduling;
- state quotienting;
- decomposition;
- lemma compilation;
- dominance/subsumption;
- cumulative reuse across queries.

The hard metric is number of rule firings/proof states while preserving exact answers.

---

## E10 — Novel composition outside training distribution

Train on separate families where different skills are useful individually, then construct held-out problems requiring a new 3–5 skill composition. The system must synthesize the composition without an example of the whole algorithm.

---

## E11 — Primitive invention from failed SOP traces

When the existing skill DSL cannot reduce a search bottleneck, synthesize a new SOP-level derived predicate or macro-rule from traces, prove its semantic contract, and add it to the language. This is the first experiment that should justify the stronger phrase “the reasoning engine extends its own reasoning language.”

---

## Long-term public benchmark

After the SOP-native mechanism is stable, evaluate on a public exact reasoning benchmark where strong non-ML algorithms exist (e.g. exact model counting / constraint solving). The target is not merely accuracy but a verified reduction in explored search and additional solved instances under a fixed resource budget.
