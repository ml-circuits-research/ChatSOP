# Regression status

Last checked: 2026-09-30

Fast cumulative regression is green.

| Experiment | Tests |
|---|---:|
| E00 world/algebra | 53 passed |
| E01 latent algebra | 8 passed |
| E02 exact quotient | 3 passed |
| E03 neural CEGIS negative control | 2 passed |
| E04 verified reasoning skills | 4 passed |
| E05 algorithm composition | 2 passed |
| E06 dominance invention | 4 passed |
| E07 feature invention | 3 passed |
| **Total historical tests** | **79 passed** |

In addition, `tools/check_claims.py` currently enforces **15 semantic capability assertions**, including preservation of important negative results.

This file is informational. The authoritative check is:

```bash
make regression
```
