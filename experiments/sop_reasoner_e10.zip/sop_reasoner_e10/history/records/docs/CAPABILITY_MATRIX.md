# Capability matrix

Legend: **demonstrated** = experimental evidence in this repository; **partial** = mechanism works under important supplied assumptions; **open** = not yet demonstrated.

| Capability | Status | Evidence / limitation |
|---|---|---|
| Exact execution in multiple algebraic worlds | demonstrated | E00 |
| Continuous training followed by exact/discrete execution | demonstrated | E00/E01; especially parity and Tropical execution |
| Learn exact behavioral quotient from counterexamples | demonstrated | E02 |
| Avoid false compression on high-complexity controls | demonstrated | E02 |
| Neural classifier + CEGIS is sufficient for exact quotient learning | **falsified in tested regime** | E03 |
| Discover DP/symmetry/memoization/Bellman abstractions from traces | demonstrated in supplied meta-language | E04 |
| Compose generic reasoning primitives into an exact solver program | demonstrated | E05 |
| ML ranks candidate algorithms without affecting correctness | demonstrated on small search spaces | E04/E05; necessity not established |
| Invent a new dominance relation from lower-level predicates | demonstrated | E06 |
| Transfer an algorithmic concept across domains | demonstrated in relational template form | E06 |
| Reject/specialize a transferred skill after counterexample | demonstrated | E06 |
| Invent a derived scalar feature needed for sound pruning | demonstrated | E07 |
| Detect insufficient feature grammar | demonstrated | E07 linear failure on quadratic domain |
| Expand representation language after failure | partial | E07; expansion policy was supplied |
| Select autonomously among qualitatively different representation constructors | open | proposed E08 |
| Invent a new primitive outside a designer-supplied meta-language | open | central target |
| Learn a reasoning theory from millions of SOP facts/rules | open | architecture specified in SOP integration document |
| Preserve completeness while learned relevance selection prunes facts/rules | open except through fallback/certified conditions | must distinguish ranking from certified pruning |
| Discover reusable lemmas in a large symbolic KB | open | design specified |
| Discover a genuinely novel algorithm competitive with strong solvers | open | no claim yet |
