# Non-regression and experimental integrity policy

## Principle

This is a cumulative research program. A new experiment may refine an interpretation or supersede a hypothesis, but it must not silently delete an earlier capability, test, negative result, or experimental condition.

## Required rules

1. **Append, do not replace.** Each conceptually new experiment receives a new `E##` directory.
2. **All old tests remain runnable.** `make regression` executes every preserved historical test suite.
3. **Capabilities have semantic assertions.** Unit tests are not enough; `tools/check_claims.py` checks selected result-level invariants.
4. **Negative results are first-class.** Failed hypotheses remain in the log. In particular, direct neural quotient classification and invalid finite-temperature criteria are preserved.
5. **No post-hoc threshold changes.** If a threshold or benchmark is changed, the old result remains recorded and the new condition is a new experiment/control.
6. **Invented vs supplied must be explicit.** Every experiment records what primitives, features, grammar constructors, oracles and verification powers were supplied by the designer and what was synthesized by the system.
7. **Verifier strength is part of the experimental budget.** A result is not credited to learning if the verifier effectively contains the solution.
8. **Accuracy cannot substitute for compositional exactness.** Approximate local prediction may guide search, but cannot justify pruning/equivalence unless separately certified.
9. **New shortcuts require a negative control.** At least one domain should make the candidate shortcut invalid or unavailable; the system must reject it.
10. **Transfer must preserve semantics.** A transferred skill is accepted only after verifying its applicability contract in the new domain.

## Two regression levels

### Fast regression

`make regression`

Runs unit/integration tests and semantic result assertions. This should remain fast enough to run after every code change.

### Full reproduction

`make reproduce-all`

Regenerates experiments where practical. Because E00/E01 contain heavier training runs, full reproduction is intentionally not part of the fast gate.

## Adding E08+

A new experiment should add:

- `README.md`: hypothesis, supplied primitives, invented objects, verifier powers.
- `REPORT.md`: result and limitations.
- tests for the new mechanism.
- at least one assertion in `tools/check_claims.py` if the experiment establishes a persistent capability.
- an entry in `RESEARCH_LOG.md` and `CAPABILITY_MATRIX.md`.

The total test count should normally increase, never decrease without an explicitly documented deletion reason.
