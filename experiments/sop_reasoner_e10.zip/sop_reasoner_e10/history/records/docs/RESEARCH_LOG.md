# Cumulative research log

## Research question

Can an ML system improve reasoning not merely by predicting the next action, but by **discovering representations and reasoning procedures that become exact, reusable computational objects**?

The experimental line progressively moved the learnable object from numerical parameters toward algebra, state distinctions, reasoning programs, algorithmic relations and derived representations.

---

## E00 — Selectable algebraic worlds

### Question
Can a contraction engine execute the same structural computation in different algebraic worlds and learn local factors while preserving extrapolation?

### Important findings
- Canonical Count/Tropical/Parity/Det computations can be executed exactly in the appropriate typed machinery.
- Learned factors with the correct world extrapolate strongly on the chosen synthetic tasks.
- Discretization/projection can repair deep compositional failure: parity was fragile in the continuous relaxation and became exact after projection.
- A fixed `beta=64 -> exact tropical within 1e-3` criterion was mathematically false because finite-temperature free energy retains entropy/degeneracy terms. This failure is preserved in `archives/E00_original_protocol_failure.zip`.
- Direct Tropical execution of learned tables is a cleaner exactification mechanism than pretending a finite soft-min is an exact minimum.

### Lasting lesson
**Train approximately when useful; execute exact algebra once the discrete structure is justified.**

---

## E01 — Hidden algebra learning

### Question
Can unknown operation tables be learned from final answers and then consolidated into an exact algebra?

### Findings
- Continuous models degrade under deep composition even when local fit is good.
- Discrete consolidation can restore exact extrapolation.
- Global algebraic consistency can be stronger than independent local rounding.
- Pure symbolic identification was more sample-efficient on small finite algebras.
- Jointly learning encoder + latent states + operations was fragile.
- Forcing an incorrect algebraic law can destroy an otherwise correct learned operation.

### Lasting lesson
**Algebraic laws must be selectable/verifiable; the ML component should not be credited for structure that symbolic search can identify more cheaply.**

---

## E02 — Exact quotient discovery

### Question
Can the system discover behavioral equivalence classes that replace exponential enumeration with exact dynamic counting?

### Findings
- L*-style counterexample refinement learned exact quotients of 4–177 states.
- Structured CNF counting collapsed from an exponential prefix tree to a tiny exact automaton and scaled to length 10,000.
- Pseudorandom finite-memory controls did not collapse artificially; quotient size and discovery cost grew rapidly.

### Lasting lesson
**The right equivalence relation can be an algorithm. Learning the quotient is often more important than learning a value function.**

---

## E03 — Direct neural quotient proposal: negative result

### Question
Can an MLP/tree predict quotient classes, with CEGIS repairing the remaining mistakes?

### Finding
At the largest test, classifiers reached roughly 97–98% state classification accuracy yet failed to produce an exact quotient after 30 refinement rounds. Classical symbolic active learning used fewer exact observations and succeeded.

### Lasting lesson
**For exact compositional reasoning, 98% state classification can be useless. The useful learnable target is more likely the next distinguishing experiment/predicate than the final class label.**

This negative result is architecturally important and must remain a permanent regression/control.

---

## E04 — Verified reasoning skills

### Question
Can the same verified-refinement interface rediscover qualitatively different algorithmic shortcuts?

### Rediscovered skills
- finite-memory DP for forbidden patterns;
- symmetry quotient for graph coloring;
- memoization and safe zero-subtree pruning for subset sum;
- additive Bellman state and valid bounds for knapsack.

### Finding
A small learned guide improved proposal ordering, but a cheap heuristic was already strong.

### Lasting lesson
A reusable skill can be represented as:

`(applicability, transformation/abstraction, semantic contract, certificate, cost model)`.

---

## E05 — Algorithm composition

### Question
Can complete algorithms emerge by composing verified generic primitives?

### Finding
Search over 144 solver programs discovered a #SAT reasoning pipeline combining propagation, decomposition, canonical memoization and branching. Ablations showed that different primitives contribute distinct gains. A learned cost model ranked useful programs early.

### Important control
`subsume` was slightly overfit to training and hurt held-out cost; it was retained in the report rather than removed post hoc.

### Lasting lesson
**Algorithm synthesis can be viewed as search over executable reasoning programs, but composition of supplied primitives is not yet primitive invention.**

---

## E06 — Algorithmic concept invention: dominance

### Question
Can a new reusable pruning concept be synthesized from lower-level logical comparisons rather than supplied as a primitive?

### Finding
From equality/order predicates the system synthesized the relation:

`same control state AND no-more-resource AND no-worse-objective`

which materialized as Pareto dominance on knapsack. It transferred structurally to resource-constrained shortest path and was rejected/specialized in a bonus domain where naive dominance was unsound.

### Lasting lesson
**A reasoning concept should survive transfer at the level of relational shape, while applicability is re-verified in each domain.**

---

## E07 — Derived feature / invariant invention

### Question
Can the system invent a new coordinate in which a previously unsafe algorithmic shortcut becomes sound?

### Findings
- From raw variables it discovered the linear guard `-T + 3*i + 2*w >= 0`.
- Unguarded dominance produced wrong end-to-end answers; the invented feature restored exactness.
- On a nonlinear domain, the linear grammar correctly failed.
- After adding generic quadratic constructors, the system discovered `-T + 2*i + w^2 >= 0`.
- A hash-like negative control produced no certified feature.

### Lasting lesson
**Reasoning improvement can require inventing the representation itself, not merely choosing a procedure in a fixed representation.**

### Current limitation
The policy “expand from linear to quadratic grammar” is still designer supplied. Open-ended invention requires choosing among qualitatively different representation constructors from evidence and failed proofs.

---

# Stable architectural conclusions so far

1. ML should primarily optimize **which candidate to examine**, not define truth.
2. Semantic state partitions, lemmas, invariants and pruning rules belong to an exact/verifiable layer.
3. Accepted discoveries should be compiled into persistent skills, not remain only in weights.
4. Counterexamples are not merely training examples; they are signals that the current representation/language is insufficient.
5. Reasoning efficiency often comes from changing the state space: quotienting, decomposition, sufficient statistics, canonicalization, bounds and derived coordinates.
6. Approximate predictors are useful when their errors affect cost only; any error that can affect correctness must be shielded by verification or exhaustive fallback.
7. The next frontier is **representation-constructor selection and invention**, followed by integration into a large rule/fact reasoning environment.
