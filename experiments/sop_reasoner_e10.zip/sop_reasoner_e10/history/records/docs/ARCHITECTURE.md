# Verified Reasoning Engine (VRE)

## 1. Objective

The engine should not be a neural theorem prover whose hidden state is trusted as reasoning. It should be a system that **learns how to restructure exact search**.

Given a goal `G`, a knowledge/environment state `K`, and a cost budget, it repeatedly constructs a smaller and more useful reasoning problem by learning:

- which distinctions matter;
- which states are behaviorally equivalent;
- which decompositions make subproblems independent;
- which lemmas or derived predicates compress repeated derivations;
- which bounds allow safe pruning;
- which representation exposes a simpler algorithm;
- which reasoning program should be executed.

ML proposes. Verification owns semantics. Accepted discoveries become persistent executable skills.

## 2. Core state

A reasoning episode maintains:

`R = (Goal, LocalTheory, ProofState, Abstractions, Lemmas, Strategy, Trace, Budget)`

where:

- **Goal**: target query or objective;
- **LocalTheory**: currently active facts/rules/definitions;
- **ProofState**: unresolved subgoals and accepted derivations;
- **Abstractions**: quotients, sufficient statistics, derived features, canonical forms;
- **Lemmas**: verified reusable implications/equivalences/bounds;
- **Strategy**: executable reasoning program assembled from skills;
- **Trace**: provenance, counterexamples, costs, failed candidates;
- **Budget**: time/state/verifier budget.

## 3. Skill object

A persistent skill is not a prompt. It is a typed object:

```text
Skill {
  id
  input_types
  applicability_condition
  transformation
  semantic_contract
  verifier
  certificate
  counterexamples
  cost_model
  provenance
  dependencies
  version
}
```

Typical semantic contracts:

- `equivalent(before, after)`;
- `solution_set_preserved`;
- `optimum_preserved`;
- `count_preserved`;
- `lower_bound` / `upper_bound`;
- `state_A_simulates_state_B`;
- `subproblems_independent`;
- `rewrite_terminates`;
- `derived_feature_is_invariant/monotone`.

## 4. Two safety classes

### Guidance-only skills

Examples: rule ordering, branch ordering, retrieval ranking, candidate lemma ranking.

A wrong prediction may increase cost but **cannot change the answer** because exhaustive fallback remains available.

### Semantics-changing optimizations

Examples: pruning a branch, merging states, omitting rules, replacing a subtheory by a quotient, using a bound to terminate search.

These require a certificate or a verifier-backed applicability check. If verification is unavailable, the operation must fall back to guidance-only behavior.

This distinction is fundamental for a large reasoning system.

## 5. Learning loop

```text
solve(goal):
    theory   = build_initial_local_theory(goal)
    strategy = retrieve_applicable_verified_skills(goal, theory)

    while not solved:
        trace = execute_verified_strategy(theory, strategy, budget)

        if solved:
            consolidate_reusable_discoveries(trace)
            return certified_answer

        bottleneck = diagnose(trace)
        candidates = proposer.generate(bottleneck, theory, skill_library)

        for candidate in candidates:
            verdict = verifier.check(candidate)
            if verdict.valid:
                theory_or_strategy = compile(candidate)
                persist_if_reusable(candidate)
                break
            else:
                learn_from(verdict.counterexample)

        if no verified improvement:
            widen search / fall back to complete baseline
```

## 6. What can be invented

The search language should be stratified so that the system can grow its own vocabulary.

### Level A — scheduling
Rule/branch/order/retrieval priorities.

### Level B — transformations
Rewrite, decompose, memoize, canonicalize, bound, split.

### Level C — relational concepts
Dominance, equivalence, independence, monotonicity, symmetry.

### Level D — derived representations
Linear/nonlinear features, sufficient statistics, quotient coordinates, potentials.

### Level E — representation constructors
Products, modular coordinates, set aggregates, min/max lattices, graph separators, spectral/change-of-basis operators, recursively learned subprograms.

### Level F — new reasoning programs
Compositions of all of the above with verified applicability.

E00–E07 progressed roughly from A/B toward C/D. E08 should test autonomous selection at Level E.

## 7. Theory learning vs ordinary ML

Ordinary learning mostly updates parameters `theta` while the computational language stays fixed.

VRE also updates an explicit theory/language:

`L_{t+1} = L_t + verified abstraction/lemma/operator/strategy`.

The intended long-term effect is cumulative expertise: repeated expensive reasoning is converted into a cheaper reusable algorithm.

## 8. Correctness model

The engine should expose three different claims instead of conflating them:

1. **Answer correctness** — what is proved about the final answer.
2. **Transformation soundness** — what is proved about a shortcut/abstraction.
3. **Search optimality/efficiency** — empirical; normally not formally guaranteed.

ML may affect (3) aggressively. It may affect (1) or (2) only through a checked artifact.
