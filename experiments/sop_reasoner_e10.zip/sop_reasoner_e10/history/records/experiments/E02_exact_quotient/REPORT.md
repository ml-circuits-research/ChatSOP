# Learned exact quotient for model counting — experimental report

## Verdict

The mechanism is real: an exact CEGIS learner can discover a finite quotient of prefix states, and the quotient can replace exponential enumeration by exact dynamic counting. On structured CNF families the learned quotient has 4–19 states and reproduces brute-force #SAT counts exactly; after compilation it counts formulas of length 10,000 in under 0.1 s. A negative control with pseudo-random finite memory does not collapse to a tiny quotient: the exact quotient grows from 10 to 332 states as memory width grows from 4 to 9, and the number of membership queries rises from 54 to 6,281.

This validates the *state-quotient + counterexample refinement* mechanism. It does **not** yet validate a new ML architecture: the present learner is essentially active automata learning, and for these regular CNF families a classical symbolic method is already sufficient.

## Experiment A — exact quotient discovery

The learner sees only membership answers and counterexamples. It is not given the target transition table. It starts from coarse observational equivalence and refines states until an exact equivalence checker finds no counterexample.

| Target | Minimal target states | Learned states | Membership queries | Equivalence queries | Longest counterexample |
|---|---:|---:|---:|---:|---:|
| no `111` | 4 | 4 | 19 | 3 | 3 |
| number of ones mod 7 = 3 | 7 | 7 | 62 | 4 | 7 |
| avoid `1011011` | 8 | 8 | 71 | 3 | 7 |
| no `111` AND mod-5 condition | 16 | 16 | 431 | 7 | 10 |
| random reachable DFA | 24 | 24 | 309 | 8 | 9 |
| random 8-bit suffix memory | 177 | 177 | 2,729 | 12 | 8 |

For every target the learned machine is exactly equivalent to the hidden target under product-automaton equivalence checking.

## Experiment B — actual CNF model counting

For a forbidden pattern `p`, every window is encoded as one CNF clause saying that the window must differ from `p` in at least one bit. Thus these are ordinary CNF model-counting instances. The learned quotient is used only after discovery; the final count is exact integer dynamic programming over quotient states.

| CNF family | Learned states | #SAT at n=20 | Brute force n=20 | Quotient DP n=20 | Count at n=10,000 |
|---|---:|---:|---:|---:|---:|
| forbid `111` | 4 | 223,317 | 3.93 s | 0.000020 s | 2,647 digits, 0.021 s |
| forbid `1011011` | 8 | 946,709 | 4.38 s | 0.000022 s | 2,980 digits, 0.051 s |
| forbid four patterns | 19 | 146,510 | 4.73 s | 0.000045 s | 2,519 digits, 0.071 s |

For n=8, 12, 16 and 20, every learned-quotient count is identical to independent brute-force evaluation of the generated CNF clauses.

For the 19-state family, a prefix tree has roughly 2^(n+1)-1 nodes while the compiled counter uses at most about 19(n+1) state-time positions. At n=32 this is about 8.6 billion tree nodes versus roughly 627 quotient positions. This is the expected exponential-to-linear reduction for a genuine finite quotient.

## Experiment C — negative control

A pseudo-random acceptance function over the last k bits was used to destroy exploitable low-dimensional structure while preserving an exact finite-state representation.

| k | Raw memory states 2^k | Exact minimal quotient | Membership queries | Learning time |
|---:|---:|---:|---:|---:|
| 4 | 16 | 10 | 54 | 0.001 s |
| 5 | 32 | 20 | 269 | 0.012 s |
| 6 | 64 | 47 | 571 | 0.051 s |
| 7 | 128 | 94 | 1,110 | 0.152 s |
| 8 | 256 | 174 | 2,365 | 0.825 s |
| 9 | 512 | 332 | 6,281 | 6.27 s |

The method therefore does not magically compress arbitrary computation. When the true quotient is large, both the learned state space and discovery cost grow rapidly.

## What this proves

1. Exact behavioral quotient discovery can turn an exponential model-counting search space into a small exact machine when such a quotient exists.
2. Counterexamples are sufficient to repair over-aggressive state merging; final execution is exact, not approximate.
3. The learned object extrapolates to sequence lengths far beyond those explicitly enumerated because the final object is a verified transition system.
4. The negative control behaves correctly: no tiny quotient appears when the target has high finite-state complexity.

## What this does not prove

The current experiment is not evidence that neural learning is needed. The learner is a compact L*-style active automata learner. The exact equivalence oracle is also strong: for the experiment it compares against a hidden finite-state target. For arbitrary CNF, constructing useful counterexamples without already knowing such a target is the hard part.

Thus the next decisive experiment is not another regular language. It is:

**neural proposal of quotient candidates on generic model-counting instances + SAT/#SAT verification + CEGIS state splitting**, compared against BDD/SDD/component-caching baselines on public model-counting benchmarks.

A positive result would require the neural proposer to reduce verifier/search cost or compiled-state size on instances where purely symbolic quotient discovery becomes too expensive. Otherwise the neural component is unnecessary.
