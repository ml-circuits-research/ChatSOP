# quotient-mc

Small reproducible experiment for exact state-quotient discovery and model counting.

## Run

```bash
python experiment.py
python cnf_demo.py
python scaling.py
pytest -q
```

Files:
- `experiment.py`: DFA targets, exact L*-style CEGIS learner, exact counting.
- `cnf_demo.py`: CNF families defined by forbidden local patterns and independent brute-force verification.
- `scaling.py`: negative-control scaling experiment.
- `test_experiment.py`: exactness tests.
- `REPORT.md`: interpretation and results.

No third-party dependency is required for the experiment itself; `pytest` is used only for tests.
