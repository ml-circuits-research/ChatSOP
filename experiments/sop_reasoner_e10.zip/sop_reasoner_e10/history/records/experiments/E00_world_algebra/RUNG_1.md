# Rung 1: PASS

| Task | Candidates | Survivors | Correct program-instance pairs | Evaluated pairs | Verdict |
|---|---|---|---|---|---|
| T1 | 60 | 6 | 6000 | 6000 | PASS |
| T2 | 60 | 1 | 1000 | 1000 | PASS |
| T3 | 60 | 4 | 4000 | 4000 | PASS |
| T4 | 60 | 3 | 3000 | 3000 | PASS |
| T7_composition | 48 | 6 | 6000 | 6000 | PASS |

Multiple survivors can be aliases, including Count/LogBeta and templates equal on the observed weight alphabet. This is finite-library program selection, not discovery of new algebraic operations.
