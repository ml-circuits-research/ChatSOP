# Rung 3: H3c PARTIAL; repaired H3d PASS; H3e PASS

| Task | Method | 0 examples | 50 | 200 | 1000 |
|---|---|---|---|---|---|
| T7 | transfer_zero_shot | 100.00 ± 0.00% | NOT RUN | NOT RUN | NOT RUN |
| T7 | scratch | NOT RUN | 64.20 ± 0.00% | 96.33 ± 6.35% | 100.00 ± 0.00% |
| T7 | transfer | NOT RUN | 100.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T7 | scratch_refined | NOT RUN | 100.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T7 | transfer_refined | NOT RUN | 100.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T8 | transfer_zero_shot | 0.00 ± 0.00% | NOT RUN | NOT RUN | NOT RUN |
| T8 | scratch | NOT RUN | 0.00 ± 0.00% | 0.00 ± 0.00% | 7.33 ± 6.39% |
| T8 | transfer | NOT RUN | 0.07 ± 0.12% | 0.27 ± 0.12% | 32.20 ± 47.50% |
| T8 | scratch_refined | NOT RUN | 100.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T8 | transfer_refined | NOT RUN | 100.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |

After convergence, both models pass at the smallest tested nonzero volume, 50: these thresholds are left-censored, not proof of equal sample complexity. T7 zero-shot uses the supplied Count→Det composition.

| Model | Beta | Energy accuracy | Maximum error across seeds |
|---|---|---|---|
| tables | 64.000 | 0.00 ± 0.00% | 24.618600457628084 |
| tables | 24645.233 | 0.00 ± 0.00% | 24.650260253902015 |
| tables | infinity | 0.00 ± 0.00% | 24.65026025390202 |
| tables_refined | 64.000 | 1.40 ± 0.00% | 0.11057340165625362 |
| tables_refined | 24645.233 | 100.00 ± 0.00% | 0.00028804415084948687 |
| tables_refined | infinity | 100.00 ± 0.00% | 2.1463879370742234e-05 |
| bilinear | 64.000 | 0.53 ± 0.92% | 0.12615150034649503 |
| bilinear | 24645.233 | 3.20 ± 4.16% | 0.05424457870266508 |
| bilinear | infinity | 3.27 ± 4.11% | 0.05424457870266508 |
| bilinear_refined | 64.000 | 1.40 ± 0.00% | 0.11057277787041642 |
| bilinear_refined | 24645.233 | 100.00 ± 0.00% | 0.0002872076382303135 |
| bilinear_refined | infinity | 100.00 ± 0.00% | 3.2821510416169986e-06 |

| n | Seed | Dense vector examples | DFT vector examples | Ratio |
|---|---|---|---|---|
| 16 | 0 | 64 | 2 | 32.0 |
| 16 | 1 | 32 | 2 | 16.0 |
| 16 | 2 | 64 | 1 | 64.0 |
| 32 | 0 | 128 | 2 | 64.0 |
| 32 | 1 | 128 | 2 | 64.0 |
| 32 | 2 | 128 | 2 | 64.0 |
| 64 | 0 | 128 | 4 | 32.0 |
| 64 | 1 | 256 | 4 | 64.0 |
| 64 | 2 | 256 | 2 | 128.0 |

The original beta=64 raw-energy criterion remains failed. Diagonal DFT and tied circulant models encode the same structural constraint.
