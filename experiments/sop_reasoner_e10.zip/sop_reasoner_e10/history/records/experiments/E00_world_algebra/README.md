# Compact source package

This package contains source, tests, configuration, and report/figure snapshots. It omits datasets, trained checkpoints, prediction arrays and historical archive files. Run `make reproduce` to regenerate all data and fits before `make evaluate` or `make verify`. The full package is w2.zip.

# WorldNet: algebraic program selection and algorithmic extrapolation

A small CPU experiment covering all eight tasks in the supplied brief. It includes independent reference algorithms, exact semiring contractions, differentiable local factors, neural baselines, discrete and mixture world selection, compositional transfer, structured operator learning, and finite-temperature inference. Original failed criteria remain visible; mathematical and experimental repairs are documented in ASSUMPTIONS.md.

## Run

Use Python 3.11 or later (the recorded run used Python 3.13.5).

```bash
python -m venv .venv
. .venv/bin/activate
# Use the CPU wheel rather than downloading a GPU runtime.
pip install torch==2.10.0 --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
make test
make reproduce
```

`make reproduce` performs new training, not a reload of the supplied checkpoints. It uses at most three single-threaded training processes, retains immutable datasets, and produces reports and figures. Scientific FAIL/PARTIAL conclusions are results; only execution errors and integrity violations cause a nonzero exit. The full clean-run timing is in VERIFICATION.md.

`make evaluate` reevaluates supplied checkpoints without training. `make verify` creates a clean directory and virtual environment, regenerates all data and models, and compares results. Its virtual environment uses the currently installed dependencies; it is not an independent-machine replication. `make rung0`, `make rung1`, `make rung2`, and `make rung3` expose component groups; the shared trainer used by rung2 also prepares the transfer and Ising models. Consolidated RUNG reports are generated after evaluation.

## Read the results

REPORT.md is the short Romanian verdict. RUNG_0.md through RUNG_3.md give stage detail. RESULTS.md contains every aggregated learning cell, including all candidate worlds, selected models, joint and two-stage mixtures, projections, controls and transfer variants. results/cells.csv has per-seed metrics. results/seed*/ contains checkpoints and optimisation traces. results/learning.json records selection decisions and projection distances. results/stress.json tests longer computation depth; results/limit.json and results/basis.json cover L and B.

Counts are scored in log1p space at tolerance .001, exactly as in the brief; that metric is not exact integer equality. Exact integer comparisons are separately used by the canonical oracle. T1–T4 symbolic-search consistency uses relative numerical tolerance 1e-7; T7 composition uses exact equality. Seed standard deviations describe optimisation variability, not confidence intervals for independent test datasets.

## What the experiment does and does not establish

M1 is given a contraction structure and learns local factors; selection chooses among a finite, human-supplied library of algorithms. The library contains Kirchhoff and compatible-terminal LGV structures. VALIDATION.md shows that M0 also has poor in-domain exact accuracy; the comparison is not a clean separation between successful interpolation and failed extrapolation. Successful selection is not the invention of those theorems or a new algebra. M0 receives the same observed graphs, weights, endpoints and walk length, but not the task-specific algorithm. A tied-depth neural control and longer-horizon tests help expose this difference; they do not exhaust neural alternatives.

T1/T3 training walk lengths are 3–6. Increasing n alone does not increase algorithm depth; supplementary k=8/16/32 tests distinguish the two. T5 holds an unknown kernel fixed within each run, uses noisy training/validation labels and clean test labels, and distinguishes vector examples from scalar responses. A tied time-domain circulant control isolates structural sharing from a change of coordinates. T7 zero-shot evaluation is given the Count→Det composition; it measures reuse of learned factors, not zero-shot discovery of the target task.

The original finite-beta=64 acceptance rule and cold joint-mixture failures remain in the reports. L-BFGS refinements and convex expert gating are labelled supplemental solutions; they never replace original Adam results. No test-size data enter training, validation, early stopping, gating, or hyperparameter selection.

## Main files

worlds.py and contract.py implement scalar worlds and shared contractions. tasks.py contains independent labels and imports neither the engine nor models. models.py is the canonical M2 oracle. learning.py contains batched trainable models. train.py generates small training/validation sets and fits models. search.py enumerates typed programs. solutions.py implements the optimizer and gating controls. basis.py implements operator learning. audit.py evaluates held-out sizes and certified limits. report.py writes tables and separate figures. run.py orchestrates the full run.

The software performs no network requests. All randomness is seeded. Supplied data have SHA-256 integrity records. No canonical local-factor targets are supplied to model training; they appear only in oracle unit tests and recovery diagnostics.
