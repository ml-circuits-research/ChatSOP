Algoritmii din biblioteca algebrică pot fi selectați și învățați cu extrapolare reușită; transferul de eșantioane și mixtura simultană au limite distincte.

| Ipoteză | Verdict | Rezultat măsurat |
|---|---|---|
| H1 | PASS, amended | 10,900 canonical checks; global Det is an explicit typed primitive. |
| H2 | PASS | 100% M1 on T1–T4 at n=16/32/64, all three seeds. Numeric thresholds pass; M0 also underfits in-domain, so this is not an isolated extrapolation comparison. |
| H3a | PARTIAL | Discrete: 3/3 per task. Cold joint mixture: 0/3 on T3. Two-stage convex gate: 3/3 per task. |
| H3b | PASS | Nearest-lattice projection preserves 100%; at k=32 it repairs the parity depth failure. |
| H3c | PARTIAL | T7 transfers zero-shot in the supplied composition. T8 does not. After refinement, scratch and transfer both pass at 50 examples; a universal 2× sample gain is not established. |
| H3d | PASS, amended | DFT selected 81/81; 16–128× fewer full-vector examples than dense LS. Tied circulant control is equivalent; asymptotic scaling is not inferred from three sizes. |
| H3e | PASS, amended | Trained 14-entry tables + L-BFGS: max error 0.000288044151 < .001 at beta=24645.233; direct Tropical max error 2.14638794e-05. Original raw beta=64 criterion fails. |

### T1–T4: 1.000 exemple de antrenare, n=32, 500 exemple de test

| Task | M0 | M1, lumea corectă | M1, rotunjit |
|---|---|---|---|
| T1 | 0.20 ± 0.20% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T2 | 4.53 ± 1.47% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T3 | 52.53 ± 8.76% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T4 | 0.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |

Valorile sunt medie ± deviație standard între trei inițializări. Aceleași 500 de instanțe sunt folosite între seed-uri. Pentru numărări, „corect” înseamnă toleranța log1p de 0,001 din brief, nu egalitate între întregi.

Limita comparației H2: M0 este deja slab pe validarea n≤8 (0,67% T1; 26,5% T2; 54,5% T3; 5,33% T4). Pragurile numerice trec, dar nu demonstrează că M0 interpolează bine și eșuează numai la extrapolare. Detalii în VALIDATION.md.

### Ce a picat și de ce

La T3, mixtura simultană selectează Tropical în loc de Parity; preantrenarea experților și selecția convexă înlătură eșecul. La T6, Adam singur nu ajustează suficient tabelele, însă L-BFGS pe aceleași date mici reușește. La paritate, k=32 reduce modelul continuu rafinat la 55% pe n=64; proiecția discretă restabilește 100%.

### Abateri de la protocol

Det este un operator global tipizat; beta se alege prin limita de entropie; Count/LogBeta au și identificare până la echivalență; T5 păstrează un kernel fix și separă exemplele vectoriale de răspunsurile scalare. Sunt adăugate controale explicite: adâncime, proiecție, optimizare L-BFGS, selecție convexă și parametrizare circulantă. Detaliile, bugetele și momentul adăugării controalelor sunt în ASSUMPTIONS.md. Niciun rezultat Adam sau beta=64 nu este eliminat.
