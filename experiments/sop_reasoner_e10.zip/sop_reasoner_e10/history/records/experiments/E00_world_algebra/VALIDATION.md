# In-domain baseline check

| Task | M0 validation accuracy, n≤8 | M0 validation MSE |
|---|---|---|
| T1 | 0.67 ± 0.29% | 0.056714 ± 0.009939 |
| T2 | 26.50 ± 2.60% | 3.971381 ± 0.444404 |
| T3 | 54.50 ± 3.46% | 0.240889 ± 0.006213 |
| T4 | 5.33 ± 4.01% | 0.004870 ± 0.003206 |

Means and sample SD over three seeds, 1,000 training examples each. The numerical H2 criteria pass, but the baseline does not first achieve strong in-domain exact accuracy. This experiment therefore does not isolate an extrapolation-only failure. In particular, count errors are evaluated at a stringent log1p tolerance of .001.

The baseline passes weighted-degree features into each message layer rather than pairing every edge weight with its neighbour embedding. This is a restricted edge-feature architecture on T2, not a comparison against all edge-conditioned GNNs. T1, T3 and T4 have constant edge weights.
