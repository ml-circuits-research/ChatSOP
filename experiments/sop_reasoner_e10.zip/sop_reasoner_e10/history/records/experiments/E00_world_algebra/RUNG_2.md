# Rung 2: H2 PASS; H3a PARTIAL; H3b PASS

| Task | M0 | M1 correct | M1 rounded |
|---|---|---|---|
| T1 | 0.20 ± 0.20% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T2 | 4.53 ± 1.47% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T3 | 52.53 ± 8.76% | 100.00 ± 0.00% | 100.00 ± 0.00% |
| T4 | 0.00 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% |

| Task | Discrete world ID | Cold joint mixture ID | Two-stage convex gate ID |
|---|---|---|---|
| T1 | 3/3 | 3/3 | 3/3 |
| T2 | 3/3 | 3/3 | 3/3 |
| T3 | 3/3 | 0/3 | 3/3 |
| T4 | 3/3 | 3/3 | 3/3 |

The gate uses training labels only and frozen experts; it is a supplemental solution, not a replacement for the failed cold joint mixture. Count/LogBeta equivalence statistics are in results/learning.json.
