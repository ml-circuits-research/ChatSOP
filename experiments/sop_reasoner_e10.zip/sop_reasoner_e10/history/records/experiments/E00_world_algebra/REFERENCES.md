# Primary implementation references

The inequalities and identifiability arguments in MATHEMATICS.md are derived there. The software uses the following official documentation; installed versions are pinned in requirements.txt.

NetworkX: number_of_spanning_trees, including weighted Kirchhoff cofactors and directed-root conventions.
https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.tree.mst.number_of_spanning_trees.html

PyTorch: torch.logsumexp and its numerically stabilized reduction.
https://docs.pytorch.org/docs/stable/generated/torch.logsumexp.html

PyTorch: torch.linalg.slogdet, sign and log-absolute determinant, including batch support.
https://docs.pytorch.org/docs/stable/generated/torch.linalg.slogdet.html

NumPy: numpy.linalg.lstsq, minimum-norm least-squares fitting.
https://numpy.org/doc/stable/reference/generated/numpy.linalg.lstsq.html

SciPy: solve_circulant and Fourier diagonalization of circulant systems.
https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.solve_circulant.html
