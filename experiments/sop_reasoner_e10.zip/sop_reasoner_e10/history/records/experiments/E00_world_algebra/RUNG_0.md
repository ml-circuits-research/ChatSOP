# Rung 0: PASS under repaired criteria

Original protocol: FAIL (finite-beta guarantee and strict Det interface).

| Task | Split | Count | Exact errors |
|---|---|---|---|
| T1 | small | 1000 | 0 |
| T1 | n=64 | 100 | 0 |
| T2 | small | 1000 | 0 |
| T2 | n=64 | 100 | 0 |
| T3 | small | 1000 | 0 |
| T3 | n=64 | 100 | 0 |
| T4 | small | 1000 | 0 |
| T4 | n=64 | 100 | 0 |
| T6 | small | 1000 | 0 |
| T6 | n=32 | 100 | 0 |
| T6 | n=64 | 100 | 0 |
| T7 | small | 1000 | 0 |
| T7 | m=8 | 100 | 0 |
| T7 | m=12 | 100 | 0 |
| T8 | small | 1000 | 0 |
| T8 | n=64 | 100 | 0 |

| Task | n | Certified beta | Count | Failures | Maximum error |
|---|---|---|---|---|---|
| T2 | 32 | 123226.165 | 100 | 0 | 0.00013121099 |
| T2 | 64 | 295742.797 | 100 | 0 | 7.74454927e-05 |
| T6 | 32 | 24645.233 | 100 | 0 | 0.000261151937 |
| T6 | 64 | 49290.466 | 100 | 0 | 0.000226080219 |

T5 adds 3000 exact-operator numerical checks.
