# Clean reproduction: PASS

Fresh run: 650.9 seconds.

80 JSONL datasets byte-identical; 9 operator datasets array-identical; 354 checkpoints tensor-identical.

Scientific JSON comparison: 9/9 passed (rtol=1e-11, atol=1e-12; runtimes excluded).

New directory and venv; reused installed dependency directories through an explicit .pth file (no new dependency download). This is not an independent machine or independently downloaded dependency installation.

The test suite and all training stages ran from scratch. Counts and classification outcomes are included in the scientific comparisons.
