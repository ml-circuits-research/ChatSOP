# Compositional Algorithm Discovery

A small CPU experiment in which an exact #SAT solver is not written as one fixed algorithm. Instead, a meta-search composes a solver from reusable verified primitives:

- `unit`: exact unit propagation
- `subsume`: exact clause subsumption
- `decompose`: connected-component decomposition
- memoization: `none`, `raw`, or `canonical` under variable renaming
- branching: `first`, `maxocc`, or `minclause`

The resulting program is frozen after training-only selection and evaluated on held-out formula families and larger formulas.

The ML component (`ExtraTreesRegressor`) only ranks complete candidate programs. It cannot change the answer. Every candidate primitive preserves #SAT semantics, and all 144 compositions are cross-checked against brute-force counting on small formulas.

## Commands

```bash
make test
make reproduce
```

`make reproduce` writes `results.json` and `REPORT.md`.

## Main result

Training-only search selected:

```text
unit > decompose > subsume | memo=canonical | branch=maxocc
```

The useful core is compositional: propagation exposes structure; decomposition creates independent subproblems; canonical memoization reuses renamed-isomorphic subproblems; max-occurrence branching tends to expose the shared bridge variable. `subsume` is a small training overfit and is slightly worse on held-out instances; it is retained rather than removed post hoc.

This experiment does **not** claim invention of a new primitive. The next research step is primitive invention from failed search traces: propose a new quotient, predicate, bound, or decomposition rule, verify it, then add it permanently to the reasoning language.
