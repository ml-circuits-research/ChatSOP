# Compositional algorithm discovery — report

## Verdict

Across 144 exact solver programs built by composing generic reasoning primitives, training-only search selected `unit>decompose>subsume|memo=canonical|branch=maxocc` and then froze it before held-out evaluation. The compiled composition remained exact in all 576 exhaustive small-instance checks and scaled to formulas with hundreds of variables. The useful behavior is genuinely compositional: decomposition, canonical reuse, propagation and branching choice contribute different parts of the gain. A learned cost model reduced the number of expensive program evaluations needed to find a near-optimal composition, but the search space is still small enough that this is not yet evidence of autonomous invention beyond the supplied primitives. The independently computed held-out oracle program is reported only as a diagnostic, not used for selection.

## Held-out performance of the frozen discovered composition

| instance | vars | clauses | work | calls | branches | decompositions | cache hits | time (s) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| rep4 | 20 | 24 | 19.2 | 11 | 2 | 2 | 4 | 0.0003 |
| bridge4 | 21 | 32 | 30.8 | 19 | 5 | 2 | 6 | 0.0012 |
| mixed4c2 | 23 | 39 | 17.9 | 9 | 2 | 1 | 3 | 0.0005 |
| mixed5c3 | 29 | 49 | 20.0 | 10 | 2 | 1 | 4 | 0.0008 |
| chain20 | 20 | 26 | 9.0 | 1 | 0 | 0 | 0 | 0.0005 |

## Ablation on the same large suite

| ablation | program | geometric-style score | effect vs discovered |
|---|---|---:|---:|
| no_unit | `decompose>subsume|memo=canonical|branch=maxocc` | 4.213 | 3.5× multiplicative work factor |
| no_decompose | `unit>subsume|memo=canonical|branch=maxocc` | 4.659 | 5.5× multiplicative work factor |
| raw_memo | `unit>decompose>subsume|memo=raw|branch=maxocc` | 3.609 | 1.9× multiplicative work factor |
| no_memo | `unit>decompose>subsume|memo=none|branch=maxocc` | 3.609 | 1.9× multiplicative work factor |
| first_branch | `unit>decompose>subsume|memo=canonical|branch=first` | 3.384 | 1.5× multiplicative work factor |
| no_subsume | `unit>decompose|memo=canonical|branch=maxocc` | 2.877 | 0.9× multiplicative work factor |

## Learned proposer: evaluations until a program within 10% of optimum

| held-out instance | ML | lexical enumeration | random mean | rank assigned to exact optimum |
|---|---:|---:|---:|---:|
| rep4 | 1 | 52 | 21.8 | 8 |
| bridge4 | 1 | 53 | 33.2 | 3 |
| mixed4c2 | 1 | 52 | 34.1 | 8 |
| mixed5c3 | 1 | 52 | 36.3 | 9 |
| chain20 | 1 | 10 | 1.5 | 97 |

The ML model never affects correctness: it only orders which complete, exact solver program is evaluated first. Every primitive is semantics-preserving, and 144 programs were checked against brute-force #SAT on four small formulas, for 576 exact soundness checks.

## Larger scaling

| instance | work | calls | branches | cache hits | time (s) | answer digits |
|---|---:|---:|---:|---:|---:|---:|
| rep50 | 95.3 | 57 | 3 | 49 | 0.0066 | 48 |
| bridge50 | 157.5 | 111 | 5 | 99 | 0.0269 | 43 |
| mixed50c20 | 101.2 | 55 | 2 | 49 | 0.0261 | 31 |

## Interpretation

This is a stronger test than discovering one abstraction at a time. The reusable object is now an executable **reasoning program** composed from verified primitives. On repeated and bridged CNFs, canonical memoization converts isomorphic renamed subproblems into one reusable computation; decomposition turns a global search into independent subproblems; unit propagation removes forced variables; max-occurrence branching tends to expose the shared bridge variable and thereby creates decomposable subproblems. Their combination is analogous to a small exact #SAT algorithm synthesized from a meta-language.

The result still has an important limitation: the engine did not invent a new primitive. It searched compositions of a supplied vocabulary. Therefore the next threshold for a genuinely stronger reasoning architecture is **primitive invention**: when no composition is adequate, derive a new predicate, bound, quotient or decomposition operator from failed search traces, verify it, then add it permanently to the language.