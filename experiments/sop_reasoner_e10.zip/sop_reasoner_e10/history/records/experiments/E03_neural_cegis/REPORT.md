# Hybrid neural proposal + exact CEGIS: result

## Verdict

The tested hybrid does **not** provide evidence for a better ML architecture. A neural classifier can propose a strong approximate quotient and CEGIS can make it exact on small and medium local-CNF families, but an exact symbolic active learner (L*) reaches the correct quotient with substantially fewer oracle bits and fewer equivalence rounds. On the largest tested family, both the MLP and a decision-tree control remain inexact after 30 CEGIS rounds despite 96.7–97.8% raw-state classification accuracy.

The useful finding is sharper: **the bottleneck is discovering distinguishing predicates/counterexamples, not projecting an approximately correct partition to a discrete quotient.**

## Problem

Each target is a family of Boolean formulas formed by forbidding several local bit patterns. A forbidden pattern of length `k` is equivalent to one CNF clause on every sliding window of length `k`; model counting is therefore the exact number of assignments avoiding all forbidden patterns.

A generic width-`K-1` dynamic program can distinguish all boundary assignments, while the semantic minimal automaton often has far fewer states. The experiment asks whether ML can infer this semantic quotient from a small number of exact observations and then let an exact verifier repair the remaining mistakes.

## Hybrid protocol

For each semantic target state, a greedy set of distinguishing continuation suffixes is constructed. The Boolean answers on these suffixes define an exact behavioral signature. This gives the ML method an intentionally favorable interface: it knows the number of signature classes and the probe set; the cost of constructing the probe set is not charged.

The proposer is either a two-layer MLP or a decision tree. It sees a small set of boundary assignments with their exact behavioral signatures, predicts a quotient class for every raw boundary state, and builds a candidate finite-state counter. An exact product verifier either certifies equivalence or returns a shortest counterexample. States on the counterexample path and one-bit counterfactual neighbors are then labeled and added to training. This repeats for at most 30 rounds.

For comparability, one labeled boundary state is charged `|E|` binary membership answers, where `E` is the distinguishing probe set. L* is run directly with binary membership and exact equivalence queries.

## Results

| Family | Raw boundary states | Exact reachable quotient (L*) | Probe width | L* binary MQ / EQ | MLP equivalent MQ / EQ | MLP exact? | Tree equivalent MQ / EQ | Tree exact? |
|---|---:|---:|---:|---:|---:|---|---:|---|
| small | 45 | 8 | 7 | 87 / 3 | 257 / 2.3 | 3/3 | 257 / 2.3 | 3/3 |
| medium | 56 | 9 | 5 | 83 / 3 | 167 / 2.7 | 3/3 | 163 / 2.7 | 3/3 |
| large | 460 | 22 | 12 | 415 / 5 | 2,232 / 13.7 | 3/3 | 2,836 / 16.3 | 3/3 |
| xlarge | 7,602 | 34 | 16 | 949 / 5 | 7,947 / 30 | 0/3 | 8,080 / 30 | 0/3 |

Values for learned proposers are means over seeds 0, 1, 2. The xlarge MLP uses a reduced 150 optimization steps per CEGIS round to keep the stress test within CPU budget; it reaches 97.8% mean mapping accuracy but never an exact quotient in 30 rounds. The decision-tree control, which does not have a neural optimization issue, also fails 3/3 at xlarge with 96.7% mean mapping accuracy.

For all successful candidates, exact model counts agree with the target at extension lengths 32, 128, 1,024 and 10,000. Independent tests also compare the automaton counter against direct brute-force evaluation of the corresponding local CNF language for small sizes.

## Interpretation

### 1. Approximate state prediction is not the hard part

At xlarge, approximately 98% of raw states can be classified correctly and the candidate is still wrong. A few rare state confusions are enough to change counts after long composition. This recovers, in a harder form, the earlier observation that local numerical accuracy is not a substitute for exact compositional structure.

### 2. CEGIS alone does not rescue a generic classifier efficiently

The verifier does find counterexamples, but the MLP repeatedly repairs local mistakes while creating or retaining other rare mistakes. The symbolic learner instead changes its observation table by introducing distinguishing continuations; one counterexample can therefore refine an entire equivalence relation rather than merely add more classified points.

### 3. ML does reduce raw enumeration, but not the relevant exact-learning cost

On xlarge the MLP labels roughly 497 of 7,602 raw states, so it avoids enumerating most boundary assignments. However, each label requires a 16-bit exact signature, giving about 7,947 binary-equivalent observations and still no proof of correctness. L* needs 949 binary membership answers and five equivalence checks to obtain the exact 34-state machine.

### 4. This falsifies the simple architecture claim

The architecture

`neural quotient proposal -> exact verifier -> counterexample -> retrain`

is not enough, by itself, to justify a new generation of ML architecture. It is inferior to a classical symbolic active learner on these tasks even though the setup gives ML substantial favorable information.

## The architectural hypothesis that survives

The experiment points to a different role for ML. The symbolic learner wins because it discovers **which distinction to ask for**. Therefore the learnable object should probably not be the quotient-state classifier itself. It should be a policy for proposing new discriminating predicates, suffixes, invariants, decompositions, or rewrite rules while the exact symbolic layer owns the partition and correctness.

A stronger architecture would therefore be:

`exact symbolic state partition + learned proposal policy + exact counterexample oracle`.

ML proposes the *next experiment/split*, not the final semantic class. Every accepted split is exact. This preserves the ability of symbolic active learning to refine whole equivalence classes while using ML only where combinatorial search over possible discriminators becomes large.

That is the next hypothesis worth testing on public model-counting instances. The current direct-classification hybrid should not be promoted as a new ML architecture.
