# Hybrid CEGIS quotient experiment

CPU experiment testing a neural proposal -> exact verification -> counterexample refinement architecture for exact model counting on local-CNF families.

Run:

```bash
python experiment.py
pytest -q
```

`small.json`, `medium.json`, and `large.json` contain the standard MLP/tree runs. `xlarge_full.json` contains the xlarge stress test; its MLP uses `experiment_fast.py` (150 optimization steps per CEGIS round) for a bounded CPU run.

See `REPORT.md` for the interpretation.
