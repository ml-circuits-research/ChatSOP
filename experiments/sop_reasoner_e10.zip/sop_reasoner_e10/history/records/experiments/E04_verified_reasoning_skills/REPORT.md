# Verified Theory Learning mini-engine — experimental report

## Verdict

The same verified-refinement component rediscovered four classical algorithmic ideas from small exact traces: finite-memory dynamic programming, symmetry/equality quotienting, subset-sum memoization with sound pruning, and the additive Bellman state for knapsack with a certified upper bound. These skills remained exact on larger instances. The learned proposal guide reduced verification ordering cost only modestly; it is not yet evidence that ML can invent better algorithms than symbolic search.

## 1. Discovered skills

| Domain | Discovered reusable skill | Exact verification | Scaling test |
|---|---|---:|---|
| Forbidden patterns P3 | `remaining+suffix[2]` | 0 violations | n=1000: 3999 DP states, 0.0029s |
| Forbidden patterns P5 | `remaining+suffix[4]` | 0 violations | n=1000: 15967 DP states, 0.0125s |
| Forbidden patterns P6 | `remaining+suffix[5]` | 0 violations | n=1000: 31903 DP states, 0.0290s |
| 4-color cycle | `remaining+equality(first,last)` | 0 violations | n=10000: 19998 abstract DP states, 0.0066s |
| 6-color cycle | `remaining+equality(first,last)` | 0 violations | n=10000: 19998 abstract DP states, 0.0101s |
| 8-color cycle | `remaining+equality(first,last)` | 0 violations | n=10000: 19998 abstract DP states, 0.0119s |
| Subset sum | `problem+i+sum` + verified zero-subtree predicates | 0 signature violations | n=64: 10944 DP states vs 2^65-1 raw nodes |
| Knapsack | `problem+i+weight` with potential `subtract current value` + `min(sum-bound, ratio-bound)` | 0 violations | n=70: 12702 DP states; B&B 7851190 calls |

## 2. What was actually discovered

**Finite-memory DP.** The engine starts from full prefixes and tests candidate state signatures against exact continuation values. It selects the smallest verified signature. For forbidden-substring counting it learns that only a short suffix plus remaining length matters; the resulting compiled recursion handles n=1000 exactly.

**Symmetry quotient.** For cycle coloring, the engine rejects signatures based only on a concrete color and accepts the relational predicate `first == last`. Thus color identities disappear and the computation becomes a two-state recurrence per depth.

**Memoization and pruning.** On subset sum, histories that share `(problem, i, sum)` have identical continuation counts. Independently, the engine verifies predicates that imply a zero subtree. Invalid candidate pruning rules are rejected before compilation.

**Bellman decomposition.** On knapsack, the best quotient appears only after subtracting the current accumulated value: future optimal gain depends on `(i, weight)`, not on the full choice history. This is the structural form of the classical Bellman state. The engine also selects the tightest universally valid upper-bound expression from its candidate language.

## 3. Learned proposal guide

- learned: mean 1.00 expensive verifier calls; median 1.0; max 1.
- heuristic: mean 1.33 expensive verifier calls; median 1.0; max 2.
- random: mean 6.83 expensive verifier calls; median 6.5; max 13.
- oracle: mean 1.00 expensive verifier calls; median 1.0; max 1.

The ML guide affects only proposal ordering. Correctness is unchanged because no candidate reaches the compiled skill library unless the exact verifier reports zero violations. In this small DSL, the learned guide is not dramatically better than a cheap heuristic; symbolic discovery remains sufficient.

## 4. Interpretation

This experiment supports a reusable architecture in which experience is compiled into verified reasoning skills rather than only into weights. A skill is a tuple `(applicability, abstraction/rewrite/bound, certificate, cost model)`. The downstream solver can reuse the skill without the learner.

It does **not** yet show autonomous invention of a genuinely new algorithm. The engine searches a supplied meta-language of candidate signatures, predicates, potentials and bounds. The important positive result is that the same verification/refinement interface can recover qualitatively different algorithmic shortcuts and safely compose them. The next hard test is to make the candidate language combinatorially large enough that symbolic enumeration becomes expensive and ask whether a learned proposer discovers useful multi-step skills that a symbolic baseline does not reach within the same budget.
