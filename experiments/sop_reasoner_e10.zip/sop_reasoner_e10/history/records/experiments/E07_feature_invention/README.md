# Verified Derived-Feature Invention

A small CPU experiment testing whether a reasoning engine can create a new derived state feature that makes an exact pruning rule possible. It starts with raw state variables and sparse linear expressions; failure on a nonlinear domain triggers degree-2 representation expansion. Every compiled shortcut requires a semantic verifier certificate.

Run:

```bash
make reproduce
```
