# Verified Derived-Feature Invention — Experiment Report

## Verdict

**PASS for invention of derived features and failure-driven grammar expansion; PASS for exact compilation; PASS for the negative control. PARTIAL for open-ended algorithm invention because the meta-grammar (arithmetic + multiplication after failure) is still designer supplied.**

## 1. Linear derived feature invention

The learner did not receive an `unlocked`/phase feature. From raw variables `{w, i, T, v, C, 1}` it searched sparse arithmetic expressions used as a guard on a previously learned dominance relation.

Discovered feature: **`-T + 3*i + 2*w >= 0`**. Candidates generated: 4,432; verifier calls: 176; counterexamples: 8.

Exact invariant certificate: -T + 3*i + 2*w >= 0 is a positive rescaling of the hidden monotone activation potential. The potential is nondecreasing under skip/take transitions; equal i and weightA<=weightB imply activation(A)=>activation(B). Once A is activated both states receive identical terminal bonus, so ordinary knapsack dominance is an inductive simulation.

| n | cumulative labels with invented feature | raw labels | reduction | pruned |
|---:|---:|---:|---:|---:|
| 14 | 237 | 5,120 | 21.6× | 176 |
| 18 | 13,229 | 16,847 | 1.3× | 1,753 |
| 22 | 22,741 | 26,076 | 1.1× | 2,198 |
| 28 | 21,113 | — | — | 6,074 |
| 40 | 24,023 | — | — | 9,792 |
| 60 | 550,706 | — | — | 31,368 |
| 100 | 2,155,718 | — | — | 96,917 |

All cases with a raw comparison return the identical exact optimum. Larger cases are additionally checked against the independent dynamic-programming oracle used by the verifier.

## Why the invented feature is necessary

Ordinary Pareto dominance is actually unsound in these phase-bonus domains. Two fixed counterexamples were tested end-to-end:
| domain | exact optimum | unguarded dominance | solver with invented feature |
|---|---:|---:|---:|
| linear | 154 | **19 (wrong)** | **154 (exact)** |
| quadratic | 191 | **6 (wrong)** | **191 (exact)** |

Thus the derived feature is not cosmetic: it supplies the applicability condition that makes a useful but otherwise invalid algorithmic shortcut sound.

## 2. Failure-driven feature-language growth

On a second domain whose hidden phase boundary is nonlinear, the original linear feature language produced **no certifiable feature** after 300 verifier calls. The engine therefore activated the next generic representation constructor: pairwise products/squares.

After adding `w2`, `wi`, `i2`, it discovered **`-T + 2*i + w2 >= 0`** from 17,826 generated sparse expressions, using 2031 verifier calls.

Exact invariant certificate: -T + 2*i + w2 >= 0 is a positive rescaling of the hidden monotone activation potential. The potential is nondecreasing under skip/take transitions; equal i and weightA<=weightB imply activation(A)=>activation(B). Once A is activated both states receive identical terminal bonus, so ordinary knapsack dominance is an inductive simulation.

| n | cumulative labels | raw labels | reduction | pruned |
|---:|---:|---:|---:|---:|
| 14 | 3,512 | 5,715 | 1.6× | 695 |
| 18 | 7,508 | 11,226 | 1.5× | 1,104 |
| 22 | 19,994 | 29,309 | 1.5× | 2,436 |
| 28 | 46,741 | — | — | 5,396 |
| 40 | 121,331 | — | — | 12,777 |
| 60 | 477,559 | — | — | 22,338 |
| 100 | 2,580,952 | — | — | 82,843 |

## 3. Negative control

The same degree-2 language was applied to a deliberately hash-like phase rule. It obtained **no general certificate** (`found = None`) after 300 verifier calls and 5 semantic counterexamples. The system therefore refuses to compile an invented shortcut.

## Interpretation

The important step beyond the previous experiment is that the pruning skill is no longer expressible using only the supplied raw predicates. The system constructs a new scalar representation from raw state variables, turns its sign into a reusable semantic predicate, verifies that predicate against transition semantics, and compiles it into an exact pruning algorithm. When the first representation language cannot express a valid invariant, counterexamples trigger a richer representation basis; when even that basis does not support a proof, the engine refuses the shortcut.

This is still not unrestricted invention: the system is given an arithmetic expression grammar and a policy that expands from degree 1 to degree 2. A stronger next experiment would require the engine to select among qualitatively different constructors (products, modulo, min/max, aggregation over sets, quotient maps, coordinate transforms) based only on failed proofs and expected search reduction.
