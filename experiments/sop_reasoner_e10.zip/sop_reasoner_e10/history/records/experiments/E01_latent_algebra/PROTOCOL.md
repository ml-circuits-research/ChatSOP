# Hidden-algebra simulation — protocol fixed before measured runs
Date: 2026-09-30. This is a CPU feasibility study, not proof of a superior general-purpose architecture.

## Questions
Q1. Can two unknown operation tables be learned from final labels of small expressions, without primitive-operation targets?
Q2. Does discretization preserve or improve extrapolation to longer/deeper expressions?
Q3. Does projection onto *all* finite unital commutative semirings help beyond independent argmax?
Q4. Is a neural learner better than exhaustive symbolic identification on exactly the same data?
Q5. Does a learned symbol encoder work, and what happens when the assumed algebraic laws are wrong?

## Fixed primary design
Three hidden targets: integers mod 3, integers mod 4, and the four-element field. Symbol names are permuted. Their formulas occur only in the data generator and post-training diagnostics. The learner knows the alphabet size and the role of the two operation tokens, but not their tables or identities. Every candidate for exact projection is generated from algebraic axioms, not a menu of named target formulas.
Training examples are balanced binary expressions with 4 or 8 leaves; only the final answer is supplied. Budgets: 32, 128, 512 examples; three seeds: 0, 1, 2. Validation: 256 shallow examples. Tests: 512 independent examples per length/distribution, held fixed and separate. Test distributions: balanced mixed-operation trees (8, 32, 128, 512 leaves), and addition-only left folds (8, 32, 128, 512 leaves). The latter prevents absorption by multiplication from making long examples trivial. All accuracies are final-class exact match. Majority accuracy and label frequencies are reported.

Models: (1) soft unknown-table network, (2) the same model with entrywise argmax, (3) nearest globally valid semiring, (4) data-consistent constrained projection, (5) exhaustive symbolic consistency baseline, (6) a shared TreeMLP. Tree structure is provided to *all* models. Primitive table targets are never used for training, selection, or projection. Tables are inspected against the oracle only after selection.

Optimization: CPU, float32; Adam, learning rate .03 for table learner, .003 for TreeMLP; 800 optimizer updates, batch size up to 128, constant softmax temperature 1. Checkpoints every 50 steps; minimum shallow validation cross-entropy selects the checkpoint. Hidden size 32 for TreeMLP. No extrapolation labels used for selection or hyperparameter tuning. A shallow-only optimizer refinement may be run as a separately labelled control, never overwrite the primary result.

Main table learner uses given one-hot symbol IDs, not an invented perceptual model. A separate jointly learned encoder/decoder test will expose whether latent-state learning is actually achieved. The number of latent states remains supplied; adaptive state merging and splitting is NOT claimed.

## Controls and interpretation
Exact catalogue generation independently checks closure, both associativities, commutativity, two identities, absorbing zero, and distributivity. Source tables are independently generated; catalogue inclusion is a test, not a learner input. Projection uses only learned probabilities; data-consistent projection additionally uses training labels, never validation/test labels. Symbolic ambiguity is reported, not suppressed.
A non-associative negative control tests whether enforcing false laws is harmful. Failure to interpolate is distinguished from failure to extrapolate. Outperforming an underfitting baseline is not evidence of an isolated extrapolation advantage. Equality of neural and symbolic solutions means no neural advantage has been established.
All completed and failed runs are retained. Timing, environment, seeds, data hashes and deviations are recorded. Results apply only to small finite algebras and supplied expression syntax, not natural language or arbitrary hidden program structure.

## Declared exploratory controls after the primary runs
These controls do not replace any primary result. (1) Joint encoder/decoder with no identity-coordinate initialization, same 800 steps and shallow validation, distinguishes learning symbols from retaining the supplied labels. (2) A non-associative target uses the same q=4 data budget and models; the semiring-constrained method must not silently claim recovery. (3) L-BFGS refinement of each primary N=512 table checkpoint uses *training examples only*, max_iter=300, strong-Wolfe line search, and reports results separately. This checks a different optimizer; it is not a new preregistered success.

Implementation correction before any measured result: independent training seeds may overlap one another. Validation and test remain disjoint from the union of training pools. Demanding three disjoint 256-example pools with four leaves at q=3 was impossible because that finite input space has only 648 elements. The initial generator timed out and was corrected without changing a measured model result.
