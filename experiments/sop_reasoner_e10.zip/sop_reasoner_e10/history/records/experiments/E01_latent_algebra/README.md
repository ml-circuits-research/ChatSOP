# Hidden algebra: learn, discretize, verify

A small CPU simulation of unknown finite-operation-table learning from **final expression labels only**. It compares differentiable tables, independent rounding, exact axiom projection, data-consistent projection, exhaustive symbolic identification, and a shared TreeMLP. The proposed stronger general-purpose architectural claim is deliberately not assumed.

## Run

Python 3.10+ and a CPU PyTorch build are required. Install the dependencies from `requirements.txt`, then run:

```sh
make reproduce
```

This resumes completed cells. To regenerate everything rather than reuse measurements:

```sh
make clean
make reproduce
```

For one small experiment:

```sh
python src/run.py --tasks z4 --budgets 128 --seeds 0
```

Default hyperparameters, targets, exclusions and the distinction between primary and exploratory controls are in `PROTOCOL.md`. `REPORT.md` gives the short Romanian conclusion. `RESULTS.md` gives the complete interpreted tables. Individual runs, shallow loss curves, learned tables, checkpoint tensors and all negative outcomes are in `results/`. Dataset hashes are in `results/data_hashes.json`.

## Architecture and what is actually learned

`TableNet` has two trainable conditional-probability tables P(result | operator, left state, right state). It propagates categorical state distributions through the supplied expression tree. Every occurrence of an operator shares the same parameters. The primary model uses one-hot external symbol IDs; the latent controls learn encoder/decoder matrices as well. No primitive operation answers, intermediate state labels, or canonical operator initialization are supplied.

`catalogue.py` exhaustively enumerates **all** commutative unital semirings of size 2, 3 or 4 from their axioms. Identities are first gauge-fixed during enumeration, then every external labelling is restored and duplicates removed. These are labelled structures, not isomorphism classes. No list of named target structures is used. The model nevertheless receives a very strong structural prior, and exhaustive enumeration does not scale to large state spaces.

`engine.compile_table` offers two materially different compilers. `projected` minimizes negative learned table log-probability over valid algebras. `consistent` additionally requires agreement with every training output. The symbolic baseline uses the same latter constraint and no neural scores. It reports the number of consistent candidates. If none exists, the data-consistent compiler returns `None`.

`tasks.py` independently implements the hidden targets and reference execution; it imports no learner or catalogue. The target tables are compared to inferred tables only after selection. Training and validation contain 4- or 8-symbol trees only. Test folds have up to 511 sequential operations; balanced test trees have depth up to 9.

## Important limits

This does not discover parse trees, state cardinality, applicability of the axioms, or adaptive state merging/splitting. A correct algebra need not be the correct task. Final-class accuracy on long addition chains does not establish recovery of multiplication. The TreeMLP does not generalize well even to held-out shallow examples, so it is not a clean extrapolation-only baseline. The stronger symbolic comparator already identifies all three targets with 32 examples. See the report rather than interpreting the best percentage in isolation.

## Files

`src/tasks.py`: independent generator; `src/catalogue.py`: all admissible tables; `src/models.py`: neural learners; `src/engine.py`: exact execution and projection; `src/run.py`: training and evaluation; `src/controls.py`: separately labelled additional controls; `src/report.py`: report generation. All code is plain Python with NumPy and PyTorch; no SAT package is needed at this scale.

## Related research

Pedro Zuidberg Dos Martires, *Neural Semirings* (NeSy 2021): https://ceur-ws.org/Vol-2986/paper7.pdf.
Felix Petersen et al., *Deep Differentiable Logic Gate Networks* (NeurIPS 2022): https://arxiv.org/abs/2210.08277.
These are close precedents, not performance baselines reproduced in this repository.

The optional figure can be regenerated after the reports with `python plot.py`. The scientific reproduction check excludes plotting and runtime measurements. Run `python verify.py` to repeat the clean-directory retraining and tensor comparisons. Use `make clean` before changing optimizer settings; cached cells correspond to the documented default protocol.
