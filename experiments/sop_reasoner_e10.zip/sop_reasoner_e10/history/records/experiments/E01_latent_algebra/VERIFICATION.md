# Reproducibility verification

Verdict: PASS.

`make reproduce` was executed in a separate directory without any existing data, models or results. Every model was retrained. The same Python interpreter and installed dependencies were used; this is not independent-machine replication.

Scientific JSON outputs: 87/87 exact agreement after excluding runtime measurements.
Checkpoint tensors: 87/87 identical at every tensor element.
Data archives: 66/66 identical extracted arrays.
Reports: 2/2 byte-identical.
Automated tests: 8 passed in the clean run.
Clean reproduction plus comparison: 124.59 seconds on the available CPU.

Full command output is in `results/verification_run.log`. Machine-readable comparison is in `results/verification.json`.
