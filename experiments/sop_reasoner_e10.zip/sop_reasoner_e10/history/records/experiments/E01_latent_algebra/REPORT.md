# Verdict
Mecanismul este implementabil și util pe calcule finite compoziționale, dar simularea nu dovedește o nouă generație de arhitecturi ML superioare.

## Testul
Am ascuns operațiile pentru Z3, Z4 și GF(4), inclusiv prin redenumirea simbolurilor. Antrenarea primește numai răspunsurile finale ale unor expresii cu 4–8 simboluri. Trei volume (32/128/512), trei seed-uri, 512 teste per condiție. Formulele-țintă nu intră în antrenare sau selecție. Proiecția enumeră toate structurile din clasa axiomatică aleasă.

## Rezultate principale
| Metodă, 512 exemple | Adunări cu 512 simboluri | Expresii mixte cu 512 simboluri |
|---|---:|---:|
| Model continuu | 50.50% | 79.73% |
| Rotunjire independentă | 57.12% | 78.04% |
| Proiecție pe axiome | 100.00% | 85.44% |
| Proiecție pe axiome + consistență cu datele | 100.00% | 100.00% |

Procentele sunt medii peste trei algebre × trei seed-uri. Adunările sunt secvențiale (511 operații), expresiile mixte sunt arbori echilibrați (adâncime 9). Proiecția numai pe axiome recuperează întreaga algebră în 4/9 rulări, deși recuperează adunarea în 9/9.

**Control decisiv:** căutarea simbolică fără rețea obține 100% pe ambele distribuții deja cu 32 de exemple, în toate cele nouă rulări. Există o singură algebră consistentă în fiecare celulă. În aceste condiții, componenta neuronală nu aduce avantaj de identificare.

## Reprezentări învățate și contraexemple
Cu encoder și decoder inițializate complet aleator și antrenate din răspunsurile finale, numai 1/9 rulări recuperează complet sistemul, inclusiv o permutare netrivială a simbolurilor. Învățarea stabilă a stărilor rămâne nerezolvată de această implementare; numărul stărilor este furnizat.

Pe un task neasociativ, în două rulări modelul liber ajunge la 100%; impunerea axiomelor greșite îl coboară la 23,63% și 25,98%. Legile trebuie să fie potrivite problemei, nu doar coerente între ele.

## Interpretare
Rezultatul susține un modul care învață și compilează reguli discrete verificate. Nu susține încă superioritatea unei arhitecturi ML generale. Exactitatea algebrei și consistența cu datele sunt cerințe distincte. Corectitudinea la orice adâncime rezultă prin inducție numai după recuperarea completă a operațiilor și a codificării.

Există și precedent direct pentru ideea generală: *Neural Semirings* (2021), https://ceur-ws.org/Vol-2986/paper7.pdf. O eventuală noutate trebuie formulată mai restrâns, nu ca simpla învățare a operațiilor algebrice.

Codul, toate celulele, rezultatele negative și controalele exploratorii sunt păstrate. Vezi RESULTS.md, PROTOCOL.md și VERIFICATION.md.
