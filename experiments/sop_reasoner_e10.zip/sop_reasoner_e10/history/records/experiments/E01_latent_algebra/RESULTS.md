# Results — hidden-algebra simulation

All accuracies are exact final-class accuracy. Mean ± sample standard deviation across three training/data seeds; test examples are shared between seeds. No primitive-operation labels are supplied.

## Primary experiment, 512 examples, three seeds per algebra

| Target | Soft: long sums | Argmax: long sums | Axiom projection: long sums | Axiom projection: mixed trees | Exact full tables after projection |
|---|---:|---:|---:|---:|---:|
| Z3 | 33.01 ± 1.60% | 35.94 ± 0.00% | 100.00 ± 0.00% | 73.83 ± 0.00% | 0/3 |
| Z4 | 82.55 ± 30.22% | 83.98 ± 27.74% | 100.00 ± 0.00% | 95.38 ± 8.01% | 2/3 |
| GF(4) | 35.94 ± 14.39% | 51.43 ± 3.32% | 100.00 ± 0.00% | 87.11 ± 22.33% | 2/3 |

Long sums are left folds of 512 symbols, hence 511 sequential operations. Mixed trees contain 512 symbols but are balanced (depth 9). Training uses balanced trees with 4 or 8 symbols (depth 2 or 3). These are distinct extrapolation tests; 100% on sums is not 100% on the entire algebra.

## Sample budgets and the decisive symbolic comparison

| Target | Examples | Soft: long sums | Projected: mixed trees | Data-consistent projection: mixed trees | Symbolic: mixed trees | Consistent candidates, seeds 0/1/2 |
|---|---:|---:|---:|---:|---:|---|
| Z3 | 32 | 32.42 ± 2.55% | 45.12 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| Z3 | 128 | 56.18 ± 37.97% | 82.55 ± 15.11% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| Z3 | 512 | 33.01 ± 1.60% | 73.83 ± 0.00% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| Z4 | 32 | 25.59 ± 0.90% | 60.29 ± 7.75% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| Z4 | 128 | 26.50 ± 2.14% | 49.15 ± 27.02% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| Z4 | 512 | 82.55 ± 30.22% | 95.38 ± 8.01% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| GF(4) | 32 | 25.65 ± 2.35% | 47.40 ± 4.20% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| GF(4) | 128 | 25.52 ± 2.55% | 54.69 ± 11.54% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |
| GF(4) | 512 | 35.94 ± 14.39% | 87.11 ± 22.33% | 100.00 ± 0.00% | 100.00 ± 0.00% | 1/1/1 |

For every primary task/budget/seed cell, there is exactly one algebra consistent with the training labels. Therefore data-consistent projection and the symbolic baseline select the same algebra; the neural scores do not contribute to identification in these cells. All of these selected tables equal the independently generated targets on every pair of states.

## Baseline qualification

| Target | TreeMLP training, N=512 | TreeMLP shallow validation | TreeMLP long sums |
|---|---:|---:|---:|
| Z3 | 69.21 ± 2.65% | 51.69 ± 2.83% | 31.12 ± 0.92% |
| Z4 | 67.19 ± 3.05% | 51.30 ± 0.23% | 26.69 ± 0.74% |
| GF(4) | 63.93 ± 2.31% | 43.10 ± 3.16% | 23.96 ± 2.51% |

TreeMLP uses the same given tree and shared operators. It does not solve shallow validation well; it is not evidence that an otherwise successful neural baseline fails only because test expressions are deeper. The symbolic comparator is the stronger control here.

## Jointly learned symbols and operations

| Initialization | Target | Seed | Soft long sums | Soft mixed trees | Joint projection: exact table? |
|---|---|---:|---:|---:|---|
| latent | Z3 | 0 | 32.03% | 74.41% | False |
| latent | Z3 | 1 | 34.18% | 74.22% | False |
| latent | Z3 | 2 | 32.23% | 75.39% | False |
| latent | Z4 | 0 | 45.70% | 86.33% | False |
| latent | Z4 | 1 | 100.00% | 100.00% | True |
| latent | Z4 | 2 | 100.00% | 100.00% | True |
| latent | GF(4) | 0 | 52.73% | 79.10% | True |
| latent | GF(4) | 1 | 25.59% | 65.62% | True |
| latent | GF(4) | 2 | 100.00% | 100.00% | True |
| latent_random | Z3 | 0 | 100.00% | 100.00% | True |
| latent_random | Z3 | 1 | 33.98% | 74.61% | False |
| latent_random | Z3 | 2 | 31.45% | 74.80% | False |
| latent_random | Z4 | 0 | 50.20% | 83.40% | False |
| latent_random | Z4 | 1 | 49.80% | 82.03% | False |
| latent_random | Z4 | 2 | 48.63% | 83.01% | False |
| latent_random | GF(4) | 0 | 26.17% | 69.14% | False |
| latent_random | GF(4) | 1 | 22.46% | 66.60% | False |
| latent_random | GF(4) | 2 | 24.02% | 66.02% | False |

`latent` initializes the encoder and decoder with an arbitrary identity-coordinate bias; `latent_random` does not. Both learn all encoder/decoder parameters from final expression labels. The latter recovers a fully correct algebra and a nontrivial symbol permutation in only 1/9 runs (Z3, seed 0). Cardinality is supplied in both cases. Adaptive state splitting/merging is not implemented.

## Wrong-law negative control

| Seed | Unconstrained hard table: long sums | Forced semiring: long sums | Best legal candidate: training mistakes /512 |
|---:|---:|---:|---:|
| 0 | 51.17% | 25.78% | 357 |
| 1 | 100.00% | 23.63% | 368 |
| 2 | 100.00% | 25.98% | 353 |

This target has operations outside the imposed semiring axioms. No data-consistent semiring exists. In seeds 1 and 2 the unconstrained model recovers the target exactly, while forcing the wrong laws destroys performance. The data-consistent compiler returns no model rather than silently accepting an incorrect one.

## L-BFGS refinement (exploratory, not a replacement)

| Target | Seed | Training accuracy | Exact hard table? | Exact projected table? |
|---|---:|---:|---|---|
| Z3 | 0 | 80.08% | False | False |
| Z3 | 1 | 77.73% | False | False |
| Z3 | 2 | 79.30% | False | False |
| Z4 | 0 | 100.00% | True | True |
| Z4 | 1 | 89.06% | False | False |
| Z4 | 2 | 100.00% | True | True |
| GF(4) | 0 | 83.79% | False | True |
| GF(4) | 1 | 70.12% | False | True |
| GF(4) | 2 | 72.46% | False | False |

Refinement does not increase the number of fully correct projected algebras: it remains 4/9. More optimizer sophistication alone has not removed the observed optimization failures.

## What is supplied, learned and verified

Supplied: finite cardinality (3 or 4), tokenized inputs and full expression trees, and the class of unital commutative semiring laws. Learned: unknown operation tables; in the separate latent tests, symbol encoder/decoder probabilities. Verified: all finite algebraic axioms, agreement with final training labels, and (only after selection) equality of recovered tables to the independent oracle. No target table is supplied to the optimizer, projector, or symbolic learner.

The catalogue contains 36 externally labelled 3-state semirings and 828 externally labelled 4-state semirings. These are not counts of isomorphism classes. The candidate family is generated from axioms; no named-target menu is used. Exhaustive enumeration at this size is nevertheless an explicit finite hypothesis search, not a scalable general-purpose algebra discovery engine.

## Conditional correctness argument

If each leaf is encoded correctly, each recovered binary-operation table agrees with the target on every pair of reachable states, and the decoder is correct, then any finite expression over those operations is evaluated correctly. The proof is structural induction on the expression tree. This applies to the completely recovered tables, not merely to a high average test score or to any algebra satisfying the axioms. A correct but wrong algebra remains possible unless the data identify the target.

## Novelty check

The broad idea of learning semiring operators jointly with representations has a close prior: Pedro Zuidberg Dos Martires, *Neural Semirings*, NeSy 2021, https://ceur-ws.org/Vol-2986/paper7.pdf (especially Sections 3–4 and Figure 1). Differentiable training followed by discrete logic execution also predates this simulation: Petersen et al., *Deep Differentiable Logic Gate Networks*, NeurIPS 2022, https://arxiv.org/abs/2210.08277. These precedents do not establish that every detail of finite joint projection is already known, but they invalidate a claim that the broad architecture is new without a much narrower contribution and literature review.

## Verdict

A functional finite-algebra learner/compiler exists in this repo. Exact constraints can repair a learned computation, and exact table recovery gives depth-independent correctness within the supplied language. The stronger claim of a superior new ML generation is NOT established: pure symbolic identification is more sample-efficient here, unconstrained latent-state learning is unreliable, and the experiment does not learn tree structure, state cardinality or applicability of the algebraic laws.
