# Verified Algorithmic Concept Invention — Experiment Report

## Verdict

**PASS for synthesis, transfer, and counterexample-driven specialization of a new dominance-pruning skill; PARTIAL for the stronger claim of open-ended algorithm invention.**

The engine was not given a `dominance` primitive. It received pairwise comparisons/equalities and conjunction. From exact small-instance behavior it synthesized:

`iA == iB AND weightA <= weightB AND valueA >= valueB`

and the verifier issued an inductive simulation certificate for that relation.

## 1. Invention on 0/1 knapsack

Training examples: 35,000; candidate conjunctions scored: 561; verifier calls: 1; counterexamples incorporated: 0.

Certificate: Inductive simulation: equal item index; weightA<=weightB preserves feasibility of every action of B; valueA>=valueB is preserved by identical skip/take rewards; terminal objective order is preserved.

| n | discovered solver generated labels | cumulative kept labels | final Pareto frontier | raw enumeration |
|---:|---:|---:|---:|---:|
| 16 | 517 | 305 | 37 | 131071 |
| 20 | 1,355 | 773 | 70 | 2097151 |
| 24 | 1,321 | 743 | 72 | 33554431 |
| 28 | 2,645 | 1,425 | 84 | 536870911 |
| 32 | 3,772 | 2,069 | 155 | 8589934591 |
| 40 | 5,902 | 3,132 | 145 | 2199023255551 |
| 60 | 19,093 | 9,921 | 297 | 2305843009213693951 |
| 100 | 69,501 | 35,503 | 624 | 2535301200456458802993406410751 |

The learned relation compiles to Pareto-frontier pruning. Exact optima agree with unpruned enumeration wherever the latter is run.

## 2. Transfer to resource-constrained shortest path

Only the relational shape was reused (`one equality + two order relations`); feature names were not transferred. It mapped to `nodeA == nodeB AND resourceA <= resourceB AND costA <= costB`.

Template transfer searched **196** structural mappings and needed **1** verifier call; synthesis from scratch scored **1,940** conjunctions and also needed **1** verifier call. Candidate scoring time fell from 9.38s to 0.94s in this implementation.

Certificate: Inductive simulation: equal node exposes identical outgoing edges; resourceA<=resourceB preserves budget feasibility; costA<=costB is preserved by identical edge costs; terminal minimum-cost order follows.

| stages | generated labels with pruning | cumulative kept | final frontier | raw path count |
|---:|---:|---:|---:|---:|
| 10 | 830 | 191 | 25 | 9765625 |
| 15 | 1,860 | 410 | 38 | 30517578125 |
| 20 | 3,435 | 737 | 50 | 95367431640625 |
| 30 | 7,860 | 1,647 | 75 | 931322574615478515625 |
| 50 | 21,855 | 4,496 | 125 | 88817841970012523233890533447265625 |
| 100 | 87,200 | 17,689 | 249 | 7888609052210118054117285652827862296732064351090230047702789306640625 |
| 200 | 348,540 | 70,205 | 497 | 62230152778611417071440640537801242405902521687211671331011166147896988340353834411839448231257136169569665895551224821247160434722900390625 |

## 3. Negative transfer and automatic specialization

The target domain adds a terminal bonus when accumulated weight crosses a threshold. Ordinary dominance is no longer sound.

Concrete counterexample: A=(weight 2, value 5) has optimal completion 5; B=(weight 7, value 4) has optimal completion 104. The transferred base rule matches this pair: `True`.

CEGIS specialized the skill to `iA == iB AND weightA <= weightB AND valueA >= valueB AND A bonus already unlocked` by adding ['A bonus already unlocked'].

Specialization verifier calls: 18; certificate: Specialized inductive simulation: A is already above threshold; weightA<=weightB implies B is also unlocked. The terminal bonus is therefore identical, and ordinary knapsack dominance applies.

On 20 fresh bonus-knapsack instances the specialized rule returned the exact optimum on **20/20** and pruned 16,289 labels in total.

## Interpretation

The experiment demonstrates a stronger operation than selecting a known algorithm: the system constructs a new pruning predicate from lower-level relational primitives, verifies it, compiles it as a reusable skill, transfers its structural form to another domain, and narrows its applicability when a new semantic effect falsifies the original rule.

It does **not** yet demonstrate open-ended invention. The predicate language (comparisons, equality, conjunction and a small set of domain-observable predicates) is designer supplied, and the verifier knows the transition semantics. The next threshold is to invent a new derived feature/invariant or a multi-step transformation absent from that language, rather than merely synthesize a predicate over available features.
