# Verified Algorithmic Concept Invention

Small CPU experiment testing whether a reasoning engine can synthesize a reusable algorithmic pruning concept rather than select a named algorithm.

The learner does **not** receive a `dominance` primitive. Its rule language contains pairwise feature comparisons/equalities and conjunction. It:

1. synthesizes a sound pruning rule on 0/1 knapsack using CEGIS;
2. compiles the verified rule into Pareto-frontier pruning;
3. transfers only the relational shape to resource-constrained shortest path;
4. deliberately applies it to a bonus-knapsack domain where it is unsound;
5. uses the verifier counterexample to specialize the rule's applicability.

Run:

```bash
make reproduce
```

`results.json` contains all measurements and traces; `REPORT.md` is generated from them.
