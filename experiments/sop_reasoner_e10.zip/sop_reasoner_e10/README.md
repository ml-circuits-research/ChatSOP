# SOP Verified Reasoner — SOP-R1 / E10

An executable, function-free relational reasoner in Node.js ES modules. It reads SOP-style fact, rule and query wires, computes exact **sets of answers**, retains optional derivation witnesses and learns reusable execution plans and can consolidate verified reasoning lemmas offline without letting predictions decide truth.

**Start with [REPORT.md](REPORT.md), [syntax](docs/SYNTAX.md), [architecture](docs/ARCHITECTURE.md), and [cumulative history](docs/RESEARCH_LOG.md).** This is a research prototype, not a claim to outperform mature Prolog/Datalog implementations universally.

## Run

Node.js 22.16 or later was tested. No `npm install` and no runtime packages are required. The optional independent SQLite benchmark uses Node's built-in `node:sqlite`; that module emits an experimental warning in the tested Node version.

```sh
node bin/sop.mjs examples/reachability.sop --query answer --explain
node bin/sop.mjs examples/wires.sop --query answer
node bin/sop.mjs examples/pareto.sop --query q --dominance --explain
node examples/learn-and-reuse.mjs
node tools/dream-demo.mjs
make sop-regression
make e10
make test
make reproduce
make verify-clean
```

`npm test` and `npm run reproduce` are equivalent entry points. `make reproduce` runs the current Node tests, archive integrity checks, 20 SOP-native property regressions, the verified dreaming demo, all 14 main workload families, policy learning, the neural ranking control, the 100k/1M-fact experiments, and the E10 106,800-fact multi-domain transfer benchmark. Allow approximately 2 GB RAM for the largest case. Observed timings and hardware are in `results/environment.json` and `results/REPRODUCTION.json`; they are not hardware-independent promises.

For constrained runners, every release phase can also be executed independently, for example `node tools/reproduce.mjs --phase e10` or `node tools/reproduce.mjs --phase benchmark`. This delivery was clean-verified phase-by-phase because the hosted runner throttled a long chain of CPU-heavy child processes; see `VERIFICATION.md`. The phase commands execute the same code used by `make reproduce`.

## A recursive SOP program

```text
@facts facts
FACT edge alpha beta
FACT edge beta gamma

@direct rule
WHEN edge ?from ?to
THEN reaches ?from ?to

@transitive rule
WHEN reaches ?from ?middle
AND edge ?middle ?to
THEN reaches ?from ?to

@answer query
GIVES ?destination
MATCH reaches alpha ?destination
```

The answers are `beta` and `gamma`. `@name` defines a wire, `$name` references a binding relation, and `?name` is a logical variable. Facts/rules/queries have line-oriented syntax without term parentheses or argument commas. The implemented profile is explicitly specified here; it does not claim to implement every prior SOP Lang construct.

## What is implemented

The kernel provides least-fixed-point evaluation, positive and mutual recursion, stratified `NONE`, explicit `NOT`, typed constants, ALL/ANY wires, comparisons, SCC scheduling, indexed joins and seminaive deltas. Optimizations include query-demand specialization, independent existential-component elimination, safe nonrecursive rule inlining, learned join permutations and a guarded Pareto compiler. Results distinguish `COMPLETE` from `INCOMPLETE`; exceeding a budget is never interpreted as a negative answer.

The learning layer includes empirical program/plan selection, a small all-`.mjs` neural cost ranker, and an offline dreaming layer. The first integrated dreamer can derive redundant Horn shortcut lemmas by constructive rule composition, verify them against the current schema, replay them exactly, and promote only useful candidates. The ranker is only a proposal mechanism. On the included selection test it ties a simple cardinality heuristic; no claim that the network is necessary is made.

## Online reasoning, offline dreaming, and composition

Use verified deployment plans during ordinary tasks; do not make each query rediscover algorithms. `AdaptiveReasoner` journals episodes. `Dreamer` can later batch replayable episodes and ask multiple inventors for candidate skills. `VerifiedSkillStore` preserves trusted and advisory artifacts separately, while `SkillComposer` replay-tests subsets before promoting a task-specific deployment. See [E10 unified Dreamer](docs/E10_UNIFIED_DREAMER.md), [dreaming lifecycle](docs/DREAMING_AND_CONSOLIDATION.md) and [experiment design](docs/EXPERIMENT_DESIGN.md).

E10 adds a unified inventor interface. Verified Horn lemmas, local existential quotient, independent-component decomposition, guarded Pareto compilation and demand specialization can all enter the same persistent skill lifecycle. Empirical invariants are retained as advisory-only hypotheses. General L* quotient discovery, arbitrary dominance synthesis and feature/invariant grammar expansion remain historical targets rather than being mislabelled as fully integrated.

## Use as a library

```js
import { loadSOP, Session, explain, verifyExplanation } from './src/index.mjs';
const program = await loadSOP('examples/reachability.sop');
const session = new Session(program);
const result = session.query('answer', { provenance: true });
if (result.complete && result.count > 0) {
  const evidence = explain(result, 0);
  console.log(verifyExplanation(program, result, evidence));
}
console.log(result.rows, result.snapshot, result.stats);
```

`SOPReasonerInterpreter` accepts typed input fact wires and returns output bindings, status, snapshot, plan metadata and optional checked evidence. See [API](docs/API.md) and [integration](docs/SOP_INTEGRATION.md).

## Package map

| Path | Contents |
|---|---|
| `src/`, `bin/` | Runtime, parser, optimizers, learning, unified inventors, skill composer, verified lemma synthesis, dreaming/store, adapters and CLI; all `.mjs` |
| `tests/` | Current semantic, differential, guard, proof, update, ML, dreaming and SQLite tests |
| `bench/`, `data/` | Deterministic generators, frozen SOP datasets, independent oracles and protocols |
| `results/` | Actual measurements, trained profiles/models, logs and deterministic fingerprints |
| `regression/cases/` | 20 executable SOP programs that double as scientific property regressions |
| `docs/` | Syntax, contracts, dreaming/consolidation, evidence map, reasoning, limitations, experiment history and integration design |
| `history/records/` | Readable copies of prior reports, results and decisions |
| `history/E00-E07-original-master.zip` | Original historical source archive, unchanged |

## Historical compatibility, precisely

**All current runtime, tests, benchmark generators and reproduction tools are `.mjs`.** The read-only historical archive still contains the original Python experiments. They were retained, not falsely renamed or advertised as Node ports. During this delivery all **79 original unit tests** were rerun successfully in an extracted copy; the original 15 saved-capability assertions also passed. The log is included.

The default Node reproduction checks the archive hash and 15 historical result records, but does **not** rerun the archived Python training procedures. No old capability has been deleted from the preserved source. Not every old capability is integrated into the new relational runtime: the [capability matrix](docs/CAPABILITIES.md) names those boundaries explicitly.

## Scope

This is set-valued, finite Datalog-like reasoning, not full Prolog. It has no cut, arbitrary term constructors, external side effects, unrestricted arithmetic generation, probabilistic reasoning, proof-path counting, automatic natural-language extraction or general theorem proving. Updates use snapshot invalidation and recomputation, not incremental deletion maintenance. Synthetic success is evidence for this implementation and workload family, not for open-ended algorithm invention or real-world semantic correctness.

## Release integrity

`make integrity` verifies the shipped source/data/results against `RELEASE_MANIFEST.json`. Reproduction intentionally changes timing logs, so perform this check before regenerating measurements. The receipt is an integrity check, not a signed trust guarantee. `make verify-clean` validates newly regenerated semantic results independently of timing equality.

Detailed workload definitions and comparator limitations are in [BENCHMARK_PROTOCOL.md](docs/BENCHMARK_PROTOCOL.md).
