# SOP Verified Reasoner — raport E10

**Verdict:** E10 păstrează reasoner-ul exact E08/E09 și integrează un Dreamer unificat cu inventors separați, quotient verificat, skill composition și transfer din lumi SOP mici într-un environment comun de **106,800 fapte**. ML/euristicile pot propune ce merită încercat; numai verificarea exactă poate schimba execuția. Invariant-urile empirice rămân advisory-only.

## E10: dreaming unificat și transfer

Skill-urile sunt învățate numai pe lumi mici cu aceeași schemă, apoi înghețate și reutilizate pe lumea mare; nu are loc reînvățare pe benchmark-ul mare.

| Query | Răspunsuri exacte | Baseline | Probes baseline | Deployment | Probes deployment | Runde | Skill-uri deployate |
|---|---:|---|---:|---|---:|---:|---|
| reach | 40 | INCOMPLETE | 300001 | COMPLETE | 167 | 43 | demand |
| visible | 1 | COMPLETE | 25002 | COMPLETE | 3 | 2 | quotient |
| eligible | 500 | COMPLETE | 251000 | COMPLETE | 1001 | 2 | factor |
| pareto | 900 | COMPLETE | 1623600 | COMPLETE | 2700 | 1 | dominance |

Baseline-ul reachability este oprit explicit la buget și este raportat **INCOMPLETE**, nu fals. Celelalte trei baseline-uri termină și produc același answer-set. Costurile de parsing/indexare nu sunt echivalente cu candidateVisits și sunt păstrate separat în rezultate.

În biblioteca E10: **14/18** records au fost promovate, dintre care **4** deployment plans. Sunt păstrate **6** invariants empirice ca ipoteze advisory; acestea nu sunt transformate în filtre/pruning.

### Ce a fost integrat

- LemmaInventor / E09: leme Horn redundante cu certificat constructiv; pot fi păstrate chiar dacă un composer nu le alege pentru un obiectiv concret.
- QuotientInventor: elimină coordonate existențiale locale care nu pot influența continuarea sau output-ul; are certificat sintactic și replay exact.
- DecompositionInventor: recunoaște componente existențiale independente și activează factorization.
- DominanceInventor: recunoaște numai template-ul Pareto complet gardat deja certificat de kernel.
- RepresentationInventor: propune query-demand specialization.
- InvariantInventor: descoperă regularități empirice, dar scope-ul lor este advisory-only; nu au voie să dovedească sau să taie ramuri.
- SkillComposer: enumeră subseturi de skill-uri deja certificate, rerulează exact task-urile și promovează deployment-ul cu scor minim pentru obiectivul declarat. Un skill promovat nu este activat automat peste tot.

## Non-regression

- Node tests: **202/202 PASS**.
- SOP-native scientific regressions: **20/20 PASS**.
- Historical evidence audit: **15/15 PASS**.
- E09 lemma demo rămâne exact: fixpoint rounds **96 → 3**; probes **9310 → 14057**.

Testele SOP E15–E20 transformă în contract permanent quotient-ul, discovery-ul quotient/decomposition/dominance, separarea invariantelor advisory și compunerea skill-urilor. Cazurile negative anterioare — budget→INCOMPLETE, Pareto nesound respins, negative recursion respins etc. — rămân active.

## Baseline reasoner E08/E09 păstrat

Față de baseline-ul greedy_semi (care are deja indexare, seminaive evaluation și greedy joins), politica adaptivă istorică păstrează următoarele reduceri de tuple probes:

| Familie | Greedy | Adaptiv | Reducere |
|---|---:|---:|---:|
| Reachability localizată | 9091 | 60 | 151.52× |
| Recursie adâncă | 102718 | 1283 | 80.06× |
| Join selectiv | 179 | 179 | 1.00× |
| Existențial independent | 360600 | 601 | 600.00× |
| Pareto | 1218800 | 6600 | 184.67× |

Main benchmark: **220** rulări COMPLETE corecte, **23** INCOMPLETE explicite, zero răspunsuri greșite între rulările COMPLETE. SQLite rămâne control independent pe familiile suportate.

## Limite

E10 nu demonstrează încă open-ended algorithm invention. Quotient-ul este nou integrat în runtime; decomposition, demand și Pareto sunt transformări cunoscute pe care Dreamer-ul le poate descoperi/compune. Feature/invariant invention și representation-language expansion din E06/E07 sunt păstrate în istorie și regresii de evidență, dar nu sunt încă portate ca transformări generale ale kernelului SOP. Invariant-urile E10 sunt deliberate ipoteze observate, nu teoreme.

## Reproducere

Node v22.16.0; AMD EPYC 9V74 80-Core Processor. Reproduction mode: phase-by-phase; total measured wall time: reported per phase / not aggregated. Fingerprint semantic: `f952f65baf286a46ed3bd539fea53a35bdb911359751663d5b031af6158e4d0a`. Vezi RESULTS.md, VERIFICATION.md, docs/E10_UNIFIED_DREAMER.md și docs/EXPERIMENT_DESIGN.md.
