import {schemaHash,sliceRules,digest} from './analyze.mjs';
import {Database} from './database.mjs';
import {quotientOpportunities,factorOpportunities} from './join.mjs';
import {recognizeDominance} from './dominance.mjs';
import {magicTransform} from './magic.mjs';
import {reason} from './engine.mjs';
import {reference} from './reference.mjs';
import {synthesizeCompositionLemmas,makeLemmaBundle} from './lemmas.mjs';

const rowsKey=rows=>JSON.stringify(rows);
const queryGoal=(program,query)=>{const q=program.queries.find(x=>x.name===query);if(!q)throw new Error(`Unknown query ${query}`);return q.pred;};
const candidate=(family,program,query,settings,certificate,extra={})=>({kind:'execution-fragment',family,schema:schemaHash(program),query,artifact:{settings},certificate,semanticContract:'exact answer-set preservation',...extra});

/** Syntactic quotient inventor: finds existential coordinates inside an otherwise live literal. */
export class QuotientInventor {
  constructor(){this.name='quotient';}
  propose(programs,query){const p=programs[0],rules=sliceRules(p.rules,queryGoal(p,query)),ops=quotientOpportunities(rules);if(!ops.length)return [];
    return [candidate(this.name,p,query,{quotient:true},{kind:'existential-variable-quotient-v1',opportunities:ops,proof:'variables eliminated from a literal occur nowhere else in rule or head'})];}
}

/** Existing exact factorization is exposed as an inventable deployment skill. */
export class DecompositionInventor {
  constructor(){this.name='decomposition';}
  propose(programs,query){const p=programs[0],rules=sliceRules(p.rules,queryGoal(p,query)),ops=factorOpportunities(rules);if(!ops.length)return [];
    return [candidate(this.name,p,query,{factor:true},{kind:'independent-existential-component-v1',opportunities:ops,proof:'component shares no variable with rule head/live components'})];}
}

/** Recognizes the fully guarded Pareto template already supported by the kernel. */
export class DominanceInventor {
  constructor(){this.name='dominance';}
  propose(programs,query){const p=programs[0],goal=queryGoal(p,query),rules=sliceRules(p.rules,goal),db=Database.fromProgram(p);const plan=recognizeDominance(rules,goal,db);if(!plan)return [];
    return [candidate(this.name,p,query,{dominance:true},plan.certificate,{artifact:{settings:{dominance:true},recognized:{source:plan.source,group:plan.group,metrics:plan.metrics,direction:plan.direction}}})];}
}

/** Demand specialization changes representation of the query slice, not its semantics. */
export class RepresentationInventor {
  constructor(){this.name='demand-specialization';}
  propose(programs,query){const p=programs[0],goal=queryGoal(p,query),rules=sliceRules(p.rules,goal),m=magicTransform(rules,goal,p.arities);if(!m.applied)return [];
    return [candidate(this.name,p,query,{demand:true},m.certificate||{kind:'query-demand-specialization-v1'})];}
}

/**
 * Empirical invariants are useful hypotheses for later feature invention, but they are
 * never deployed as pruning rules. Version 1 discovers unary functional dependencies
 * in extensional relations and requires them to hold in every replay program.
 */
export class InvariantInventor {
  constructor({maxFacts=100_000}={}){this.name='observed-invariant';this.maxFacts=maxFacts;}
  propose(programs,query){const p=programs[0],schema=schemaHash(p),byPred=new Map();
    for(const x of programs){for(const f of x.facts){if(!byPred.has(f.pred))byPred.set(f.pred,[]);byPred.get(f.pred).push(f.terms);}}
    const out=[];
    for(const [pred,rows] of byPred){if(!rows.length||rows.length>this.maxFacts||rows[0].length<2)continue;const arity=rows[0].length;
      for(let a=0;a<arity;a++)for(let b=0;b<arity;b++){if(a===b)continue;const map=new Map();let ok=true;for(const row of rows){const k=JSON.stringify(row[a]),v=JSON.stringify(row[b]);if(map.has(k)&&map.get(k)!==v){ok=false;break;}map.set(k,v);}if(ok&&map.size>=4)out.push({kind:'observed-invariant',family:'functional-dependency',schema,query,status:'candidate',scope:'advisory-only',semanticContract:'empirical observation; MUST NOT prune or prove',artifact:{pred,determinant:[a],dependent:b,distinctKeys:map.size},certificate:{kind:'replay-functional-dependency-v1',programs:programs.length,rows:rows.length,digest:digest([...map])}});}
    }
    return out.slice(0,16);
  }
}

/** Wrapper exposing the E09 verified Horn composition mechanism through the same interface. */
export class LemmaInventor {
  constructor({maxCandidates=64}={}){this.name='lemma';this.maxCandidates=maxCandidates;}
  propose(programs,query){const p=programs[0];return synthesizeCompositionLemmas(p,query,{maxCandidates:this.maxCandidates}).map(s=>({kind:'lemma-candidate',family:'lemma',schema:schemaHash(p),query,artifact:makeLemmaBundle(p,query,[s]),certificate:s.certificate,semanticContract:'redundant Horn consequence'}));}
}

export const DEFAULT_INVENTORS=()=>[new QuotientInventor(),new DecompositionInventor(),new DominanceInventor(),new RepresentationInventor(),new InvariantInventor()];

export function verifyReplayCandidate(programs,query,candidate,{maxWork=5_000_000,roundWeight=32,baselineOptions={demand:false,factor:false,quotient:false,fuse:false,dominance:false}}={}){
  if(candidate.kind==='observed-invariant'){const {pred,determinant=[0],dependent}=candidate.artifact;let rows=0;for(const p of programs){const map=new Map();for(const f of p.facts.filter(x=>x.pred===pred)){rows++;const k=JSON.stringify(determinant.map(i=>f.terms[i])),v=JSON.stringify(f.terms[dependent]);if(map.has(k)&&map.get(k)!==v)return {valid:false,advisory:true,exactReplay:false,reason:'HELDOUT_COUNTEREXAMPLE',rows};map.set(k,v);}}return {valid:true,advisory:true,exactReplay:true,rows,baselineCost:null,skillCost:null,gain:null};}
  const settings=candidate.kind==='lemma-candidate'?{lemmaBundle:candidate.artifact}:{...(candidate.artifact?.settings||{})};
  let exact=true,baselineCost=0,skillCost=0,complete=true;
  for(const p of programs){const oracle=reference(p,query),base=reason(p,query,{...baselineOptions,maxWork}),skill=reason(p,query,{...baselineOptions,...settings,maxWork});
    exact&&=skill.complete&&rowsKey(skill.rows)===rowsKey(oracle.rows);complete&&=base.complete&&skill.complete;
    baselineCost+=base.stats.candidateVisits+roundWeight*base.stats.rounds;skillCost+=skill.stats.candidateVisits+roundWeight*skill.stats.rounds;
  }
  return {valid:exact&&complete,exactReplay:exact,complete,baselineCost,skillCost,gain:baselineCost?1-skillCost/baselineCost:0,settings};
}

function mergeBundles(records,schema,query){const skills=[];for(const r of records)if(r.kind==='lemma-bundle')skills.push(...(r.artifact.skills||[]));return skills.length?{kind:'verified-lemma-bundle-v1',version:1,schema,query,skills}:null;}
function settingsFor(records,schema,query){const settings={};for(const r of records){if(r.kind==='execution-fragment')Object.assign(settings,r.artifact.settings||{});else if(r.kind==='execution-policy')settings.policy=r.artifact;else if(r.kind==='join-plan')settings.bundle=r.artifact;}
  const lemmaBundle=mergeBundles(records,schema,query);if(lemmaBundle)settings.lemmaBundle=lemmaBundle;return settings;}
function subsets(records,maxCombos=256){const out=[[]];for(const r of records){const current=out.slice();for(const s of current){if(out.length>=maxCombos)break;out.push([...s,r]);}if(out.length>=maxCombos)break;}return out;}

/**
 * Compose already-certified skills. Correctness is rechecked on exact replay for every
 * candidate subset. The composer optimizes a declared objective; a promoted skill is
 * not automatically deployed merely because it is individually useful.
 */
export class SkillComposer {
  constructor({store,roundWeight=32,maxCombos=256}={}){if(!store)throw new Error('SkillComposer requires store');Object.assign(this,{store,roundWeight,maxCombos});}
  compose(programs,query,{maxWork=5_000_000,baselineOptions={demand:false,factor:false,quotient:false,fuse:false,dominance:false},promote=true}={}){
    if(!programs.length)throw new Error('No replay programs');const schema=schemaHash(programs[0]);if(programs.some(p=>schemaHash(p)!==schema))throw new Error('Replay schemas differ');
    const eligible=this.store.records.filter(r=>r.status==='promoted'&&r.schema===schema&&r.query===query&&['execution-fragment','execution-policy','join-plan','lemma-bundle'].includes(r.kind));
    const trace=[];let best=null;
    for(const subset of subsets(eligible,this.maxCombos)){const settings=settingsFor(subset,schema,query);let exact=true,score=0,work=0,rounds=0;
      for(const p of programs){const oracle=reference(p,query),r=reason(p,query,{...baselineOptions,...settings,maxWork});exact&&=r.complete&&rowsKey(r.rows)===rowsKey(oracle.rows);work+=r.stats.candidateVisits;rounds+=r.stats.rounds;score+=r.stats.candidateVisits+this.roundWeight*r.stats.rounds;}
      const row={members:subset.map(r=>r.id),families:subset.map(r=>r.kind==='execution-fragment'?r.artifact.family||r.family:r.kind),exact,score,work,rounds,settings};trace.push(row);if(exact&&(!best||score<best.score||score===best.score&&subset.length<best.members.length))best=row;
    }
    if(!best)throw new Error('No exact deployment subset');
    let record=null;if(promote){record=this.store.add({kind:'deployment-plan',schema,query,artifact:{kind:'verified-skill-deployment-v1',settings:best.settings,members:best.members,objective:`candidateVisits+${this.roundWeight}*rounds`},evidence:{exactReplay:true,trace}});this.store.setStatus(record.id,'promoted','best exact composition on replay objective');}
    return {kind:'skill-composition-report-v1',schema,query,eligible:eligible.length,best,trace,recordId:record?.id||null};
  }
}
