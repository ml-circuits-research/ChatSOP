import {Database} from './database.mjs';
import {reason} from './engine.mjs';
import {schemaHash} from './analyze.mjs';
import {permutations,verifyPlanBundle} from './skills.mjs';

/** Empirical algorithm/plan synthesis, trained only on caller-provided training instances.
 * It is intentionally labelled symbolic autotuning, not neural algorithm invention.
 * Objective is integer tuple probes, not unstable sub-millisecond timings.
 */
export function learnPlans(programs,queryName,{maxLiterals=4,maxCandidates=96,maxWork=5_000_000}={}){
  if(!programs.length)throw new Error('No training programs');const schema=schemaHash(programs[0]);
  if(programs.some(p=>schemaHash(p)!==schema))throw new Error('Training schemas must match');
  const plans={},trace=[];
  for(const rule of programs[0].rules){
    if(rule.body.length<2||rule.body.length>maxLiterals||rule.body.some(l=>l.kind!=='atom'))continue;
    let best=Infinity,bestOrder=null,tried=0;
    for(const order of permutations(rule.body.map((_,i)=>i))){if(tried++>=maxCandidates)break;let cost=0,complete=true;
      for(const program of programs){const r=reason(program,queryName,{demand:false,factor:false,join:'source',plans:{...plans,[rule.id]:order},maxWork,provenance:false});
        if(!r.complete){complete=false;cost+=maxWork*2;}else cost+=r.stats.candidateVisits;
      }
      trace.push({rule:rule.id,order,cost,complete});if(complete&&cost<best){best=cost;bestOrder=order;}
    }
    if(bestOrder)plans[rule.id]=bestOrder;
  }
  const bundle={version:1,kind:'empirical-join-plan-v1',schema,plans,trainingPrograms:programs.length,objective:'candidateVisits',trace};
  if(!verifyPlanBundle(programs[0],bundle).valid)throw new Error('Internal plan verification failed');return bundle;
}

/** A tiny CPU neural proposal model. Output affects ranking only. Not used as a truth oracle. */
export class Ranker {
  constructor(input,hidden=12,seed=1){this.input=input;this.hidden=hidden;let s=seed>>>0;const rand=()=>{s=(1664525*s+1013904223)>>>0;return s/4294967296;};
    this.w1=Array.from({length:hidden},()=>Array.from({length:input},()=> (rand()-.5)*.15));this.b1=Array(hidden).fill(0);this.w2=Array.from({length:hidden},()=> (rand()-.5)*.15);this.b2=0;
  }
  forward(x){const h=this.w1.map((w,j)=>Math.tanh(w.reduce((v,a,i)=>v+a*x[i],this.b1[j])));return {h,y:h.reduce((v,a,j)=>v+a*this.w2[j],this.b2)};}
  fit(samples,{epochs=250,lr=.015}={}){
    for(let e=0;e<epochs;e++)for(const {x,y}of samples){const p=this.forward(x),g=Math.max(-5,Math.min(5,p.y-y));
      for(let j=0;j<this.hidden;j++){const dh=g*this.w2[j]*(1-p.h[j]*p.h[j]);for(let i=0;i<this.input;i++)this.w1[j][i]-=lr*dh*x[i];this.b1[j]-=lr*dh;this.w2[j]-=lr*g*p.h[j];}this.b2-=lr*g;
    }return this;
  }
  predict(x){return this.forward(x).y;}
  static fromJSON(j){const r=new Ranker(j.input,j.hidden);Object.assign(r,j);return r;}
}

export const POLICY_CANDIDATES=Object.freeze([false,true].flatMap(demand=>[false,true].flatMap(factor=>[false,true].flatMap(quotient=>[false,true].flatMap(fuse=>[false,true].map(dominance=>({demand,factor,quotient,fuse,dominance,join:'greedy'})))))));
export function learnExecutionPolicy(programs,query,{maxWork=1_000_000}={}){
  if(!programs.length)throw new Error('No training instances');const schema=schemaHash(programs[0]);
  if(programs.some(p=>schemaHash(p)!==schema))throw new Error('Training schema mismatch');
  const trace=[];const started=performance.now();
  for(let id=0;id<POLICY_CANDIDATES.length;id++){
    let work=0,complete=true;
    for(const p of programs){const r=reason(p,query,{...POLICY_CANDIDATES[id],maxWork});work+=r.stats.candidateVisits;if(!r.complete)complete=false;}
    trace.push({id,work,complete});
  }
  trace.sort((a,b)=>Number(b.complete)-Number(a.complete)||a.work-b.work||a.id-b.id);
  if(!trace[0].complete)throw new Error('No policy completed within training budget');
  return {kind:'verified-policy-selection-v1',schema,query,options:POLICY_CANDIDATES[trace[0].id],trainingOnly:true,trainingPrograms:programs.length,trainMs:performance.now()-started,trace};
}
