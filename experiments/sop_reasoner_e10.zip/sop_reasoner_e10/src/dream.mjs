import {schemaHash,digest} from './analyze.mjs';
import {reason,publicResult} from './engine.mjs';
import {reference} from './reference.mjs';
import {learnExecutionPolicy,learnPlans} from './learn.mjs';
import {verifyExecutionPolicy,verifyPlanBundle} from './skills.mjs';
import {synthesizeCompositionLemmas,makeLemmaBundle,verifyLemmaBundle} from './lemmas.mjs';
import {DEFAULT_INVENTORS,verifyReplayCandidate,SkillComposer} from './inventors.mjs';

const rowsKey=rows=>JSON.stringify(rows);
const score=(r,roundWeight=32)=>r.stats.candidateVisits+roundWeight*r.stats.rounds;

/** Episodes are evidence for later consolidation. They are not themselves skills.
 * Small programs can be captured for exact replay; large tasks normally store only
 * fingerprints/metrics and should be replayed from their source dataset.
 */
export class EpisodeJournal {
  constructor({capturePrograms=true,maxFacts=10000}={}){this.capturePrograms=capturePrograms;this.maxFacts=maxFacts;this.entries=[];this.serial=0;}
  record(program,query,result,options={},meta={}){
    const replayable=this.capturePrograms&&program.facts.length<=this.maxFacts;
    const entry={episode:++this.serial,schema:schemaHash(program),data:digest(program.facts),query,status:result.status,count:result.count,
      cost:{candidateVisits:result.stats.candidateVisits,rounds:result.stats.rounds,derived:result.stats.derived,totalMs:result.stats.totalMs},
      options:{demand:options.demand,factor:options.factor,fuse:options.fuse,dominance:options.dominance,join:options.join,mode:options.mode},meta:structuredClone(meta),
      program:replayable?structuredClone(program):null};this.entries.push(entry);return entry;
  }
  replayableGroups({minEpisodes=2}={}){const groups=new Map();for(const e of this.entries)if(e.program){const k=`${e.schema}:${e.query}`;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(e);}return [...groups.values()].filter(g=>g.length>=minEpisodes);}
  toJSON(){return {version:1,entries:this.entries};}
  static fromJSON(j){const x=new EpisodeJournal();x.entries=structuredClone(j.entries||[]);x.serial=x.entries.reduce((m,e)=>Math.max(m,e.episode||0),0);return x;}
}

/** Persistent lifecycle store. Only PROMOTED records are deployed by default. */
export class VerifiedSkillStore {
  constructor(records=[]){this.records=records.map(r=>structuredClone(r));this.serial=this.records.reduce((m,r)=>Math.max(m,r.serial||0),0);}
  add({kind,family=null,schema,query,artifact,status='candidate',evidence={},semanticContract='exact answer-set preservation',scope='schema-local'}){
    const record={serial:++this.serial,id:`skill-${this.serial}-${digest({kind,family,schema,query,artifact}).slice(0,10)}`,kind,family,schema,query,status,scope,semanticContract,artifact:structuredClone(artifact),evidence:structuredClone(evidence),history:[{event:'created',status}]};this.records.push(record);return record;
  }
  setStatus(id,status,note=''){const r=this.records.find(x=>x.id===id);if(!r)throw new Error('Unknown skill');r.status=status;r.history.push({event:'status',status,note});return r;}
  promoted(program,query){const schema=schemaHash(program),matching=this.records.filter(r=>r.status==='promoted'&&r.schema===schema&&r.query===query);const deployment=matching.filter(r=>r.kind==='deployment-plan').at(-1);if(deployment)return structuredClone(deployment.artifact.settings||{});const out={};for(const r of matching){if(r.kind==='execution-policy')out.policy=structuredClone(r.artifact);if(r.kind==='join-plan')out.bundle=structuredClone(r.artifact);if(r.kind==='lemma-bundle')out.lemmaBundle=structuredClone(r.artifact);if(r.kind==='execution-fragment')Object.assign(out,structuredClone(r.artifact.settings||{}));}return out;}
  advisories(program,query){const schema=schemaHash(program);return this.records.filter(r=>r.status==='promoted'&&r.schema===schema&&r.query===query&&r.scope==='advisory-only').map(r=>structuredClone(r));}
  candidates(){return this.records.filter(r=>r.status==='candidate').map(r=>structuredClone(r));}
  toJSON(){return {version:1,records:this.records};}
  static fromJSON(j){return new VerifiedSkillStore(j.records||[]);}
}

function exactOn(program,query,settings){const r=reason(program,query,settings),oracle=reference(program,query);return {result:r,exact:r.complete&&rowsKey(r.rows)===rowsKey(oracle.rows)};}
function splitPrograms(programs){if(programs.length<3)return {train:programs,holdout:programs};const cut=Math.max(1,Math.floor(programs.length*2/3));return {train:programs.slice(0,cut),holdout:programs.slice(cut)};}

/** Offline consolidation. It may be triggered after a task batch or during an idle
 * "dreaming" phase. It never promotes a candidate solely because ML/heuristics like it:
 * candidates must pass exact replay, certificate checks and held-out cost tests.
 */
export class Dreamer {
  constructor({store=new VerifiedSkillStore(),roundWeight=32,minGain=.03,maxLemmaCandidates=64,maxPromotedLemmas=2}={}){Object.assign(this,{store,roundWeight,minGain,maxLemmaCandidates,maxPromotedLemmas});}
  consolidate(programs,query,{learnPolicy=true,learnJoins=true,learnLemmas=true,learnInventors=false,inventors=null,compose=false,maxWork=5_000_000,baselineOptions={demand:false,factor:false,quotient:false,fuse:false,dominance:false}}={}){
    if(!programs.length)throw new Error('No replay programs');const schema=schemaHash(programs[0]);if(programs.some(p=>schemaHash(p)!==schema))throw new Error('Replay schemas differ');
    const {train,holdout}=splitPrograms(programs),report={kind:'dream-report-v1',schema,query,train:train.length,holdout:holdout.length,candidates:[],promoted:[],rejected:[]};
    for(const p of programs){const x=exactOn(p,query,{maxWork,demand:false});if(!x.exact)throw new Error('Dreaming requires exact replayable training cases');}
    let policy=null,bundle=null;
    if(learnPolicy){policy=learnExecutionPolicy(train,query,{maxWork});const v=verifyExecutionPolicy(programs[0],query,policy);let exact=true,base=0,cost=0;for(const p of holdout){const a=exactOn(p,query,{maxWork,demand:false}),b=exactOn(p,query,{maxWork,policy});exact&&=b.exact;base+=score(a.result,this.roundWeight);cost+=score(b.result,this.roundWeight);}const rec=this.store.add({kind:'execution-policy',schema,query,artifact:policy,evidence:{certificate:v,holdoutExact:exact,baselineCost:base,skillCost:cost}});if(v.valid&&exact){this.store.setStatus(rec.id,'promoted','exact held-out replay');report.promoted.push(rec.id);}else{this.store.setStatus(rec.id,'rejected','verification/replay failure');report.rejected.push(rec.id);}}
    if(learnJoins){bundle=learnPlans(train,query,{maxWork});const v=verifyPlanBundle(programs[0],bundle);let exact=true,base=0,cost=0;for(const p of holdout){const baseSettings=policy?{policy,maxWork}:{maxWork,demand:false};const a=exactOn(p,query,baseSettings),b=exactOn(p,query,{...baseSettings,bundle});exact&&=b.exact;base+=score(a.result,this.roundWeight);cost+=score(b.result,this.roundWeight);}const rec=this.store.add({kind:'join-plan',schema,query,artifact:bundle,evidence:{certificate:v,holdoutExact:exact,baselineCost:base,skillCost:cost}});if(v.valid&&exact&&cost<=base*(1+this.minGain)){this.store.setStatus(rec.id,'promoted','safe plan; no material held-out regression');report.promoted.push(rec.id);}else{this.store.setStatus(rec.id,'rejected','verification or held-out regression');report.rejected.push(rec.id);}}
    if(learnLemmas){const candidates=synthesizeCompositionLemmas(programs[0],query,{maxCandidates:this.maxLemmaCandidates});let promoted=0;for(const candidate of candidates){if(promoted>=this.maxPromotedLemmas)break;const lemmaBundle=makeLemmaBundle(programs[0],query,[candidate]);const vv=verifyLemmaBundle(programs[0],lemmaBundle,query);let exact=true,base=0,cost=0;
        for(const p of programs){const settings={maxWork,demand:false};const a=exactOn(p,query,settings),b=exactOn(p,query,{...settings,lemmaBundle});exact&&=b.exact;base+=score(a.result,this.roundWeight);cost+=score(b.result,this.roundWeight);}
        const gain=base?1-cost/base:0;report.candidates.push({kind:'lemma',rule:candidate.rule.id,gain,base,cost,exact});const rec=this.store.add({kind:'lemma-bundle',family:'lemma',schema,query,artifact:lemmaBundle,evidence:{certificate:vv.certificate,exactReplay:exact,baselineCost:base,skillCost:cost,gain,objective:`candidateVisits+${this.roundWeight}*rounds`}});
        if(vv.valid&&exact&&gain>=this.minGain){this.store.setStatus(rec.id,'promoted',`verified replay gain ${(gain*100).toFixed(2)}%`);report.promoted.push(rec.id);promoted++;}else{this.store.setStatus(rec.id,'rejected',exact?'insufficient cost gain':'semantic mismatch');report.rejected.push(rec.id);}
      }}
    if(learnInventors){const list=inventors||DEFAULT_INVENTORS();for(const inventor of list){const proposals=inventor.propose(train,query)||[];for(const candidate of proposals){const verification=verifyReplayCandidate(holdout,query,candidate,{maxWork,roundWeight:this.roundWeight,baselineOptions});const rec=this.store.add({kind:candidate.kind,family:candidate.family||inventor.name,schema,query,artifact:candidate.artifact,evidence:{certificate:candidate.certificate,verification},semanticContract:candidate.semanticContract||'exact answer-set preservation',scope:candidate.scope||'schema-local'});report.candidates.push({kind:candidate.kind,family:candidate.family||inventor.name,verification});
          if(candidate.kind==='observed-invariant'){if(verification.valid){this.store.setStatus(rec.id,'promoted','held-out observation retained as advisory only');report.promoted.push(rec.id);}else{this.store.setStatus(rec.id,'rejected','held-out counterexample');report.rejected.push(rec.id);}continue;}
          if(verification.valid&&(verification.gain??0)>=this.minGain){this.store.setStatus(rec.id,'promoted',`verified held-out gain ${((verification.gain||0)*100).toFixed(2)}%`);report.promoted.push(rec.id);}else{this.store.setStatus(rec.id,'rejected',verification.valid?'insufficient held-out gain':'semantic/replay failure');report.rejected.push(rec.id);}
        }}}
    if(compose){const composer=new SkillComposer({store:this.store,roundWeight:this.roundWeight});report.composition=composer.compose(programs,query,{maxWork,baselineOptions});if(report.composition.recordId)report.promoted.push(report.composition.recordId);}
    return report;
  }
  consolidateJournal(journal,opts={}){const reports=[];for(const group of journal.replayableGroups(opts)){reports.push(this.consolidate(group.map(e=>e.program),group[0].query,opts));}return reports;}
}

/** Online facade: only promoted, schema-compatible artifacts influence execution;
 * every completed/failed episode can later seed offline consolidation.
 */
export class AdaptiveReasoner {
  constructor({store=new VerifiedSkillStore(),journal=new EpisodeJournal()}={}){this.store=store;this.journal=journal;this.dreamer=new Dreamer({store});}
  run(program,query,options={},meta={}){const skills=this.store.promoted(program,query),settings={...skills,...options};const r=reason(program,query,settings);this.journal.record(program,query,r,settings,meta);return r;}
  dream(options={}){return this.dreamer.consolidateJournal(this.journal,options);}
}
