import {parseSOP,validateProgram} from './parser.mjs';import {Session} from './session.mjs';import {publicResult} from './engine.mjs';import {explain,verifyExplanation} from './proof.mjs';

/** Adapter boundary for a SOP interpreter. Caller-provided facts remain explicit
 * premises; neither extraction accuracy nor external truth is claimed here. */
export class SOPReasonerInterpreter {
  constructor(ruleText,{factWires=[],source='sop://reasoning-module'}={}){
    const program=parseSOP(ruleText,source);
    for(const wire of factWires)for(const fact of wire.facts){
      if(!/^[A-Za-z][\w.-]*$/.test(fact.relation)||!Array.isArray(fact.values)||fact.values.some(v=>!['string','number','boolean'].includes(typeof v)||typeof v==='number'&&!Number.isSafeInteger(v)))throw new TypeError('Fact wire contains an invalid ground relation');
      program.facts.push({kind:'atom',pred:fact.relation,terms:[...fact.values],source:fact.source||wire.source||source,line:fact.line||0,wire:wire.name});
    }
    validateProgram(program);this.session=new Session(program);
  }
  evaluate({query,policy,bundle,provenance=false,budget={}}){
    const options={policy,bundle,provenance};for(const k of ['maxWork','maxDerived','maxMs'])if(k in budget)options[k]=budget[k];
    const r=this.session.query(query,options),json=publicResult(r);
    const output={...json,outputWire:`@${query}`,bindings:r.rows.map(row=>Object.fromEntries(r.columns.map((name,i)=>[name,row[i]])))};
    if(provenance&&r.complete&&r.count){output.evidence=explain(r);output.evidenceCheck=verifyExplanation(this.session.program,r,output.evidence);}
    return output;
  }
  fork(){const child=Object.create(SOPReasonerInterpreter.prototype);child.session=this.session.fork();return child;}
}
