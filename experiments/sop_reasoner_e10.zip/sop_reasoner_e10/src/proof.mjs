import {variable,testValues} from './terms.mjs';
import {digest} from './analyze.mjs';

/** One finite witness DAG per tuple. This is not all-proofs provenance. */
export function explain(result,answerIndex=0,{maxNodes=10000}={}){
  if(!result.complete)throw new Error('Cannot certify an incomplete evaluation');
  const answer=result.rows[answerIndex];if(!answer)throw new RangeError('Answer does not exist');
  const db=result.database,rootRelation=db.relations.get(result.goal);
  const rootRow=rootRelation.keys.get(answer.map(v=>db.pool.intern(v)).join(','));
  const id=(pred,row)=>`${pred}#${row}`;const root=id(result.goal,rootRow),todo=[{pred:result.goal,row:rootRow}],nodes=[],seen=new Set();
  for(let i=0;i<todo.length;i++){
    const ref=todo[i],name=id(ref.pred,ref.row);if(seen.has(name))continue;seen.add(name);
    if(seen.size>maxNodes)throw new Error('Proof node budget exceeded');
    const relation=db.relations.get(ref.pred),proof=relation?.proofs[ref.row];if(!proof)throw new Error('Provenance was disabled');
    const node={id:name,predicate:ref.pred,tuple:relation.rows[ref.row].map(x=>db.pool.decode(x)),kind:proof.kind};
    if(proof.kind==='rule'){
      node.rule=proof.rule;node.premises=[];
      for(const p of proof.premises){
        if(p.kind==='tuple'){node.premises.push({kind:'tuple',id:id(p.pred,p.row)});todo.push(p);}
        else if(p.kind==='absence')node.premises.push({...p,tuple:p.tuple.map(x=>db.pool.decode(x))});
        else node.premises.push(p);
      }
    }else Object.assign(node,proof);
    nodes.push(node);
  }
  return {version:1,root,nodes,sourceSchema:result.plan.schema,inputHash:result.plan.inputHash,scope:'one witness over completed evaluation snapshot'};
}
export function verifyExplanation(program,result,proof){
  if(!result.complete||proof.sourceSchema!==result.plan.schema||proof.inputHash!==result.plan.inputHash||proof.inputHash!==digest(program.facts))return {valid:false,reason:'INCOMPLETE_OR_STALE'};
  const nodes=new Map(proof.nodes.map(n=>[n.id,n])),rules=new Map(result.executedRules.map(r=>[r.id,r]));
  if(nodes.size!==proof.nodes.length||!nodes.has(proof.root))return {valid:false,reason:'MALFORMED_DAG'};
  const facts=new Map(),verified=new Set();
  for(const f of program.facts){const k=JSON.stringify([f.pred,f.terms]);if(!facts.has(k))facts.set(k,new Set());facts.get(k).add(JSON.stringify([f.source,f.line,f.wire]));}
  const visiting=new Set(),done=new Set(),order=[],todo=[{id:proof.root,exit:false}];
  while(todo.length){const item=todo.pop();if(item.exit){visiting.delete(item.id);done.add(item.id);order.push(item.id);continue;}if(done.has(item.id))continue;if(visiting.has(item.id))return {valid:false,reason:'CYCLIC_PROOF'};const node=nodes.get(item.id);if(!node)return {valid:false,reason:'MISSING_PREMISE'};visiting.add(item.id);todo.push({id:item.id,exit:true});for(const p of node.premises||[])if(p.kind==='tuple')todo.push({id:p.id,exit:false});}
  function unify(ts,tuple,env){const out={...env};if(ts.length!==tuple.length)return null;for(let i=0;i<ts.length;i++){const t=ts[i];if(variable(t)){if(Object.hasOwn(out,t.var)&&out[t.var]!==tuple[i])return null;out[t.var]=tuple[i];}else if(t!==tuple[i])return null;}return out;}
  const values=(ts,e)=>ts.map(t=>variable(t)?e[t.var]:t);
  function check(id){
    if(verified.has(id))return true;const n=nodes.get(id);if(!n)return false;let ok=false;
    if(n.kind==='fact')ok=!!facts.get(JSON.stringify([n.predicate,n.tuple]))?.has(JSON.stringify([n.source,n.line,n.wire]));
    else if(n.kind==='seed')ok=n.predicate===`demand:query:${result.query}:${'f'.repeat(result.columns.length)}`&&n.tuple.length===0;
    else if(n.kind==='rule'){
      const r=rules.get(n.rule),children=(n.premises||[]).filter(p=>p.kind==='tuple');
      if(r&&r.head.pred===n.predicate&&children.every(p=>verified.has(p.id))){
        const initial=unify(r.head.terms,n.tuple,{}),positive=r.body.filter(l=>l.kind==='atom'),guards=r.body.filter(l=>l.kind!=='atom');
        function bind(i,e){if(i===positive.length){return guards.every(l=>{
            const v=values(l.terms,e);if(v.some(x=>x===undefined))return false;
            if(l.kind==='test')return testValues(l.op,...v);
            const rel=result.database.relations.get(l.pred),encoded=v.map(x=>result.database.pool.intern(x));return !rel?.has(encoded);
          });}
          const l=positive[i];for(const c of children){const child=nodes.get(c.id);if(child.predicate===l.pred){const next=unify(l.terms,child.tuple,e);if(next&&bind(i+1,next))return true;}}return false;
        }
        ok=initial!==null&&bind(0,initial);
      }
    }
    if(ok)verified.add(id);return ok;
  }
  const root=nodes.get(proof.root);
  const rootOk=root?.predicate===result.goal&&result.rows.some(row=>JSON.stringify(row)===JSON.stringify(root.tuple));
  for(const id of order)if(!check(id))return {valid:false,reason:'INVALID_DERIVATION',node:id};
  return {valid:rootOk&&verified.has(proof.root),checkedNodes:verified.size,reason:rootOk?'derivation-replay':'WRONG_ROOT'};
}
