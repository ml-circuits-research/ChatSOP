import {randomUUID} from 'node:crypto';
import {validateProgram} from './parser.mjs';
import {reason} from './engine.mjs';

/** Snapshot semantics. Updates invalidate all results; deletion is not incrementally maintained. */
export class Session {
  constructor(program){this.id=randomUUID();this.epoch=0;this.program=structuredClone(program);this.cache=new Map();}
  query(name,options={}){const key=JSON.stringify([name,options]);let result=this.cache.get(key);const reused=!!result;
    if(!result){result=reason(this.program,name,options);if(result.complete)this.cache.set(key,result);}
    return {...result,rows:result.rows.map(r=>[...r]),snapshot:{session:this.id,epoch:this.epoch},cacheHit:reused};
  }
  assertFact(predicate,values,source='session'){
    if(values.some(v=>!['string','number','boolean'].includes(typeof v)||(typeof v==='number'&&!Number.isSafeInteger(v))))throw new TypeError('Ground scalar fact required');
    const fact={kind:'atom',pred:predicate,terms:[...values],source,line:0,wire:'session'};
    const next={...this.program,facts:[...this.program.facts,fact]};validateProgram(next);this.program=next;this.invalidate();
  }
  retractFact(predicate,values){const k=JSON.stringify(values),next=this.program.facts.filter(f=>f.pred!==predicate||JSON.stringify(f.terms)!==k);const removed=this.program.facts.length-next.length;
    if(removed){this.program={...this.program,facts:next};this.invalidate();}return removed;
  }
  invalidate(){this.epoch++;this.cache.clear();}
  validateSnapshot(snapshot){return snapshot.session===this.id&&snapshot.epoch===this.epoch?'CURRENT':'STALE';}
  fork(){return new Session(this.program);}
}
