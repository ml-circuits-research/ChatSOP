# Extending the lab

## Custom binding provider

Providers are best when an operation is naturally a relation generator but should be implemented by a specialized algorithm.

```js
import { Reasoner, provider, unifyTerms } from '../src/index.mjs';

const r = new Reasoner();
r.registerProvider('square', function* (args, bindings) {
  const [x, y] = args;
  for (let n = 1; n <= 10; n++) {
    let b = unifyTerms(x, n, bindings);
    if (!b) continue;
    b = unifyTerms(y, n * n, b);
    if (b) yield { bindings: b, evidence: [{ kind: 'provider', provider: 'square' }] };
  }
});

r.query(provider('square', '?x', '?y'));
```

## Custom wire semantic

Use a wire type when the operation should be a named reusable circuit component with its own definition object.

```js
r.registerWireType('graphClosure', function* ({ def, args, seed, evidence }) {
  // run a specialized closure algorithm over def.relation
  // unify results with args and yield rows
});

r.addWire({
  kind: 'wire',
  wireType: 'graphClosure',
  id: 'reachable',
  params: ['?from', '?to'],
  relation: 'edge'
});
```

A useful experiment would compare this specialized wire against recursive `reach` rules on identical graphs.

## Custom materializer

```js
r.registerMaterializer('candidate', (reasoner, options) => {
  // evaluate options.rules and write derived facts to reasoner.store
  return { rounds: 1, added: 0, facts: reasoner.store.size(), converged: true };
});
```

A materializer should use `reasoner.metrics` so symbolic costs remain comparable.

## Custom builtin

Builtins are filters/constraints that usually emit at most one binding environment.

```js
r.registerBuiltin('isEven', (args, bindings) => {
  const value = /* resolve input */;
  return { pass: value % 2 === 0 };
});
```

If an operation can emit many rows, prefer a provider.

## Parser extensions

The current CNL parser recognizes the bundled block types explicitly. For experimental wire types, the JavaScript API is the stable extension point. If a new wire proves useful, add a CNL block form only after its semantics are stable.

This separation is deliberate: syntax should not ossify exploratory semantics.
