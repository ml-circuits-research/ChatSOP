# Knowledge ingestion with an LLM teacher

The intended system is not only a hand-authored rule engine. A major use case is to ingest books, manuals, procedures and worked examples into persistent SOP knowledge.

The LLM is a **teacher/proposer**. The symbolic engine is the execution and validation substrate.

## 1. Target pipeline

```text
document / manual / worked examples
               ↓
        large teacher LLM
               ↓
 facts + rules + procedures + concepts
               +
 validation curriculum
               ↓
 symbolic checks / micro-world tests
               ↓
 accepted SOP knowledge
               ↓
 persistent/forkable KB
```

A later user query can be translated into a small SOP `goal`/circuit and evaluated against this accumulated knowledge.

## 2. Do not ingest only facts

For each important section, the teacher should try to produce several artifact classes.

### Declarative facts

```text
VALUE boilingPoint water 100 C
```

with source spans/provenance.

### General rules

Reusable relationships inferred or explicitly stated by the source.

### Procedures

Instructions should become high-level declarative transitions/subcircuits where possible rather than opaque code.

### Definitions and classifications

Concept membership, necessary/sufficient conditions, taxonomic relations.

### Constraints and invariants

Conditions that must remain true or are useful for validation.

### Examples and counterexamples

Positive and negative cases that distinguish the intended rule from plausible alternatives.

## 3. Validation curriculum generated with the knowledge

For each candidate rule or procedure, ask the teacher to construct **independent micro-worlds** rather than merely paraphrasing the source example.

Useful categories:

```text
positive example
negative example
near miss / boundary case
contradiction case
missing-information case
increasing-depth case
renamed-domain/isomorphic case
counterfactual case
procedure success case
procedure failure case
```

The teacher should not reveal hidden target-rule identifiers to the learner used for validation.

## 4. Structural curriculum

If a rule may be recursive or compositional, examples should increase structural complexity:

```text
depth 1
2
4
8
16
```

This is intended to distinguish true recursive abstractions from finite memorization/unrolling.

## 5. Provenance

Every extracted claim/rule should preserve at least:

```text
source document
source location/span
teacher/model version
ingestion run id
confidence or validation status if used
```

A derived result must be able to point back through learned rules to source evidence where possible.

## 6. Acceptance states

Do not treat ingestion as binary trusted/untrusted. A future persistent KB should support states such as:

```text
proposed
syntactically valid
locally validated
validated on independent micro-worlds
accepted
contested
superseded
```

The current code does not yet implement this lifecycle; it is a target data-model feature.

## 7. Contradictions

Do not force a teacher to collapse conflicting sources prematurely.

If source A supports `P` and source B supports `NOT P`, retain both with provenance. Later reasoning may scope by source, date, authority or world.

This is one reason the baseline uses local four-valued evidence rather than global classical consistency.

## 8. Procedures from manuals

A manual step such as:

```text
If the sample is frozen, thaw it before analysis.
```

can be represented as a transition/precondition relation rather than generated JavaScript.

High-level SOP knowledge is preferred because it remains inspectable, searchable, recomposable and testable.

Executable code/providers should be introduced only when declarative representation is inadequate or inefficient.

## 9. Query translation

The long-term architecture can use a much smaller model than the ingestion teacher to translate varied natural-language questions into SOP query circuits.

The query translator should learn paraphrase/intent mapping rather than re-derive the entire document knowledge.

Evaluation then remains symbolic and inspectable.

## 10. Separate ingestion quality from reasoning quality

Experiments must report at least two independent dimensions:

```text
A. Was the source converted correctly into SOP knowledge?
B. Given correct SOP knowledge, did the reasoner answer correctly?
```

Otherwise an LLM extraction failure can be mistaken for a reasoning failure, or vice versa.

## 11. Suggested ingestion experiment

1. Select a short technical chapter with known exercises.
2. Have a strong LLM produce SOP facts/rules/procedures plus validation micro-worlds.
3. Manually audit a small gold subset.
4. Run generated rules against generated and independently authored tests.
5. Ask held-out natural-language questions and translate them into SOP goals.
6. Compare symbolic answers with a strong direct-LLM baseline.
7. Inject contradictory passages and missing information.
8. Measure provenance coverage, correctness, structural extrapolation and update behavior.
