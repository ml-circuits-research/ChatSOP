# Included experiments

## Recursion depth

```bash
npm run experiment:depth
```

Compares a genuinely recursive reachability rule against a finite family of path rules capped at length three. Both fit examples up to depth three; only the recursive abstraction extrapolates beyond that depth.

The experiment is intentionally small and transparent. It is useful as a regression test for structural generalization, not as a performance benchmark.

## Independent micro-worlds and noise

```bash
npm run experiment:noise
```

Generates independent relational worlds, adds distractor facts and controlled label noise, enumerates a candidate path-rule grammar and records the rank of the hidden rule.

Change these parameters in `experiments/noise-microworlds.mjs` to make the induction problem harder:

```text
relations
maxBody
world count
positive examples
negative examples
distractor density
labelNoise
```

The important experimental idea is to test a candidate abstraction in **independent worlds**, not to repeat surface variations of the same world.

## Evaluation strategies

```bash
npm run experiment:strategies
npm run bench
```

Compares:

```text
delta + sliced
delta + global
naive + sliced
naive + global
```

The synthetic workload also contains irrelevant rules. It therefore measures both fixed-point strategy and backward relevance slicing.

Do not treat the bundled wall-clock numbers as universal. Re-run on the target machine and focus on symbolic operation counts.

## Randomized graph property test

`test/property.test.mjs` creates seeded random graphs, computes transitive closure independently, then checks every pair against the symbolic engine. This guards against a benchmark that merely reproduces the implementation's own assumptions.

## Recommended next experiments

The maintained staged program is now in `EXPERIMENT_ROADMAP.md`. Highest priority:

1. demand-driven/tabling evaluation against fixed-point materialization;
2. SMT/provider versus relational enumeration;
3. proof-DAG canonicalization and abstraction mining;
4. learned abstraction versus specialized compiled wire;
5. LLM-generated independent micro-world curricula with structural extrapolation;
6. first-class world/time/causal semantics only if generic representations become inadequate.

Every new experiment should follow `RESEARCH_PROTOCOL.md` and state a falsification condition before execution.
