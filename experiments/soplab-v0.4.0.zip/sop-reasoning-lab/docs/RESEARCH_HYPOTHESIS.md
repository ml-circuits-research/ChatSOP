# Research hypothesis and scientific target

## 1. The central hypothesis

SOP Reasoning Lab does **not** assume that one algorithm should efficiently solve every form of reasoning.

The stronger and more testable hypothesis is that many reasoning families can share a compact intermediate representation (IR) and execution contract:

```text
knowledge / instructions / observations
                ↓
      SOP relational circuits
                ↓
 bindings + evidence + provenance
                ↓
 evaluation / search / specialized solver
                ↓
 proof, answer, plan, hypothesis or learned abstraction
```

The fundamental runtime object is a **relation of bindings with evidence**, not a scalar and not necessarily a classical predicate implementation.

Conceptually:

```text
BindingProducer : Bindings -> 0..N (Bindings + Evidence)
```

A KB lookup, a join, an OR branch, an aggregate, a graph algorithm, an SMT solver, a SQL query, a semantic retriever or another SOP circuit can all satisfy this contract.

The long-term research question is therefore:

> Can a small symbolic kernel plus composable binding producers serve as a sufficiently general reasoning IR, while allowing important recurring reasoning patterns to be learned and compiled into reusable abstractions or specialized algorithms?

## 2. What would be genuinely interesting

The novelty target is **not** "rules exist", "Datalog exists", "planning exists" or "SMT exists". Those are established fields.

The potentially interesting contribution is the full adaptive loop:

```text
facts / procedures / examples
          ↓
generic SOP circuits
          ↓
reasoning and proof traces
          ↓
detect repeated or expensive structure
          ↓
induce a reusable abstraction
          ↓
validate it on independent micro-worlds
          ↓
compile it as a rule, named wire, provider or specialized algorithm
          ↓
future reasoning becomes shorter / cheaper / more reliable
```

This would make the system learn not only *facts* but parts of its own **reasoning vocabulary and algorithmic shortcuts**.

## 3. Separation of concerns

The project deliberately separates four layers:

1. **Representation** — how knowledge and intermediate structure are written.
2. **Semantics** — what a wire or condition means as a binding producer.
3. **Evaluation strategy** — how evaluation/search is scheduled and optimized.
4. **Learning** — how new rules, abstractions or specialized components are discovered.

A scientific experiment should change as few layers as possible at once.

## 4. Main hypotheses

### H1 — Binding relations are a useful common IR

Many reasoning tasks can be composed from binding-producing relations while preserving explicit provenance.

**Prediction:** deduction, relational querying, aggregation, planning, abduction and calls to specialized solvers can exchange intermediate results without custom pairwise adapters.

**Falsification pressure:** if important reasoning families repeatedly require opaque state or semantics that cannot be represented without destroying the common contract, the IR is too weak.

### H2 — Circuit structure can replace complicated expression syntax

Complex Boolean structure can be represented through named `all` and `any` wires rather than nested syntax.

**Prediction:** reusable named circuits remain readable, compositional and easier to profile/learn than deeply nested expressions.

**Falsification pressure:** if realistic knowledge requires excessive numbers of tiny wires or loses locality/readability, richer structured syntax may be required.

### H3 — A small generic kernel can coexist with specialized algorithms

A capability should not automatically become a primitive. Generic rules provide a semantic baseline; specialized wires/providers are introduced only when justified.

**Prediction:** specialized implementations can preserve answers while substantially reducing symbolic cost on some workloads.

The bundled `graphClosure` experiment is the first example.

### H4 — Independent micro-worlds improve rule induction

Rules proposed from examples should be validated across structurally independent worlds, not merely paraphrases of one world.

**Prediction:** multiple independent worlds eliminate spurious rules and make induction more robust to label noise.

**Falsification pressure:** if independent worlds do not improve held-out structural generalization relative to same-world examples, the curriculum hypothesis is weak.

### H5 — Structural extrapolation is required to learn recursion

Training only at shallow depth cannot reliably distinguish a recursive abstraction from a finite unrolling.

**Prediction:** curricula that systematically increase depth and generate discriminating counterexamples favor genuinely recursive rules.

### H6 — Proof traces are training data for new abstractions

Repeated proof subgraphs contain information about useful reusable reasoning patterns.

**Prediction:** anti-unification/compression of repeated proof traces can produce abstractions that reduce future proof expansion without changing answers.

**Falsification pressure:** if learned abstractions mostly overfit, increase search, or destroy interpretability, proof compression alone is insufficient.

### H7 — Some abstractions should compile into algorithms, not only rules

A repeated pattern may justify a specialized wire/provider when an algorithmic implementation yields major leverage.

**Prediction:** for selected patterns, a compiled component gives equivalent answers with substantially fewer symbolic operations.

This is stronger than ordinary rule learning: the system may learn *how to reason more efficiently*, not only additional propositions.

### H8 — An LLM is best treated as a teacher/proposer, not the trusted evaluator

A large model can transform books/manuals into candidate facts, rules, examples, counterexamples and micro-worlds. The symbolic system validates and executes the resulting knowledge.

**Prediction:** independent symbolic validation plus contrastive examples reduces persistent teacher errors and produces reusable knowledge that survives model replacement.

## 5. What “almost universal” means here

It does **not** mean computationally efficient universality.

It means that the IR should be broad enough to host or compose:

- deduction and recursive closure;
- classification;
- constraint solving;
- aggregation;
- abduction;
- planning;
- counterfactual worlds;
- induction;
- analogical mapping;
- temporal/causal reasoning;
- external numerical or symbolic solvers;
- learned semantic retrieval.

Different families may require different algorithms. The research question is whether they can share the same circuit-level composition and provenance model.

## 6. Scientific success criteria

A strong result would show all of the following:

1. Several reasoning families expressed through the same IR.
2. Clear semantic equivalence tests against independent implementations.
3. Learned abstractions that generalize beyond training depth/worlds.
4. Measurable reduction in search/proof cost after abstraction learning.
5. Specialized compiled wires that preserve semantics and produce large efficiency gains where appropriate.
6. Explicit provenance and contradictions preserved throughout composition.
7. New capabilities added without rewriting the central evaluator.

The strongest future claim would be supported only if the system repeatedly discovers reusable reasoning structures that transfer across tasks and reduce future computation.
