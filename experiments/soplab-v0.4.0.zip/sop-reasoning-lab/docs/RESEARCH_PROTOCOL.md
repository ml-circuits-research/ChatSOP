# Research protocol

Use this protocol for every future experiment so results remain comparable across architecture changes.

## 1. State the hypothesis before running

Every experiment record should contain:

```text
question
hypothesis
independent variable
dependent variables
baseline
expected failure mode
seed / dataset version
```

Avoid experiments whose only objective is "see what happens" unless explicitly labeled exploratory.

## 2. Separate semantic and optimization experiments

A **semantic experiment** changes what programs mean.

An **optimization experiment** claims to preserve answers while changing execution.

Never mix the two labels. If answers differ, an optimization candidate has failed semantic equivalence until explained.

## 3. Three-way representation comparison

When testing a new capability, prefer:

```text
A. generic facts/rules
B. specialized wire
C. provider/external solver
```

This avoids assuming that every useful capability belongs in the SOP kernel.

## 4. Independent oracle whenever possible

Do not validate the reasoner only against itself.

Examples:

- graph closure: independent BFS/Floyd-Warshall implementation;
- arithmetic: direct JavaScript/SMT result;
- planning: known optimal small domains/exhaustive search;
- aggregation: direct collection operations;
- induction: hidden rule used only by generator, not learner.

## 5. Train/test structural separation

For learning experiments, separate not only examples but **structures**.

Examples:

```text
train depth <= 3, test depth 4..20
train worlds A-D, test worlds E-H
train graph sizes <= 20, test > 20
train relation names randomized independently
```

This detects finite memorization disguised as abstraction.

## 6. Preserve negative results

A failed candidate is valuable. Record:

- what changed;
- what workload broke;
- smallest counterexample;
- metrics before/after;
- whether failure is semantic, scaling, learning, or implementation.

Do not delete negative result files when replacing a strategy.

## 7. Required metrics

For relational evaluation:

```text
answerSignature
candidateRows
unifications
matchedRows
ruleFirings
factsDerived
rounds
wireCalls
providerCalls
queryRows
elapsedMs
```

For search:

```text
statesExpanded
statesGenerated
maxFrontier
solutionCost
solutionDepth
```

For learning:

```text
train accuracy
held-out accuracy
candidate count
rank of target/correct rule
learned representation size
structural extrapolation depth
noise level
```

Add metrics, but do not silently rename existing fields in historical results.

## 8. Environment record

Store at least:

```text
project version
git commit if available
Node version
OS/platform
CPU architecture
seed
command line
workload parameters
```

For LLM-assisted experiments also store:

```text
model identifier
prompt/template version
decoding parameters when available
raw generated artifact or hash
validation result
```

## 9. Repetitions

Deterministic symbolic tests need one run plus regression tests.

Randomized/LLM experiments should use multiple seeds/worlds and report distributions, not only the best run.

## 10. Evidence threshold for promoting a new primitive

A proposed permanent wire type should demonstrate at least one of:

- substantially better asymptotic/symbolic cost;
- substantially clearer reusable semantics;
- a correctness invariant difficult to preserve generically;
- better learning/generalization;
- required interoperability with a specialized solver.

Otherwise keep it as ordinary composition or provider.

## 11. Result directories

Recommended layout:

```text
results/<experiment>/<date-or-version>/
  config.json
  result.json
  stdout.txt
  notes.md
```

Never overwrite a result used in a written conclusion without preserving the old record.
