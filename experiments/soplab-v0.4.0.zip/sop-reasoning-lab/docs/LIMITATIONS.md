# Current limitations and research boundaries

These limits are explicit so later experiments do not accidentally attribute capabilities to the baseline that it does not have.

## Finite-domain bias

The rule engine is most naturally used like Datalog. It does not contain function symbols that recursively construct new terms. This helps fixed-point termination. Providers can still introduce values, so a provider that emits an unbounded stream can break this assumption.

## Recursive named view wires

Recursive `all`/`any`/`reduce` wire references are currently rejected. Recursion is expressed through materialized `rule` heads. A future tabled evaluator could relax this restriction.

## Negation

`NONE` supports stratified negation only. Programs with a negative recursion cycle are rejected. Stable-model/answer-set semantics are not implemented.

Explicit `NOT` is different: it is ordinary signed evidence and may coexist with positive evidence.

## Aggregation

`reduce` is evaluated on demand and is not incrementally maintained. Recursive aggregation and sophisticated monotonic-aggregate semantics are outside the current baseline.

## Delta materialization

The delta implementation is a research baseline, not a full database-grade semi-naive compiler. It applies delta restriction to a safe positive fragment and falls back to repeated evaluation for complex conditions.

No cost-based join ordering, magic sets, RETE, differential dataflow or disk-backed execution is implemented.

## Query slicing

`sliced` scope performs backward predicate dependency selection, not full top-down tabling. It can eliminate irrelevant rule families but still materializes the selected recursive subprogram.

## Planning

Planning uses generic best-first state-space search and copies fact maps. It is suitable for experiments and small domains, not large industrial planning problems. There is no partial-order planning, symbolic state compression or learned heuristic in the baseline.

## Abduction

The current algorithm enumerates bounded sets of candidate assumptions by cost and re-evaluates the KB. This provides a simple correctness baseline but scales combinatorially.

## Rule learning

The included learner only explores a small path-shaped relational grammar. It is a harness for curriculum/noise/generalization experiments, not a general inductive logic programming system.

## Confidence and uncertainty

Proof provenance is represented, but numeric confidence, probabilistic inference and evidence calibration do not yet have semantics in the kernel.

## Time, modality and worlds

Temporal, counterfactual, modal and causal reasoning do not yet have dedicated semantics. They can be represented explicitly as relation arguments or implemented as new wire/provider types; comparing those alternatives is one intended use of the project.

## Persistence and concurrency

The claim store is in-memory. Serialization helpers exist at the data-structure level, but there is no transactional persistent store, concurrency control or distributed execution.

## Security

Providers execute ordinary JavaScript registered by the host application. The project does not sandbox them. Any LLM-generated executable provider should therefore run outside this process in an appropriate sandbox.
