# Semantic model

This document fixes the conceptual semantics that future implementations should preserve or explicitly revise.

## 1. Core entities

### Term

A constant, variable or finite structured value. Variables begin with `?`.

### Binding environment

A partial mapping from variables to terms:

```text
{ ?x = Ana, ?age = 42 }
```

### Evidence

Metadata explaining why a row exists: source claim, rule application, provider call, assumption, aggregate, transition, or future specialized wire.

### Binding row

```text
(bindings, evidence)
```

### Binding relation

A finite set/stream of binding rows.

This is the common intermediate representation.

## 2. Conditions as relations

Every condition is interpreted relative to an incoming binding environment.

```text
Eval(condition, seedBindings) -> rows
```

The returned bindings must be compatible extensions of the seed unless the condition explicitly represents a state/world transformation outside ordinary relational evaluation.

### Relation lookup

```text
MATCH parent ?x ?y
```

finds claims whose relation/sign/arity match and unifies their arguments with the current bindings.

### Conjunction

Sequential conditions implement relational join:

```text
A AND B
```

means evaluate `A`, then evaluate `B` for every row emitted by `A`.

### Disjunction

`any`/OR is relational union. Each branch starts from the same incoming seed.

### Absence

`NONE P` is an anti-existence test. It succeeds only if `P` emits no row for the current bindings. Because this is non-monotonic, the current baseline requires stratified negation.

### Explicit negative evidence

`NOT P` is not absence. It is stored evidence supporting the negative sign of `P`.

A proposition can therefore have four evidence states:

```text
positive negative    state
   0        0         unknown
   1        0         supported
   0        1         refuted
   1        1         conflicting
```

No principle of explosion is applied.

## 3. Named wires as derived relations

A named `all`, `any` or specialized wire exposes parameters through `GIVES`/its declared interface.

Local variables are existential and must be alpha-renamed for every invocation.

Example:

```text
@grandparent all
GIVES ?x ?y
MATCH parent ?x ?middle
MATCH parent ?middle ?y
```

Conceptually, this defines a derived relation `grandparentView(?x, ?y)` without requiring nested function or predicate syntax.

The **circuit is the expression tree**.

## 4. Rules

A rule is a projection/materialization operation:

```text
body relation -> ground head claims
```

For every successful body row, substitute the bindings into the head and insert the resulting ground claim with proof provenance.

Recursive positive rules are evaluated to a fixed point.

## 5. Aggregation

A `reduce` wire consumes a relation, groups rows and emits new rows containing aggregates.

Aggregation is intentionally distinct from ordinary Horn rules because operations such as count, sum or argmin have specialized semantics and implementations.

## 6. Providers

A provider is an external binding producer obeying the same row contract.

Possible providers include:

```text
SMT/CSP solver
SQL query
graph database
numerical routine
vector/semantic retrieval
safe code interpreter
remote tool
LLM proposer
```

A provider is not automatically trusted. Its evidence should identify the provider and, when appropriate, inputs/version/source.

## 7. State-changing reasoning

Planning differs from monotonic deduction because transitions construct hypothetical states.

A transition can be viewed as:

```text
(current world bindings/state) -> next world/state + cost
```

The same ordinary reasoning kernel may be run inside each state, but state-space search is a separate algorithmic layer.

## 8. Abduction

Abduction searches for additional premises that make a goal derivable.

Conceptually:

```text
find A minimizing cost(A)
such that KB ∪ A entails Goal
```

This shares infrastructure with planning/search but has different candidate-generation semantics.

## 9. Induction

Induction searches over candidate *rules or circuits* rather than ordinary bindings.

Conceptually:

```text
find program P minimizing complexity/error
such that P explains training micro-worlds
and generalizes to held-out worlds/depths
```

The learned object may later become a rule, named wire, or specialized algorithm.

## 10. Provenance invariant

A result without traceable evidence should be distinguishable from a result with traceable evidence.

At minimum, derived claims should preserve enough information to reconstruct:

- source claims;
- rule/wire/provider responsible;
- relevant bindings;
- assumptions;
- state/world identity when introduced later.

## 11. Open semantic extensions

These are intentionally not frozen yet:

- probabilistic confidence;
- defeasible priorities/default logic;
- stable-model semantics;
- first-class worlds/scopes;
- temporal intervals and temporal uncertainty;
- interventions/causal models;
- existential object creation;
- higher-order rules/circuits;
- learned approximate providers.

New semantics must document whether they preserve monotonicity, determinism, finite-domain termination and provenance.
