# Baseline observations

These observations describe the bundled synthetic workloads only. They are included as reference points for future experiments, not as general performance claims.

## Recursive abstraction versus bounded paths

`results/recursion-depth.txt` shows that both representations solve chains of depth 1–3, while the representation explicitly bounded to paths of length at most three fails from depth 4 onward. The recursive rule continues through depth 20 in the bundled experiment.

This is primarily a **generalization-shape test**: examples limited to shallow depth cannot by themselves distinguish recursion from a sufficiently large finite expansion.

## Delta versus naive fixed point

In the packaged graph workload, `delta` and `naive` produce the same answer. Delta evaluates substantially fewer candidate rows than naive. Wall-clock timings vary and should be regenerated on the target machine.

The current implementation is intentionally conservative: the delta optimization applies directly to a positive Horn fragment, while more complex rule bodies can fall back to repeated evaluation.

## Sliced versus global scope

The workload contains irrelevant rule families. `sliced` selects only the backward dependency closure of the goal; `global` materializes the irrelevant families as well. On small workloads wall-clock noise can dominate the difference, so `selectedRuleCount`, `factsDerived` and other symbolic metrics are the more reliable comparison.

## Recursive rules versus specialized graph wire

`results/graph-wire-vs-rules.txt` is the clearest example of why the architecture keeps wire semantics pluggable.

Both variants return the same 44 reachable nodes. In the packaged run:

```text
recursive rules:
  990 facts derived
  18,885 candidate rows
  2,104 rule firings

specialized graph wire:
  87 graph edges visited
  1 wire call
```

This does not establish that graph wires should replace generic rules. It establishes that the harness can expose when a specialized semantic component buys a large amount of computational leverage while preserving answers.

## Rule induction over micro-worlds

The bundled candidate grammar contains a hidden two-relation path rule. Under the current synthetic generator, independent worlds keep that rule at or near rank 1 even with label noise. The task is intentionally simple; its role is to provide a reproducible starting point for harder curricula, larger grammars and LLM-generated examples.
