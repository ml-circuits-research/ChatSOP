# Glossary

**Atom / claim** — signed relation instance such as `parent Ana Bob` or `NOT safe X`.

**Binding** — assignment of a variable to a term, e.g. `?x = Ana`.

**Binding row** — bindings plus evidence/provenance.

**Binding producer** — any condition/component that maps an input binding environment to zero or more output rows.

**Wire** — named reusable SOP component exposing a relation-like interface.

**`all` wire** — conjunction/natural join of conditions.

**`any` wire** — disjunction/union of alternatives.

**`reduce` wire** — grouping/aggregation over another binding relation.

**Provider** — externally implemented binding producer such as an SMT solver or graph algorithm.

**Materializer** — strategy that executes rules and derives fixed-point facts.

**Explicit negation (`NOT`)** — evidence for the negative sign of a proposition.

**Negation as failure (`NONE`)** — succeeds when no matching result exists in the evaluated scope.

**Micro-world** — independent synthetic or generated KB instance used to train/validate a candidate abstraction.

**Proof DAG** — provenance graph showing claims and rule applications supporting a derived conclusion.

**Abstraction** — reusable generalized circuit/rule/algorithm learned from repeated examples or proofs.

**Structural extrapolation** — testing at structural complexity/depth beyond training, rather than merely new surface examples.

**Specialized wire** — wire whose semantics is implemented by a dedicated algorithm rather than generic rule expansion.

**Semantic experiment** — changes program meaning.

**Optimization experiment** — claims to preserve meaning while changing cost/execution.
