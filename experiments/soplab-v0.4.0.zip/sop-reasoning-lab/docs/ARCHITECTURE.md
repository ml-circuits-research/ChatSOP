# Architecture

## 1. Research objective

The project tests a specific architectural hypothesis: many reasoning operations can share a small runtime if intermediate results are represented as **relations of bindings with provenance** rather than as opaque values.

The project therefore separates four questions that are often mixed together:

1. **Representation** — facts, variables, reusable wires, rules and states.
2. **Semantics** — how a wire transforms binding environments.
3. **Evaluation strategy** — how to schedule rule evaluation/search efficiently.
4. **Learning** — how rules or reusable abstractions are obtained from examples.

A future experiment can replace any one of these layers while keeping the others stable.

## 2. Intermediate representation

An atom is conceptually:

```text
(sign, relation, argument_1, ..., argument_n)
```

Variables begin with `?`. Terms can be primitive JavaScript values, arrays or structured objects. The default rule engine is function-free: it does not create an unbounded term algebra.

A successful condition emits:

```text
{
  bindings: { ?x: ..., ?y: ... },
  evidence: [...]
}
```

The evaluator composes these rows.

## 3. Relational core

For an atom such as:

```text
parent ?x ?middle
```

the store selects candidate rows from an index keyed by sign/relation/arity and, when possible, by grounded argument positions. Unification extends the current binding environment.

Sequential conditions implement a natural join because shared variables must unify. `any` implements a union. `none` is an anti-existence test. `reduce` groups successful bindings and produces new bindings.

This makes a named condition wire behave like a derived relation.

## 4. Claim store and contradictions

Positive and explicit negative support are stored independently. A proposition can therefore be:

- `unknown`;
- `supported`;
- `refuted`;
- `conflicting`.

A contradiction is local to the proposition; it does not make every proposition derivable.

Each record can retain multiple proof objects. Rule proofs record rule id, bindings and premise keys. `Reasoner.explain()` expands this into a proof DAG. `Reasoner.explainDOT()` emits Graphviz DOT.

## 5. Wires

A wire is a named reusable relation. Calls use `$wire ...`.

The evaluator does not hard-code every possible wire kind. `Reasoner.wireTypes` maps a wire type to a generator handler.

Built-ins are:

- `all`: join a sequence of conditions;
- `any`: union alternatives;
- `reduce`: aggregate another relation.

New wire semantics are registered with `registerWireType()`.

This is a deliberate research boundary: a future temporal, causal, graph, SMT or probabilistic wire can be tested without changing the generic reference/call machinery.

## 6. Binding providers

`CALL provider ...` invokes a `ProviderRegistry` entry. A provider receives arguments and current bindings and may emit zero or more new binding environments.

Providers are the interoperability boundary for algorithms that should not be encoded as Horn rules. Examples include:

- an SMT/CSP solver;
- SQL or an indexed graph database;
- arithmetic/numerical routines;
- semantic/vector retrieval;
- a deterministic code interpreter;
- a constrained LLM call;
- remote tool results.

The rest of the circuit only sees bindings plus provenance.

## 7. Rules and fixed points

A rule evaluates its body and substitutes each successful binding into its head. Ground heads are inserted into the claim store with a proof record.

Two materializers are provided.

### Naive

Repeatedly evaluates all selected rules until no new facts are added.

### Delta

For rule bodies in the positive Horn fragment, at least one positive atom is restricted to the previous delta. More complex bodies fall back to safe repeated evaluation. This is intentionally conservative rather than pretending to be a complete optimized Datalog engine.

Materializers are plugins. A future implementation can add magic sets, full semi-naive compilation, RETE, differential dataflow, SQL pushdown or custom graph algorithms.

## 8. Goal-directed slicing

`Reasoner.evaluate(goal, { scope: 'sliced' })` computes the predicate dependency closure backwards from the goal and keeps only rules capable of contributing to it.

This is not full top-down tabling. It is a simple, explicit baseline between global forward chaining and a future demand-driven evaluator.

## 9. Negation

`NOT relation ...` is explicit negative evidence and is just another signed relation.

`NONE relation ...` means that no matching row exists. Because this is non-monotonic, rules using `NONE` are stratified. A head depending negatively on a predicate must be evaluated in a higher stratum. Negative recursive cycles are rejected.

This avoids order-dependent stale conclusions.

## 10. Planning

A `transition` contains a condition, additions, removals and cost. Planning uses generic best-first search over immutable sets of ground facts. Each candidate state can run ordinary symbolic rules before checking a goal or instantiating another transition.

This intentionally reuses the reasoning kernel but keeps state-space search outside fixed-point deduction.

## 11. Abduction

Abduction is currently a bounded minimum-cost search over candidate assumptions. For each assumption set, a clean clone of the KB is evaluated and tested against the goal.

This is a correctness-oriented baseline. It is not yet the efficient abductive proof procedure that a mature system would use.

## 12. Learning harness

The included learner enumerates a deliberately narrow grammar of relational path rules, evaluates candidates over independent micro-worlds, and ranks them by prediction accuracy plus a small complexity penalty.

Its role is experimental: it provides a place to test whether an LLM-generated curriculum of positive/negative micro-worlds can recover reusable symbolic structure. It is not claimed as a general ILP implementation.

## 13. Invariants worth preserving in future strategies

A replacement engine should preserve, or explicitly declare that it changes, these invariants:

- immutable claim identity;
- explicit distinction between `NOT` and `NONE`;
- alpha-renaming of local variables in reusable wires;
- provenance for derived claims;
- deterministic output for deterministic providers;
- no silent acceptance of non-stratifiable negative recursion;
- comparable execution metrics;
- side-effect-free `Reasoner.evaluate()`.
