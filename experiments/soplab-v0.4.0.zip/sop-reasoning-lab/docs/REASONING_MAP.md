# Mapping reasoning families onto the baseline

This table is a research hypothesis, not a claim that all forms are already solved efficiently.

| Reasoning family | Baseline formulation |
|---|---|
| deduction | rules + fixed point |
| recursive deduction | recursive rules + fixed point |
| relational query | atoms + joins + bindings |
| classification | derive/query membership relations |
| explicit contradiction | independent positive/negative claims |
| closed-world absence | stratified `NONE` |
| aggregation | `reduce` wire |
| constraint filtering | `TEST` builtin |
| external symbolic solving | `CALL` provider |
| planning | transition rules + best-first state search |
| abduction | assumptions + minimum-cost search |
| counterfactual reasoning | cloned/modified world + ordinary evaluation |
| explanation | proof DAG/provenance |
| induction | search over candidate rules on micro-worlds |
| abstraction learning | future: compress repeated proof/circuit patterns into wires |
| analogy | future: relation-preserving mapping search |
| temporal reasoning | currently explicit relations; candidate specialized wire |
| causal reasoning | currently explicit world/transition modeling; candidate specialized wire |

The architectural question to test is not whether every row should use the same algorithm. It is whether they can share a compact intermediate representation and compositional runtime interface.

## Unifying view

The map above is intentionally not a claim that all reasoning reduces to Horn inference. The proposed commonality is the **binding/evidence interface** plus explicit search/world transformation where necessary.

A useful working decomposition is:

```text
deduction      = satisfy goal with zero added assumptions
abduction      = satisfy goal while minimizing added assumptions
planning       = satisfy goal while constructing a low-cost transition sequence
induction      = satisfy examples while constructing a low-complexity rule/circuit
optimization   = satisfy constraints while minimizing an objective
explanation    = retain the derivation object produced by satisfaction/search
```

This decomposition is a research hypothesis to test, not a reason to force every family through the same algorithm.
