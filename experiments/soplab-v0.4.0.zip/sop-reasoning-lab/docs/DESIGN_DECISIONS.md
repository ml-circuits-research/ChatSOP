# Design decisions and non-decisions

This file records why the baseline looks the way it does. Future versions may reverse a decision, but should state that explicitly.

## D1 — Relations of bindings are the common runtime representation

Reason: joins, queries, solvers and reusable circuits compose naturally through variable bindings.

Status: core hypothesis; must be tested, not treated as dogma.

## D2 — SOP syntax stays close to CNL/dataflow

No predicate parentheses or comma-heavy syntax are required. Named circuits express complex structure.

Reason: keep authoring readable and expose reusable subgraphs to learning/profiling.

## D3 — Circuit structure represents Boolean structure

Prefer named `all` and `any` wires over deeply nested Boolean expressions.

Reason: the graph is explicit, reusable and SSA-like.

## D4 — `NOT` and `NONE` are different

`NOT` = explicit negative evidence.

`NONE` = no matching proof/row in the current evaluated scope.

Reason: KBs extracted from documents are incomplete and can contain contradictions.

## D5 — Contradictions are local

Positive and negative evidence can coexist. There is no explosion rule.

Reason: heterogeneous real-world sources cannot be assumed globally consistent.

## D6 — Function-free baseline

The core rule engine does not recursively construct arbitrary new terms.

Reason: predictable finite fixed points and Datalog-like evaluation.

Non-decision: future existential/object-generating semantics remain open.

## D7 — Specialized algorithms are allowed, but not automatically primitives

Reason: a universal IR does not imply one universal evaluator.

New algorithms should enter through wire/provider/materializer interfaces and earn permanent status experimentally.

## D8 — Planning/search remains outside monotonic fixed-point deduction

Reason: hypothetical world transitions and branch costs are different operational semantics, even if they reuse the same relational conditions.

## D9 — LLM output is candidate knowledge

Reason: teacher models can hallucinate. Candidate rules should be validated by examples, counterexamples, independent worlds and symbolic execution.

## D10 — Provenance is part of semantics, not optional logging

Reason: research, contradiction analysis and later abstraction learning require knowing how a conclusion was obtained.

## D11 — Learning should prefer structural generalization

Reason: shallow example fit can be reproduced by finite unrolling. Depth/world transfer is a stronger signal.

## D12 — Performance claims use symbolic metrics first

Reason: small Node benchmarks are noisy. Candidate rows, unifications, firings and expansions reveal architecture-level differences more reliably.

## D13 — The current CNL is not frozen

Syntax should stabilize only after semantics do. Experimental wire types may exist only in the JavaScript API before receiving surface syntax.

## D14 — The project is a comparison harness, not the final engine

Any layer may be replaced if the same workloads/tests can expose the difference.
