# Candidate wire families for future comparison

These are deliberately not implemented as privileged concepts. The point of the lab is to test whether each capability is better represented by ordinary relations/rules, by a specialized wire, or by a binding provider.

| Candidate wire | Purpose | Baseline to compare against |
|---|---|---|
| `graph` / `closure` | reachability, shortest paths, components | recursive rules + search |
| `smt` | arithmetic and finite-domain constraints | `TEST` + relational enumeration |
| `temporal` | intervals, before/after, temporal closure | time as ordinary relation arguments |
| `causal` | interventions and counterfactual worlds | explicit transition/world relations |
| `world` | branchable hypothetical contexts | cloned KB + assumptions |
| `choice` | alternatives with costs/preferences | external best-first search |
| `sequence` | ordered procedural steps | relations plus transition search |
| `set` | set-valued relations and membership | `reduce SET` + ordinary facts |
| `probabilistic` | weighted evidence/inference | four-valued deterministic evidence |
| `semantic` | neural/vector retrieval | external `CALL` provider |
| `solver` | generic CSP/optimization | provider + search |
| `rewrite` | symbolic normalization/e-graph style rewriting | ordinary rules |
| `induction` | synthesize reusable relations from examples | learning module outside evaluator |
| `proof` | proof-pattern matching/compression | provenance DAG inspection |
| `scope` | source/time/world-specific contexts | explicit relation arguments |

## How to decide whether a new wire is justified

A specialized wire is justified only if at least one of these is demonstrated experimentally:

1. It expresses a recurring semantic pattern substantially more clearly than ordinary rules.
2. It enables a specialized algorithm with a large reduction in symbolic cost.
3. It preserves an invariant that is awkward or unsafe in generic rules.
4. It enables learning/generalization that is difficult with the baseline representation.

Otherwise prefer composition of existing wires. A minimal semantic vocabulary is easier to learn, verify and optimize.

## Suggested experiment shape

For each candidate wire, keep the task and input knowledge fixed and compare:

```text
A. ordinary facts/rules
B. specialized wire
C. external provider/solver
```

Record answer equivalence, proof/provenance quality, representation size, candidate rows, unifications, rule firings, search expansions and elapsed time.

## Learned versus hand-designed wires

A future wire may be proposed manually or discovered from repeated proof/search structure. In either case, promotion into the core vocabulary requires the same comparison protocol.

A learned pattern can have three different interpretations:

```text
semantic abstraction   -> new reusable concept/relation
execution macro         -> same semantics, cheaper scheduling
specialized algorithm   -> same relation contract, different evaluator
```

Do not report an execution macro as a newly learned semantic concept. See `ABSTRACTION_LEARNING.md`.
