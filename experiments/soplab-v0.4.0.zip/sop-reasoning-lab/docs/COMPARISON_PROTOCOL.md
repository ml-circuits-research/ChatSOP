# Comparison protocol

This repository is intended to survive changes in the reasoning architecture. Use the following protocol when testing a new strategy or wire type.

## 1. Keep workloads immutable

A workload should construct a fresh KB, rules/wires and goal. Never benchmark a reasoner that already contains derived facts from a previous variant.

Use `Reasoner.evaluate()`, which clones only base knowledge before materialization.

## 2. Compare semantics before speed

For every variant record a canonical answer signature. `src/comparison.mjs` provides `compareVariants()` and marks whether each variant matches the reference result.

A faster strategy that changes answers is a semantic experiment, not an optimization, and should be labeled accordingly.

## 3. Record symbolic cost

At minimum preserve:

```text
candidateRows
unifications
ruleFirings
factsDerived
rounds
wireCalls
providerCalls
queryRows
```

Wall-clock milliseconds are secondary because they depend on Node version, machine, JIT state and workload size.

## 4. Use at least four workload families

### Deductive recursion

Graph reachability, recursive taxonomy, transitive dependencies.

Measures depth generalization and fixed-point behavior.

### Wide relational joins

Many rows, selective grounded columns, multiple joins.

Measures indexing and join ordering.

### Mixed reasoning

Rules plus reducers, constraints, `NONE`, or providers.

Measures whether an optimization remains correct outside the pure Horn fragment.

### Search

Planning or abduction with branching and costs.

Measures integration between symbolic evaluation and state-space search.

## 5. Noise and learning experiments

For learned rules, vary independently:

- number of micro-worlds;
- positive/negative balance;
- label noise;
- distractor density;
- structural depth;
- candidate grammar size;
- training/test depth gap.

Report rule rank or held-out predictions, not only training fit.

## 6. Adding a materializer

A materializer has the shape:

```js
(reasoner, options) => ({
  rounds,
  added,
  facts,
  converged,
  ...extraMetrics
})
```

Register it:

```js
reasoner.registerMaterializer('reteLike', reteLikeMaterializer);
```

Then compare with the same workload:

```js
const variants = [
  { name: 'baseline', strategy: 'delta', scope: 'sliced' },
  { name: 'candidate', strategy: 'reteLike', scope: 'sliced' },
];
```

## 7. Adding a wire type

A wire evaluator is a generator:

```js
function* handler({ reasoner, def, args, seed, evidence, context, solve }) {
  // yield { bindings, evidence }
}
```

Register it with `registerWireType()`.

For a fair comparison, make a new workload variant that replaces only the target representation. Example: ordinary recursive rules versus a specialized graph-closure wire.

## 8. Suggested result record

```json
{
  "variant": "delta+sliced",
  "workload": "reachability-100",
  "answerSignature": ["..."],
  "metrics": {
    "candidateRows": 0,
    "unifications": 0,
    "ruleFirings": 0,
    "factsDerived": 0,
    "rounds": 0,
    "elapsedMs": 0
  },
  "environment": {
    "node": "...",
    "platform": "..."
  }
}
```

Store deterministic workload parameters and random seeds with every result.
