# SOP CNL reference

The CNL is intentionally line-oriented. Named blocks provide structure, so the language does not need nested predicate syntax.

## Terms

Variables start with `?`.

```text
?person
?x
```

Bare words are strings. Numbers, booleans and `null` are recognized. Strings containing spaces should be quoted.

```text
age Ana 42
label item "long scientific name"
active Ana true
```

## Claims

```text
@c1 claim
VALUE parent Ana Bob
SOURCE book:p12
```

Explicit negative evidence:

```text
@c2 claim
VALUE NOT safe compoundX
SOURCE paper:B
```

Metadata lines other than `VALUE` are kept as source metadata.

## `all`: conjunction / join

```text
@grandparent all
GIVES ?x ?y
MATCH parent ?x ?middle
MATCH parent ?middle ?y
```

Variables not listed by `GIVES` are local existential variables and are alpha-renamed at each call.

## `any`: alternatives / union

```text
@carer any
GIVES ?x ?y
MATCH parent ?x ?y
MATCH guardian ?x ?y
```

For a complex branch, create an `all` wire and reference it from the `any` wire. This keeps the circuit itself as the expression tree.

```text
@adultParent all
GIVES ?x ?y
MATCH parent ?x ?y
MATCH age ?x ?age
TEST ?age >= 18

@adultGuardian all
GIVES ?x ?y
MATCH guardian ?x ?y
MATCH age ?x ?age
TEST ?age >= 18

@adultCarer any
GIVES ?x ?y
USE $adultParent ?x ?y
USE $adultGuardian ?x ?y
```

`MATCH` and `USE` are semantically the same kind of binding-producing condition at runtime; the separate words improve readability.

## Rules

```text
@r1 rule
WHEN $grandparent ?x ?y
AND alive ?x
THEN livingGrandparent ?x ?y
```

Simple OR is supported:

```text
@r2 rule
WHEN parent ?x ?y
AND active ?x
OR guardian ?x ?y
THEN carer ?x ?y
```

Its meaning is:

```text
(parent ?x ?y AND active ?x) OR guardian ?x ?y
```

For deeper Boolean structure, use named `all`/`any` wires instead of relying on precedence rules.

## Tests / constraints

```text
TEST ?age >= 18
TEST ?x != ?y
```

Built-in infix operators are `=`, `==`, `!=`, `<`, `<=`, `>`, `>=`.

A named builtin can also be used:

```text
TEST includes ?text science
```

## `NONE`: absence

```text
@eligible rule
WHEN person ?x
NONE blocked ?x
THEN eligible ?x
```

`NONE` is not explicit falsity. It is a not-exists check and is subject to stratified-negation rules.

## Aggregate wires

```text
@children all
GIVES ?parent ?child
MATCH parent ?parent ?child

@childCount reduce
GIVES ?parent ?count
FROM $children ?parent ?child
GROUP ?parent
COUNT ?child AS ?count
```

Supported reducers are currently `COUNT`, `SUM`, `MIN`, `MAX`, `COLLECT`, `SET`, `FIRST`.

A reduce wire is referenced like any other relation:

```text
WHERE $childCount Ana ?n
```

## Binding providers

```text
@q goal
CALL range 1 10 ?n
TEST ?n >= 8
FIND ?n
```

`CALL` is an extension point. Provider semantics are registered in JavaScript.

## Goals

```text
@q goal
WHERE grandparent ?who Maria
FIND ?who
```

Multiple `FIND` variables are allowed.

## Transitions

```text
@move transition
WHEN at ?robot ?from
AND road ?from ?to
REMOVE at ?robot ?from
ADD at ?robot ?to
COST 1
```

Transitions are consumed by the planner, not by fixed-point materialization.

## Assumptions

```text
@a1 assumption
VALUE cough patient
COST 1
```

Assumptions are candidate premises used by the current bounded abductive search.

## Recommended style

Prefer several small named wires over a deeply nested Boolean condition. This keeps SOP close to SSA/dataflow form, exposes reusable abstractions to learning, and makes provenance and profiling easier.
