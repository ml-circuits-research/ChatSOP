# Abstraction learning and self-improving reasoning

This is the main long-term experiment that should not be lost as the project evolves.

## 1. Target capability

The system should eventually learn reusable reasoning structures from its own solved problems.

The intended loop is:

```text
solve tasks
   ↓
collect proof/search traces
   ↓
canonicalize variable names and local structure
   ↓
find repeated / expensive subgraphs
   ↓
anti-unify or synthesize candidate abstraction
   ↓
validate on independent tasks and counterexamples
   ↓
install as reusable rule/wire/provider
   ↓
measure future cost and generalization
```

The goal is not merely compression. A useful abstraction should improve later reasoning.

## 2. Levels of learned abstraction

### Level A — learned relation/rule

Example: infer transitive ancestor logic from examples.

Representation remains ordinary SOP rules.

### Level B — learned named circuit

A repeated multi-step proof fragment becomes an `all`/`any` circuit with a stable interface.

This reduces representation duplication and creates a reusable concept.

### Level C — learned macro/search heuristic

The abstraction does not change semantics but changes scheduling: preferred goals, join order, branch order, cached subgoals, admissible heuristic, etc.

### Level D — learned specialized wire

A recurring pattern is implemented by a dedicated algorithm while preserving the relation interface.

Example: recursive reachability compiled to graph closure.

### Level E — learned external solver selection

The system recognizes a subproblem as belonging to a solver family and delegates it through a provider, e.g. SMT, shortest path, matching, linear optimization.

## 3. Candidate discovery from proof DAGs

For each proof DAG:

1. Normalize variable names (`?v0`, `?v1`, ...).
2. Normalize commutative branches where semantics allows it.
3. Record semantic operators, relation signatures and dependency structure.
4. Mine repeated connected subgraphs or frequent path motifs.
5. Compute cost statistics: frequency, average expansions, candidate rows, wall time.
6. Prefer motifs that are frequent *and* expensive.

Exact repeated subgraphs are only the first baseline. The important later mechanism is **anti-unification**: discover a common generalized pattern behind structurally similar proofs.

## 4. Candidate validation

A learned abstraction must not be installed because it compresses training traces.

Validation should include:

- independent micro-worlds;
- positive and negative examples;
- adversarial counterexamples;
- larger structural depth than training;
- distractor relations;
- explicit contradictions where relevant;
- comparison with the original uncompressed program.

The new component must either preserve answer semantics or be explicitly labeled approximate.

## 5. Compilation choice

For every candidate abstraction, compare at least:

```text
A. keep original proof/rules
B. install reusable SOP rule/wire
C. implement specialized provider/algorithm
```

Choose based on measured trade-offs, not aesthetics.

Relevant measures:

```text
answer equivalence
generalization
representation size
proof depth
candidate rows
unifications
rule firings
search expansions
memory
wall time
provenance quality
```

## 6. Avoiding pathological abstractions

Reject or penalize abstractions that:

- simply memorize constants from training worlds;
- hide assumptions/provenance;
- improve one workload while exploding another common workload;
- require unsafe negative recursion;
- are equivalent to a very small existing primitive;
- depend on accidental ordering;
- cannot survive alpha-renaming;
- cannot be validated outside their discovery traces.

## 7. LLM role

An LLM can help propose names, interfaces and generalized hypotheses for repeated patterns. It should not be the sole validator.

Useful teacher outputs are:

```text
candidate abstraction
positive micro-worlds
negative micro-worlds
edge cases
counterexamples
expected invariants
possible specialized algorithm
```

The symbolic harness should decide whether the candidate survives the tests.

## 8. First implementation experiment

A concrete next milestone:

1. Generate many graph/family/taxonomy tasks.
2. Solve them using generic recursive rules.
3. Export proof DAGs.
4. Canonicalize and count recurring subgraphs.
5. Synthesize named wires from frequent fragments.
6. Re-run held-out tasks.
7. Measure proof expansion and symbolic cost before/after.
8. For reachability-like motifs, compare a specialized graph wire.

This gives a progression from simple proof compression to algorithm discovery without changing the research harness.
