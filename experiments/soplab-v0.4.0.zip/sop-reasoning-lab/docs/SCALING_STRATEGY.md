# Scaling strategy for large knowledge bases

The current in-memory implementation is deliberately small. The long-term target may contain millions of facts, learned rules and procedural circuits. At that scale the system must not scan or globally rematerialize the entire KB for every query.

## 1. Query principle

A query should drive a **relevance cone** through the dependency graph.

```text
goal
 ↓
relation/wire dependency slice
 ↓
indexed candidate retrieval
 ↓
demand-driven/table-aware evaluation
 ↓
only necessary derived relations
```

The current `sliced` mode is only a first approximation: it selects relevant rule families but still materializes their subprogram.

## 2. Required indexes

Likely indexes include:

```text
relation + sign + arity
grounded argument positions
rule head relation
rule body dependencies
wire dependencies
source/time/world scopes
proof-to-source/proof-to-rule
learned abstraction usage
```

A cost model should eventually exploit selectivity statistics.

## 3. Materialization choices

Not every relation should be treated the same.

Candidate policies:

```text
fully materialized          stable high-use relations
incrementally maintained    changing but frequently queried relations
memoized/table-generated    recursive/query-dependent relations
on-demand                   rare or expensive derived relations
external/provider-backed    solver/database-owned relations
```

The correct policy should be measurable per workload.

## 4. Persistence

A persistent implementation should separate immutable/content-addressed base knowledge from mutable indexes and caches where possible.

This supports:

- reproducible snapshots;
- cheap forks/branches;
- provenance retention;
- sharing a common base KB across agents/sessions;
- experimental comparison against identical knowledge versions.

## 5. Forkable worlds/projects

A useful architecture is:

```text
base knowledge snapshot
       ├── project/book fork A
       ├── project/book fork B
       └── agent/session fork C
```

Forks should share unchanged structures and store deltas locally.

This is compatible with counterfactual worlds and with the user's broader requirement that procedural knowledge can be reused while each analyzed document/project evolves independently.

## 6. Incremental learning

Adding a fact/rule should ideally invalidate only affected cached/materialized results.

Future strategies to compare:

- dependency-directed invalidation;
- RETE-like networks;
- differential dataflow;
- incremental Datalog;
- event-sourced recomputation;
- snapshot + delta layers.

## 7. Provenance at scale

Full proof trees can be enormous. Preserve a compact proof DAG and references to shared subproofs.

Experiments should measure:

```text
proof storage per derived claim
shared-subproof compression
explanation reconstruction time
impact of provenance on evaluation cost
```

Provenance should not simply be disabled for performance without measuring what research capability is lost.

## 8. Specialized indexes/wires

The graph-wire experiment demonstrates why some relations may deserve specialized physical representations.

A future query planner may choose among:

```text
generic relational rules
graph index
SMT solver
SQL engine
vector index
precompiled specialized wire
```

while preserving a common binding/evidence interface.

## 9. Memory management and forgetting

If the KB becomes a long-lived agent memory, forgetting should be treated separately from logical truth.

Possible targets include:

- dropping caches/materializations first;
- compressing old proof detail while retaining source references;
- usage/age-based eviction of derived abstractions;
- keeping immutable source knowledge but rebuilding derived layers;
- experimental integration with alternative memory stores.

Any forgetting policy should preserve enough metadata to distinguish "false" from "no longer stored/retrievable".

## 10. Scale benchmarks to add

At minimum:

```text
10^4 / 10^5 / 10^6 base facts
selective versus broad queries
recursive closure with sparse/dense graphs
incremental single-fact update
batch updates
fork creation and divergent updates
provenance-heavy queries
mixed provider + relational workloads
```

Report memory, symbolic work, latency and update cost separately.
