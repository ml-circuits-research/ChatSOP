# Experiment roadmap

The roadmap is organized by scientific dependency. Later stages should not be interpreted strongly unless earlier semantic baselines are stable.

## Stage 0 — Semantic regression baseline

Already present.

Objectives:

- unification and joins;
- recursion/fixed point;
- `NOT` versus `NONE`;
- stratified negation;
- aggregation;
- provenance;
- custom providers/wires/materializers;
- planning and abduction baselines;
- randomized closure property tests.

Exit condition: independent reference implementations agree on bundled semantics.

## Stage 1 — Evaluation strategy comparisons

Compare without changing representation:

```text
naive fixed point
delta/semi-naive
backward slicing
tabling / demand driven
magic sets
RETE-like incremental network
differential/incremental dataflow
```

Primary measures: answer equivalence, candidate rows, unifications, facts derived, memory and update cost.

## Stage 2 — Specialized wire experiments

For each domain, compare:

```text
ordinary SOP rules
specialized SOP wire
external provider/solver
```

Priority candidates:

1. graph closure / shortest path;
2. finite-domain/SMT constraints;
3. temporal intervals;
4. sequence/procedural reasoning;
5. world/choice/counterfactual branching;
6. causal intervention;
7. set/reduce-heavy problems;
8. semantic retrieval.

Do not add a permanent primitive unless experiments justify it.

## Stage 3 — Learning rules from LLM-generated micro-worlds

Teacher LLM produces:

- candidate facts/rules;
- several independent worlds;
- positive examples;
- negative examples;
- depth extrapolation cases;
- counterexamples.

Vary:

```text
world count
noise
distractor density
candidate grammar size
structural depth
teacher model
```

Measure held-out rule accuracy/rank, not training fit.

## Stage 4 — Proof abstraction learning

Implement the pipeline in `ABSTRACTION_LEARNING.md`.

Start with exact canonical subgraph repetition, then anti-unification.

Critical result: learned abstractions should reduce cost on unseen tasks while preserving semantics.

## Stage 5 — Learned algorithmic specialization

Detect abstractions where generic symbolic execution is consistently expensive.

Candidates can be mapped to known algorithm families or synthesized code/providers.

Compare generic versus compiled form under identical tasks.

The important question is whether the system can *learn when a shortcut is valid and useful*.

## Stage 6 — Mixed reasoning tasks

Construct tasks that require more than one family:

```text
deduction + aggregation
deduction + SMT
abduction + planning
retrieval + contradiction handling
counterfactual + optimization
temporal + causal
```

This tests whether the common IR gives compositional benefits instead of merely hosting isolated solvers.

## Stage 7 — Knowledge ingestion from books/manuals

Large LLM ingests a document and creates SOP knowledge plus validation curriculum.

Evaluate separately:

- extraction fidelity;
- rule correctness;
- coverage;
- contradiction preservation;
- query answer correctness;
- depth/generalization;
- ability to update/fork knowledge.

Do not conflate extraction quality with reasoning quality.

## Stage 8 — Large persistent KB

Scale toward millions of facts/rules.

Topics:

```text
persistent indexes
incremental updates
sharding
provenance compression
proof cache
query planning
forgetting / memory management
forkable worlds/projects
```

At this stage compare against database/Datalog engines, not only toy scripts.

## Stage 9 — Cross-domain transfer

The strongest test: an abstraction learned in one task family should improve another task family with the same latent reasoning structure.

Examples:

- reachability learned on graphs transferred to dependencies or genealogy;
- ordering abstractions transferred from procedures to temporal reasoning;
- constraint motifs transferred across scheduling/configuration tasks.

Cross-domain transfer would be stronger evidence than compression within one benchmark family.
