# Open research questions

Keep this list active. When an item becomes settled, move the conclusion to `DESIGN_DECISIONS.md` and preserve the experiment/result that justified it.

## Representation

- Are relations of bindings sufficient for the important intermediate states of analogical, causal and probabilistic reasoning?
- When should collections/sets become first-class rather than aggregate outputs?
- Is first-class `world`/`scope` necessary, or can it remain an ordinary relation dimension?
- Do temporal intervals need dedicated semantics?
- How should existentially created entities be represented without losing termination guarantees?

## Evaluation

- At what KB size does fixed-point materialization stop being competitive with demand-driven/tabling approaches?
- Can one cost model select join order, materializer and specialized wire automatically?
- Which results should be materialized/cached versus computed on demand?
- Can proof provenance be compressed without losing useful explanation structure?

## Learning

- Can repeated proof DAGs produce useful abstractions through anti-unification?
- Can the system distinguish a useful semantic concept from an optimization-only macro?
- Can it learn when to compile a circuit into a graph/SMT/other algorithm?
- Can learned abstractions transfer across relation names and domains?
- What curriculum best forces recursion, invariance and compositionality?

## LLM teacher

- Should the LLM emit rules directly, or mostly generate micro-worlds/tests from which rules are induced?
- How many independent worlds are needed for robust validation?
- How should contradictory teacher outputs be retained and resolved?
- Can smaller models reliably translate queries into SOP once the symbolic vocabulary stabilizes?

## Reasoning semantics

- How should defeasible/default reasoning interact with explicit contradiction?
- Are stable-model semantics ever needed, or is stratified negation enough for target workloads?
- How should uncertainty/confidence combine across proof paths?
- What is the minimal causal semantics needed for useful intervention/counterfactual queries?

## Scaling

- How should millions of facts and learned rules be indexed and persisted?
- How should forkable KBs/worlds share structure efficiently?
- How do forgetting and memory pressure interact with provenance and learned abstractions?
- What update algorithm supports continuous learning without global recomputation?
