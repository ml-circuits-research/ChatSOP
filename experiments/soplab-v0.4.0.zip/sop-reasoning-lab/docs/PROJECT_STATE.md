# Project state — v0.4.0

This file is a snapshot. It distinguishes **implemented**, **experimentally demonstrated**, **hypothesized**, and **not yet designed** capabilities.

## Implemented and covered by tests

- ground claims and variables;
- unification;
- indexed relation lookup;
- positive recursive rules and fixed-point materialization;
- naive and delta materialization strategies;
- backward predicate slicing;
- explicit positive/negative support with local contradiction;
- stratified `NONE` and rejection of negative recursion cycles;
- named `all` and `any` relation wires;
- `reduce` aggregation wires;
- built-in deterministic tests;
- external binding providers;
- pluggable wire types;
- pluggable materializers;
- proof/provenance DAG export;
- best-first transition planning baseline;
- bounded minimum-cost abduction baseline;
- small path-rule induction harness;
- SOP/CNL parser and CLI;
- randomized graph closure property tests;
- common symbolic metrics and comparison helpers.

## Demonstrated by bundled experiments

### Recursive abstraction

Recursive reachability extrapolates beyond training depths where a finite path-unrolling baseline fails.

### Independent micro-worlds

The current synthetic learner can recover a hidden compositional path rule under controlled noise, and independent worlds reduce spurious fits in the bundled setting.

### Specialized wire leverage

A specialized graph-closure wire returns the same bundled reachability answers as recursive rules with far fewer symbolic operations.

### Evaluation strategy leverage

Delta evaluation reduces candidate-row work relative to naive repeated evaluation on the bundled recursive workload. Backward slicing avoids irrelevant rule families.

These are **baseline observations**, not universal performance claims.

## Hypothesized but not yet implemented

- proof-DAG anti-unification;
- automatic discovery of reusable named circuits;
- automatic compilation of circuits into specialized algorithms;
- learned solver/wire selection;
- demand-driven tabling/magic sets;
- first-class hypothetical worlds;
- stable-model/default/non-monotonic semantics beyond stratification;
- temporal wire semantics;
- causal/intervention semantics;
- probabilistic evidence combination;
- analogical structure mapping;
- SMT/CSP provider baseline;
- semantic/vector retrieval provider baseline;
- LLM document-ingestion curriculum;
- persistent million-scale KB;
- incremental continuous-learning updates;
- forkable persistent KB/world storage.

## Conceptual minimal vocabulary versus current surface vocabulary

The early conceptual decomposition was roughly:

```text
claim
rule
goal
constraint
choice
reduce
fix
```

The current implementation makes some of these operational rather than syntactic primitives:

```text
claim          -> first-class block
rule           -> first-class block
goal           -> first-class block
constraint     -> TEST / provider / conditions
choice          -> any wire or external search; first-class world choice not frozen
reduce          -> first-class wire
fix             -> materialization strategy, not usually authored as a wire
transition      -> first-class search operator
assumption      -> first-class abductive candidate
all / any       -> named compositional relation wires
```

This mapping is intentional. The project should not preserve an early taxonomy merely because it was proposed first.

## Current highest-value next steps

1. **Proof abstraction mining** — canonicalize proof DAGs and mine repeated structures.
2. **Demand-driven evaluation** — tabled/top-down or magic-set strategy versus current fixed-point baselines.
3. **SMT provider experiment** — test the binding-producer boundary on constraints that are inefficient to enumerate relationally.
4. **Automatic abstraction validation** — independent worlds + counterexamples + depth extrapolation.
5. **Algorithmic compilation** — test whether a discovered pattern can safely become a specialized wire/provider.
6. **Mixed reasoning benchmark** — combine deduction, constraints, abduction/planning and aggregates in the same task.

## Strong claim that is *not* yet justified

The repository does **not** yet demonstrate a universal reasoning engine or autonomous algorithm discovery.

What it currently demonstrates is a credible experimental substrate for testing the narrower hypothesis that heterogeneous reasoning methods can share a compact binding/provenance IR and that specialized abstractions can be compared under one semantic harness.
