# Documentation map

Read these documents in roughly this order.

## Start here

1. [`RESEARCH_HYPOTHESIS.md`](RESEARCH_HYPOTHESIS.md) — what the project is trying to discover and what would falsify the main hypotheses.
2. [`ARCHITECTURE.md`](ARCHITECTURE.md) — implementation architecture and extension boundaries.
3. [`SEMANTIC_MODEL.md`](SEMANTIC_MODEL.md) — exact conceptual meaning of bindings, conditions, rules, negation, providers and search.
4. [`CNL.md`](CNL.md) — current SOP surface syntax.
5. [`PROJECT_STATE.md`](PROJECT_STATE.md) — exact snapshot of implemented vs hypothesized capabilities.

## Running research

6. [`RESEARCH_PROTOCOL.md`](RESEARCH_PROTOCOL.md) — mandatory discipline for future experiments.
7. [`COMPARISON_PROTOCOL.md`](COMPARISON_PROTOCOL.md) — controlled strategy/wire comparisons.
8. [`EXPERIMENTS.md`](EXPERIMENTS.md) — experiments already included.
9. [`EXPERIMENT_ROADMAP.md`](EXPERIMENT_ROADMAP.md) — staged future program.
10. [`BASELINE_RESULTS.md`](BASELINE_RESULTS.md) — current observations that future versions should be able to reproduce or explain.

## Extending the architecture

11. [`EXTENDING.md`](EXTENDING.md) — APIs for providers, wires, materializers and builtins.
12. [`WIRE_IDEAS.md`](WIRE_IDEAS.md) — candidate future semantic components and baselines.
13. [`ABSTRACTION_LEARNING.md`](ABSTRACTION_LEARNING.md) — target loop for learning reusable concepts and algorithmic shortcuts from proofs.
14. [`REASONING_MAP.md`](REASONING_MAP.md) — how reasoning families map onto the common IR.
15. [`KNOWLEDGE_INGESTION.md`](KNOWLEDGE_INGESTION.md) — book/manual → SOP knowledge + validation curriculum.
16. [`SCALING_STRATEGY.md`](SCALING_STRATEGY.md) — million-scale KB, demand-driven evaluation, persistence and forks.

## Guardrails

17. [`DESIGN_DECISIONS.md`](DESIGN_DECISIONS.md) — intentional choices and non-decisions.
18. [`LIMITATIONS.md`](LIMITATIONS.md) — what the current baseline does not solve.
19. [`OPEN_QUESTIONS.md`](OPEN_QUESTIONS.md) — unresolved research questions that should remain visible.
20. [`GLOSSARY.md`](GLOSSARY.md) — terminology.

The project is a **research harness**, not a frozen final architecture. A future implementation may reverse any design choice, but should preserve the experiment, counterexample or measurement that motivated the change.
