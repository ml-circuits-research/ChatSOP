# Project manifest

Version: 0.4.0
Runtime: Node.js >= 20, ESM, no runtime dependencies.

Validation at packaging time:

```text
npm run verify
23 tests passed
family CNL example passed
planning CNL example passed
abduction CNL example passed
```

Main directories:

```text
src/          reusable implementation
bin/          CLI and benchmark commands
examples/     CNL and JavaScript usage examples
benchmarks/   reusable workload builders
experiments/  reproducible research experiments
test/         unit, integration and randomized property tests
docs/         architecture, CNL, limitations and comparison protocol
results/      baseline snapshots generated from the experiments
```

The primary starting point is `docs/README.md`.

Research-preservation documents added in v0.4.0 include:

```text
docs/RESEARCH_HYPOTHESIS.md
docs/SEMANTIC_MODEL.md
docs/PROJECT_STATE.md
docs/ABSTRACTION_LEARNING.md
docs/EXPERIMENT_ROADMAP.md
docs/RESEARCH_PROTOCOL.md
docs/DESIGN_DECISIONS.md
docs/OPEN_QUESTIONS.md
docs/GLOSSARY.md
docs/KNOWLEDGE_INGESTION.md
docs/SCALING_STRATEGY.md
benchmarks/README.md
experiments/README.md
results/RESULT_SCHEMA.md
```
