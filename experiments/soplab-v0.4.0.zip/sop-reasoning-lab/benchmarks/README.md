# Benchmark contract

Benchmark workloads should be deterministic from explicit parameters and seed.

Each workload should expose enough information to create a **fresh** reasoner for every variant. Never share a store that already contains derived claims between variants.

A useful workload returns or records:

```text
name
seed
parameters
base knowledge
rules/wires/providers
goal
independent oracle when available
```

When extending this directory, preserve old workload names/parameters so historical result files remain reproducible.

See `docs/COMPARISON_PROTOCOL.md` and `docs/RESEARCH_PROTOCOL.md`.
