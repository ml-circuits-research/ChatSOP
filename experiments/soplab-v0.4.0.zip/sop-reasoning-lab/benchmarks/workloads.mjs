import { Reasoner, atom, rule } from '../src/index.mjs';

export function graphClosureWorkload({ nodes = 80, fanout = 2, irrelevantRules = 0 } = {}) {
  const r = new Reasoner();
  for (let i = 0; i < nodes; i++) {
    for (let j = 1; j <= fanout; j++) {
      const to = i + j;
      if (to < nodes) r.fact(atom('edge', `n${i}`, `n${to}`));
    }
  }
  r.addRules([
    rule('reach.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
    rule('reach.rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
  ]);
  for (let i = 0; i < irrelevantRules; i++) {
    r.fact(atom(`noise${i}`, `v${i}`));
    r.addRule(rule(`noise.rule.${i}`, atom(`noiseDerived${i}`, '?x'), [atom(`noise${i}`, '?x')]));
  }
  return { reasoner: r, goal: atom('reach', 'n0', `n${nodes - 1}`) };
}

export function chainWorkload(depth = 20) {
  const r = new Reasoner();
  for (let i = 0; i < depth; i++) r.fact(atom('edge', `n${i}`, `n${i + 1}`));
  r.addRules([
    rule('reach.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
    rule('reach.rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
  ]);
  return { reasoner: r, goal: atom('reach', 'n0', `n${depth}`) };
}
