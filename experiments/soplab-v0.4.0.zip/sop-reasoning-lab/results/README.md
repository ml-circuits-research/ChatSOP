# Baseline results

These files are snapshots produced by the bundled experiments. They are included to make later regressions and strategy comparisons easier.

- `baseline.json`: machine-readable functional/strategy baseline plus environment metadata.
- `recursion-depth.txt`: recursive abstraction versus a path representation bounded to depth three.
- `graph-wire-vs-rules.txt`: same reachability answers using recursive rules versus a specialized graph wire.
- `noise-microworlds.txt`: rank of a hidden relational rule under independent micro-worlds and label noise.
- `benchmark-current.txt`: wall-clock and symbolic metrics from the packaging environment.

Only deterministic answer equivalence and symbolic operation counts should be treated as portable. Wall-clock timings must be regenerated on the target machine.
