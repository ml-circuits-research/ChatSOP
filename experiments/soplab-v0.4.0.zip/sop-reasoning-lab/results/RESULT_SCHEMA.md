# Result record schema

Recommended JSON shape for future experiments:

```json
{
  "schemaVersion": 1,
  "projectVersion": "0.4.0",
  "experiment": "name",
  "variant": "candidate",
  "hypothesis": "short identifier",
  "workload": {
    "name": "reachability",
    "seed": 123,
    "parameters": {}
  },
  "semantics": {
    "referenceVariant": "baseline",
    "answerEquivalent": true,
    "answerSignature": []
  },
  "metrics": {},
  "learning": {},
  "environment": {
    "node": "...",
    "platform": "...",
    "arch": "..."
  },
  "notes": ""
}
```

Not every experiment uses every field. Add fields rather than repurposing an existing field with a different meaning.

For LLM-assisted experiments add a `teacher` object containing model identifier, prompt/template version, generation parameters where available, and a reference/hash for generated artifacts.
