import test from 'node:test';
import assert from 'node:assert/strict';
import { Reasoner, atom, rule, seededRandom } from '../src/index.mjs';

function closure(edges, n) {
  const reach = Array.from({ length: n }, () => Array(n).fill(false));
  for (const [a, b] of edges) reach[a][b] = true;
  for (let k = 0; k < n; k++) for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) reach[i][j] ||= reach[i][k] && reach[k][j];
  return reach;
}

test('recursive engine matches graph transitive closure across seeded random worlds', () => {
  for (let seed = 1; seed <= 12; seed++) {
    const rnd = seededRandom(seed);
    const n = 8;
    const edges = [];
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (i !== j && rnd() < 0.16) edges.push([i, j]);
    const expected = closure(edges, n);
    const r = new Reasoner();
    r.facts(edges.map(([a, b]) => atom('edge', `n${a}`, `n${b}`)));
    r.addRules([
      rule('r.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
      rule('r.rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
    ]).saturate({ strategy: 'delta' });
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      assert.equal(r.ask(atom('reach', `n${i}`, `n${j}`)).status === 'supported', expected[i][j], `seed=${seed} ${i}->${j}`);
    }
  }
});
