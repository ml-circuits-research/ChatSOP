import test from 'node:test';
import assert from 'node:assert/strict';
import {
  Reasoner, atom, not, rule, builtin, condition, all, any, ref, reduction,
} from '../src/index.mjs';

test('naive and delta materialization agree on recursive closure', () => {
  const build = () => new Reasoner()
    .facts([atom('edge', 'a', 'b'), atom('edge', 'b', 'c'), atom('edge', 'c', 'd')])
    .addRules([
      rule('reach.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
      rule('reach.rec', atom('reach', '?x', '?y'), [atom('edge', '?x', '?z'), atom('reach', '?z', '?y')]),
    ]);
  const a = build(); a.saturate({ strategy: 'naive' });
  const b = build(); b.saturate({ strategy: 'delta' });
  const qa = a.query(atom('reach', '?x', '?y')).map((x) => JSON.stringify(x.bindings)).sort();
  const qb = b.query(atom('reach', '?x', '?y')).map((x) => JSON.stringify(x.bindings)).sort();
  assert.deepEqual(qb, qa);
  assert.equal(b.ask(atom('reach', 'a', 'd')).status, 'supported');
});

test('four-valued evidence keeps contradiction local', () => {
  const r = new Reasoner();
  r.fact(atom('safe', 'x'), { kind: 'source', source: 'A' });
  r.fact(not('safe', 'x'), { kind: 'source', source: 'B' });
  assert.equal(r.ask(atom('safe', 'x')).status, 'conflicting');
  assert.equal(r.ask(atom('safe', 'y')).status, 'unknown');
});

test('condition wires compose AND, OR and local existential variables', () => {
  const r = new Reasoner();
  r.facts([
    atom('parent', 'Ana', 'Bob'), atom('parent', 'Bob', 'Cara'),
    atom('guardian', 'Dan', 'Eva'), atom('active', 'Ana'), atom('active', 'Dan'),
  ]);
  r.addWire(condition('grandparent', 'all', ['?x', '?y'], [
    atom('parent', '?x', '?middle'), atom('parent', '?middle', '?y'),
  ]));
  r.addWire(condition('carer', 'any', ['?x', '?y'], [
    atom('parent', '?x', '?y'), atom('guardian', '?x', '?y'),
  ]));
  r.addRule(rule('responsible', atom('responsible', '?x', '?y'), all(ref('carer', '?x', '?y'), atom('active', '?x'))));
  r.saturate();
  assert.equal(r.query(ref('grandparent', '?g', 'Cara'), { select: ['?g'] })[0].bindings['?g'], 'Ana');
  assert.equal(r.ask(atom('responsible', 'Ana', 'Bob')).status, 'supported');
  assert.equal(r.ask(atom('responsible', 'Dan', 'Eva')).status, 'supported');
});

test('reduce wire is a first-class relation', () => {
  const r = new Reasoner();
  r.facts([atom('parent', 'A', 'c1'), atom('parent', 'A', 'c2'), atom('parent', 'B', 'c3')]);
  r.addWire(reduction('childCount', {
    params: ['?parent', '?count'],
    source: atom('parent', '?parent', '?child'),
    groupBy: ['?parent'],
    aggregates: [{ op: 'count', field: '?child', as: '?count' }],
  }));
  const rows = r.query(ref('childCount', '?p', '?n'), { select: ['?p', '?n'] }).map((x) => x.bindings).sort((a, b) => a['?p'].localeCompare(b['?p']));
  assert.deepEqual(rows, [{ '?p': 'A', '?n': 2 }, { '?p': 'B', '?n': 1 }]);
  assert.equal(r.query(ref('childCount', 'A', '?n'), { select: ['?n'] })[0].bindings['?n'], 2);
});

test('builtin equality can bind a variable', () => {
  const r = new Reasoner();
  const rows = r.query(builtin('eq', '?x', 42), { select: ['?x'] });
  assert.equal(rows[0].bindings['?x'], 42);
});
