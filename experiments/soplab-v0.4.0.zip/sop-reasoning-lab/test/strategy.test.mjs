import test from 'node:test';
import assert from 'node:assert/strict';
import { Reasoner, atom, rule, none, all } from '../src/index.mjs';

function buildWithNoise() {
  const r = new Reasoner();
  r.facts([atom('edge', 'a', 'b'), atom('edge', 'b', 'c')]);
  r.addRules([
    rule('reach.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
    rule('reach.rec', atom('reach', '?x', '?y'), [atom('edge', '?x', '?z'), atom('reach', '?z', '?y')]),
  ]);
  for (let i = 0; i < 40; i++) {
    r.fact(atom('noise', `x${i}`, `y${i}`));
    r.addRule(rule(`noise.${i}`, atom(`derived${i}`, '?x'), [atom('noise', '?x', '?y')]));
  }
  return r;
}

test('sliced evaluation selects only backward-relevant rules', () => {
  const r = buildWithNoise();
  const sliced = r.evaluate(atom('reach', 'a', '?y'), { scope: 'sliced', strategy: 'delta', select: ['?y'] });
  const global = r.evaluate(atom('reach', 'a', '?y'), { scope: 'global', strategy: 'delta', select: ['?y'] });
  assert.deepEqual(sliced.rows.map((x) => x.bindings['?y']).sort(), global.rows.map((x) => x.bindings['?y']).sort());
  assert.deepEqual(sliced.selectedRules.sort(), ['reach.base', 'reach.rec']);
  assert.ok(sliced.metrics.ruleFirings < global.metrics.ruleFirings);
});

test('argument indexes reduce relation candidates for grounded positions', () => {
  const r = new Reasoner();
  for (let i = 0; i < 100; i++) r.fact(atom('row', `k${i}`, i));
  r.metrics.counters.clear();
  const rows = r.query(atom('row', 'k77', '?v'));
  assert.equal(rows[0].bindings['?v'], 77);
  assert.equal(r.metrics.get('candidateRows'), 1);
});

test('proofs can be exported as an explanation DAG and DOT', () => {
  const r = new Reasoner();
  r.facts([atom('parent', 'A', 'B'), atom('parent', 'B', 'C')]);
  r.addRule(rule('gp', atom('grandparent', '?x', '?y'), [atom('parent', '?x', '?z'), atom('parent', '?z', '?y')])).saturate();
  const e = r.explain(atom('grandparent', 'A', 'C'));
  assert.equal(e.proofs[0].ruleId, 'gp');
  const dot = r.explainDOT(atom('grandparent', 'A', 'C'));
  assert.match(dot, /digraph Proof/);
  assert.match(dot, /gp/);
});

test('NONE uses stratified negation so later positive derivations do not leave stale conclusions', () => {
  const r = new Reasoner();
  r.facts([atom('person', 'A'), atom('person', 'B'), atom('rawBlocked', 'A')]);
  // Deliberately add the negative rule first; stratification must still evaluate blocked before eligible.
  r.addRule(rule('eligible', atom('eligible', '?x'), all(atom('person', '?x'), none(atom('blocked', '?x')))));
  r.addRule(rule('blocked', atom('blocked', '?x'), [atom('rawBlocked', '?x')]));
  r.saturate({ strategy: 'delta' });
  assert.equal(r.ask(atom('eligible', 'A')).status, 'unknown');
  assert.equal(r.ask(atom('eligible', 'B')).status, 'supported');
});

test('negative recursive cycles are rejected as non-stratifiable', () => {
  const r = new Reasoner();
  r.addRule(rule('p', atom('p', '?x'), none(atom('q', '?x'))));
  r.addRule(rule('q', atom('q', '?x'), [atom('p', '?x')]));
  assert.throws(() => r.saturate(), /not stratifiable/i);
});

test('materialization strategies are pluggable', async () => {
  const { materializeNaive } = await import('../src/index.mjs');
  let calls = 0;
  const r = new Reasoner();
  r.fact(atom('edge', 'a', 'b'));
  r.addRule(rule('reach', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]));
  r.registerMaterializer('instrumented', (reasoner, options) => {
    calls++;
    return materializeNaive(reasoner, options);
  });
  const out = r.evaluate(atom('reach', 'a', 'b'), { strategy: 'instrumented', scope: 'sliced' });
  assert.equal(out.rows.length, 1);
  assert.ok(calls >= 1);
});
