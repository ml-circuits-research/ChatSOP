import test from 'node:test';
import assert from 'node:assert/strict';
import { Reasoner, provider, unifyTerms, ref } from '../src/index.mjs';

test('custom providers can produce bindings without kernel changes', () => {
  const r = new Reasoner();
  r.registerProvider('double', function* (args, bindings) {
    const input = args[0];
    const output = args[1];
    for (const n of [1, 2, 3]) {
      let b = unifyTerms(input, n, bindings);
      if (!b) continue;
      b = unifyTerms(output, n * 2, b);
      if (b) yield { bindings: b };
    }
  });
  const rows = r.query(provider('double', '?x', '?y'), { select: ['?x', '?y'] });
  assert.deepEqual(rows.map((x) => x.bindings), [
    { '?x': 1, '?y': 2 }, { '?x': 2, '?y': 4 }, { '?x': 3, '?y': 6 },
  ]);
});

test('new wire types can be registered without modifying the evaluator', () => {
  const r = new Reasoner();
  r.facts([{ kind: 'atom', pred: 'person', args: ['Ana'], sign: 1 }, { kind: 'atom', pred: 'person', args: ['Bob'], sign: 1 }]);
  r.registerWireType('alias', function* ({ def, args, seed, evidence, solve }) {
    const target = { kind: 'atom', pred: def.predicate, args, sign: 1 };
    yield* solve(target, seed, evidence);
  });
  r.addWire({ kind: 'wire', wireType: 'alias', id: 'people', params: ['?x'], predicate: 'person' });
  const rows = r.query(ref('people', '?x'), { select: ['?x'] });
  assert.deepEqual(rows.map((x) => x.bindings['?x']).sort(), ['Ana', 'Bob']);
});
