import test from 'node:test';
import assert from 'node:assert/strict';
import { Reasoner, atom, rule, validateReasoner } from '../src/index.mjs';

test('program validator detects unsafe rule heads', () => {
  const r = new Reasoner();
  r.addRule(rule('unsafe', atom('p', '?x', '?y'), [atom('q', '?x')]));
  const v = validateReasoner(r);
  assert.equal(v.ok, false);
  assert.equal(v.errors[0].code, 'UNSAFE_RULE_HEAD');
});
