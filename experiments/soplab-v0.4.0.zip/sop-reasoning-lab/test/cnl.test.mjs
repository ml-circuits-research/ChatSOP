import test from 'node:test';
import assert from 'node:assert/strict';
import { Reasoner, atom, parseSOP, loadSOP, planParsed, abductParsed } from '../src/index.mjs';

test('CNL parser handles claims, all/any, rules, OR, NONE and goals', () => {
  const text = `
@p1 claim
VALUE parent Ana Bob
@p2 claim
VALUE guardian Dan Bob
@p3 claim
VALUE active Ana
@p4 claim
VALUE blocked Dan

@carer any
GIVES ?x ?y
MATCH parent ?x ?y
MATCH guardian ?x ?y

@r rule
WHEN $carer ?x ?y
AND active ?x
OR guardian ?x ?y
NONE blocked ?x
THEN responsible ?x ?y

@q goal
WHERE responsible ?who Bob
FIND ?who
`;
  const parsed = parseSOP(text);
  const r = loadSOP(new Reasoner(), parsed);
  r.saturate();
  const rows = r.query(parsed.goals[0].where, { select: parsed.goals[0].find });
  assert.deepEqual(rows.map((x) => x.bindings['?who']), ['Ana']);
});

test('CNL reduce wire aggregates without parentheses', () => {
  const text = `
@a claim
VALUE parent Ana Bob
@b claim
VALUE parent Ana Cara
@c claim
VALUE parent Dan Eva

@children all
GIVES ?parent ?child
MATCH parent ?parent ?child

@counts reduce
GIVES ?parent ?count
FROM $children ?parent ?child
GROUP ?parent
COUNT ?child AS ?count

@q goal
WHERE $counts ?p ?n
FIND ?p ?n
`;
  const parsed = parseSOP(text);
  const r = loadSOP(new Reasoner(), parsed);
  const rows = r.query(parsed.goals[0].where, { select: parsed.goals[0].find }).map((x) => x.bindings);
  assert.equal(rows.find((x) => x['?p'] === 'Ana')['?n'], 2);
});

test('CALL invokes a binding provider from CNL', () => {
  const parsed = parseSOP(`
@q goal
CALL range 1 3 ?n
FIND ?n
`);
  const r = loadSOP(new Reasoner(), parsed);
  const rows = r.query(parsed.goals[0].where, { select: parsed.goals[0].find });
  assert.deepEqual(rows.map((x) => x.bindings['?n']), [1, 2, 3]);
});

test('CNL transition blocks can be planned', () => {
  const parsed = parseSOP(`
@f1 claim
VALUE at robot A
@f2 claim
VALUE road A B
@f3 claim
VALUE road B C

@move transition
WHEN at ?who ?from
AND road ?from ?to
REMOVE at ?who ?from
ADD at ?who ?to
COST 1

@goal goal
WHERE at robot C
`);
  const res = planParsed(parsed);
  assert.equal(res.found, true);
  assert.equal(res.path.length, 2);
});

test('CNL assumptions can drive bounded abduction', () => {
  const parsed = parseSOP(`
@f claim
VALUE fever p

@r rule
WHEN fever ?p
AND cough ?p
THEN diagnosis ?p flu

@a1 assumption
VALUE rash p
COST 1
@a2 assumption
VALUE cough p
COST 1

@g goal
WHERE diagnosis p flu
`);
  const res = abductParsed(parsed);
  assert.equal(res.found, true);
  assert.equal(res.assumptions.length, 1);
  assert.equal(res.assumptions[0].atom.pred, 'cough');
});

test('CNL rejects ambiguous nested Boolean syntax inside named all/any wires', () => {
  assert.throws(() => parseSOP(`
@bad all
GIVES ?x
MATCH a ?x
OR b ?x
`), /compose an @\.\.\. any wire/i);
  assert.throws(() => parseSOP(`
@bad any
GIVES ?x
MATCH a ?x
AND b ?x
`), /compose an @\.\.\. all wire/i);
});
