import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generatePathRules, rankRules, makeWorlds,
} from '../src/index.mjs';

test('micro-world learning recovers a hidden compositional relation', () => {
  const candidates = generatePathRules({ relations: ['a', 'b', 'c'], maxBody: 2, includeInverse: true });
  const worlds = makeWorlds({ count: 4, seed: 17, relationA: 'a', relationB: 'b', positives: 5, distractors: 12, labelNoise: 0 });
  const ranked = rankRules(candidates, worlds, { complexityPenalty: 0.0001 });
  assert.equal(ranked[0].rule.id, 'path:a/b');
  assert.equal(ranked[0].accuracy, 1);
});

test('multiple independent micro-worlds remain useful under label noise', () => {
  const candidates = generatePathRules({ relations: ['a', 'b', 'c'], maxBody: 2, includeInverse: true });
  const worlds = makeWorlds({ count: 6, seed: 123, relationA: 'a', relationB: 'b', positives: 8, distractors: 20, labelNoise: 0.1 });
  const ranked = rankRules(candidates, worlds, { complexityPenalty: 0.0001 });
  const hidden = ranked.find((x) => x.rule.id === 'path:a/b');
  assert.ok(hidden);
  assert.ok(hidden.accuracy > 0.8);
  assert.ok(ranked.slice(0, 5).some((x) => x.rule.id === 'path:a/b'));
});
