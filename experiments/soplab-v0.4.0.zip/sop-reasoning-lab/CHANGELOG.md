# Changelog

## 0.4.0 — research-preservation baseline

- Added explicit central research hypothesis and falsification criteria.
- Fixed the conceptual semantic contract for binding producers, evidence, rules, providers, search and learning.
- Documented the full proof-trace → abstraction → validation → compilation loop.
- Added staged experiment roadmap from semantic baseline through persistent KB and cross-domain transfer.
- Added mandatory research protocol, negative-result preservation and result schema.
- Recorded design decisions separately from unresolved research questions.
- Added documentation map, glossary, benchmark contract and experiment authoring guide.
- Clarified that learned semantic abstractions and execution optimizations are different experimental outcomes.


## 0.3.0 — research baseline

- CNL relation syntax without predicate parentheses or commas.
- First-class `all`, `any` and `reduce` wires.
- Explicit `NOT` versus stratified `NONE` semantics.
- Indexed four-valued claim store with provenance and proof DAG export.
- Recursive fixed-point reasoning with `naive` and `delta` materializers.
- Goal-directed rule slicing.
- Pluggable binding providers, wire types and materialization strategies.
- Generic best-first search, transition planning and bounded abduction.
- Micro-world rule-learning experiments.
- Reproducible comparison/benchmark harness and baseline result snapshots.
- CNL/engine/property/learning/search/extension tests.
