import { Reasoner, atom, rule } from '../src/index.mjs';

function chain(depth) {
  return Array.from({ length: depth }, (_, i) => atom('edge', `n${i}`, `n${i + 1}`));
}
function buildRecursive(depth) {
  return new Reasoner().facts(chain(depth)).addRules([
    rule('r.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
    rule('r.rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
  ]);
}
function buildBounded(depth, bound = 3) {
  const r = new Reasoner().facts(chain(depth));
  const vars = ['?x', '?a', '?b', '?c', '?d', '?e', '?f', '?y'];
  for (let len = 1; len <= bound; len++) {
    const body = [];
    for (let i = 0; i < len; i++) body.push(atom('edge', vars[i], vars[i + 1]));
    r.addRule(rule(`bounded.${len}`, atom('reach', '?x', vars[len]), body));
  }
  return r;
}

console.log('depth\trecursive\tbounded<=3');
for (const depth of [1, 2, 3, 4, 6, 10, 20]) {
  const goal = atom('reach', 'n0', `n${depth}`);
  const rec = buildRecursive(depth).evaluate(goal, { scope: 'sliced', strategy: 'delta' }).rows.length > 0;
  const bounded = buildBounded(depth).evaluate(goal, { scope: 'sliced', strategy: 'delta' }).rows.length > 0;
  console.log(`${depth}\t${rec}\t\t${bounded}`);
}
