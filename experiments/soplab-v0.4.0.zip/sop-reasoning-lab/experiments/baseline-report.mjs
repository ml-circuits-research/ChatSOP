import os from 'node:os';
import process from 'node:process';
import { Reasoner, atom, rule, compareVariants } from '../src/index.mjs';
import { graphClosureWorkload } from '../benchmarks/workloads.mjs';

const recursion = [];
for (const depth of [1, 2, 3, 4, 8, 16]) {
  const r = new Reasoner();
  for (let i = 0; i < depth; i++) r.fact(atom('edge', `n${i}`, `n${i + 1}`));
  r.addRules([
    rule('base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
    rule('rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
  ]);
  recursion.push({ depth, supported: r.evaluate(atom('reach', 'n0', `n${depth}`)).rows.length > 0 });
}

const variants = await compareVariants({
  build: () => graphClosureWorkload({ nodes: 35, fanout: 2, irrelevantRules: 15 }),
  variants: [
    { name: 'delta+sliced', strategy: 'delta', scope: 'sliced' },
    { name: 'delta+global', strategy: 'delta', scope: 'global' },
    { name: 'naive+sliced', strategy: 'naive', scope: 'sliced' },
    { name: 'naive+global', strategy: 'naive', scope: 'global' },
  ],
});

const report = {
  schema: 'sop-reasoning-lab-baseline-v1',
  generatedAt: new Date().toISOString(),
  environment: {
    node: process.version,
    platform: process.platform,
    arch: process.arch,
    cpus: os.cpus().length,
  },
  recursion,
  variants: variants.map((v) => ({
    name: v.name,
    matchesReference: v.matchesReference,
    materialization: v.materialization,
    metrics: v.metrics,
    selectedRuleCount: v.selectedRules.length,
  })),
};

console.log(JSON.stringify(report, null, 2));
