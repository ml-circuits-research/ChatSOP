import { graphClosureWorkload } from '../benchmarks/workloads.mjs';

const configs = [
  { strategy: 'delta', scope: 'sliced' },
  { strategy: 'delta', scope: 'global' },
  { strategy: 'naive', scope: 'sliced' },
  { strategy: 'naive', scope: 'global' },
];
for (const cfg of configs) {
  const { reasoner, goal } = graphClosureWorkload({ nodes: 60, fanout: 2, irrelevantRules: 40 });
  const res = reasoner.evaluate(goal, cfg);
  console.log(`\n${cfg.strategy}/${cfg.scope}`);
  console.log('answer:', res.rows.length > 0);
  console.log('selected rules:', res.selectedRules.length);
  console.log('materialization:', res.materialization);
  console.log('metrics:', res.metrics);
}
