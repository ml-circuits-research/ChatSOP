# Experiment authoring guide

Every new experiment should answer a narrow question and preserve enough metadata to be repeated later.

Minimum header to place near the top of an experiment source file:

```text
QUESTION:
HYPOTHESIS:
BASELINE:
VARIABLE CHANGED:
METRICS:
SEED/DATA:
FALSIFICATION CONDITION:
```

Prefer independent oracles and structurally held-out test cases.

For a new reasoning primitive, compare ordinary rules, specialized wire and provider implementation when possible.

For learned abstractions, always include held-out worlds and increased structural depth.

See `docs/RESEARCH_PROTOCOL.md`.
