import { generatePathRules, rankRules, makeWorlds } from '../src/index.mjs';

const candidates = generatePathRules({ relations: ['a', 'b', 'c', 'd'], maxBody: 2, includeInverse: true });
const trials = 12;
console.log('worlds\tnoise\ttop1 hidden\tmean rank');
for (const worldsCount of [1, 2, 3, 5]) {
  for (const noise of [0, 0.1, 0.2, 0.3]) {
    let top1 = 0, rankSum = 0;
    for (let t = 0; t < trials; t++) {
      const worlds = makeWorlds({ count: worldsCount, seed: 1000 + t * 37, relationA: 'a', relationB: 'b', positives: 6, distractors: 18, labelNoise: noise });
      const ranked = rankRules(candidates, worlds, { complexityPenalty: 0.0001 });
      const rank = ranked.findIndex((x) => x.rule.id === 'path:a/b') + 1;
      if (rank === 1) top1++;
      rankSum += rank;
    }
    console.log(`${worldsCount}\t${noise.toFixed(1)}\t${top1}/${trials}\t\t${(rankSum / trials).toFixed(2)}`);
  }
}
