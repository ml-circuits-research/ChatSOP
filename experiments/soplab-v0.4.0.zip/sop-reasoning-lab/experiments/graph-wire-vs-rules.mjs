import {
  Reasoner, atom, rule, ref, unifyTerms, compareVariants,
} from '../src/index.mjs';

function edges(nodes = 45, fanout = 2) {
  const out = [];
  for (let i = 0; i < nodes; i++) for (let j = 1; j <= fanout; j++) if (i + j < nodes) out.push(atom('edge', `n${i}`, `n${i + j}`));
  return out;
}

function installGraphWire(r) {
  r.registerWireType('graphClosure', function* ({ reasoner, def, args, seed, evidence, context }) {
    const records = reasoner.store.values().filter((x) => x.atom.sign === 1 && x.atom.pred === def.relation && x.atom.args.length === 2);
    const adjacency = new Map();
    for (const rec of records) {
      const [a, b] = rec.atom.args;
      if (!adjacency.has(a)) adjacency.set(a, []);
      adjacency.get(a).push([b, rec.key]);
    }
    const starts = [...new Set(records.flatMap((x) => x.atom.args))];
    for (const start of starts) {
      let startBindings = unifyTerms(args[0], start, seed);
      if (!startBindings) continue;
      const seen = new Set(), queue = [start];
      while (queue.length) {
        const cur = queue.shift();
        for (const [next, edgeKey] of adjacency.get(cur) ?? []) {
          context.metrics?.inc('graphEdgesVisited');
          if (seen.has(next)) continue;
          seen.add(next); queue.push(next);
          const b = unifyTerms(args[1], next, startBindings);
          if (b) yield { bindings: b, evidence: [...evidence, edgeKey] };
        }
      }
    }
  });
  r.addWire({
    kind: 'wire', wireType: 'graphClosure', id: 'reachable',
    params: ['?from', '?to'], relation: 'edge',
    dependencies: [atom('edge', '?from', '?to')],
  });
}

const results = await compareVariants({
  build: (variant) => {
    const r = new Reasoner().facts(edges());
    if (variant.name === 'recursive-rules') {
      r.addRules([
        rule('reach.base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
        rule('reach.rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
      ]);
      return { reasoner: r, goal: atom('reach', 'n0', '?to'), select: ['?to'] };
    }
    installGraphWire(r);
    return { reasoner: r, goal: ref('reachable', 'n0', '?to'), select: ['?to'] };
  },
  variants: [
    { name: 'recursive-rules', strategy: 'delta', scope: 'sliced' },
    { name: 'specialized-graph-wire', strategy: 'delta', scope: 'sliced' },
  ],
});

for (const r of results) {
  console.log(`\n${r.name}`);
  console.log('matches reference:', r.matchesReference);
  console.log('answers:', r.rows.length);
  console.log('metrics:', r.metrics);
}
