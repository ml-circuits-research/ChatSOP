# SOP Reasoning Lab

**Research baseline v0.4.0.** The repository is intended to preserve not only code but the hypotheses, falsification criteria and experimental protocol needed to compare future reasoning strategies.

A dependency-free Node.js research harness for experimenting with symbolic reasoning over SOP-style SSA/CNL circuits.

The project is deliberately designed as a **baseline that can be replaced piece by piece**. It is not tied to one final ontology of wire types. New binding providers, new wire semantics and new materialization strategies can be registered without rewriting the core evaluator or the benchmark suite.

Node.js 20+, ESM `.mjs`, zero runtime dependencies.

## Core idea

The fundamental runtime object is not a scalar value but a **relation of variable bindings**.

A condition consumes a binding environment and emits zero or more compatible environments:

```text
condition : Bindings -> 0..N Bindings + Evidence
```

This gives one common execution model for relation lookup, joins, OR, absence checks, constraints, aggregate views, external solvers and reusable subcircuits.

Rules project successful bindings into new immutable claims. Recursive rules are evaluated to a fixed point. Claims retain provenance and positive/negative support independently.

## Quick start

```bash
npm test
node bin/sop-run.mjs examples/family.sop
node bin/sop-run.mjs examples/planning.sop --plan
node bin/sop-run.mjs examples/abduction.sop --abduct
npm run bench
```

## CNL example

```text
@p1 claim
VALUE parent Ana Bob

@p2 claim
VALUE parent Bob Maria

@grandparent all
GIVES ?x ?y
MATCH parent ?x ?middle
MATCH parent ?middle ?y

@children all
GIVES ?parent ?child
MATCH parent ?parent ?child

@childCount reduce
GIVES ?parent ?count
FROM $children ?parent ?child
GROUP ?parent
COUNT ?child AS ?count

@r1 rule
WHEN $grandparent ?x ?y
THEN grandparent ?x ?y

@q goal
WHERE grandparent ?who Maria
FIND ?who
```

No predicate parentheses or commas are required. Named wires represent the expression structure, so complex logic can stay SSA-like instead of growing a nested expression syntax.

## Built-in semantic elements

| Element | Role |
|---|---|
| `claim` | positive or explicit negative evidence |
| `all` | conjunction / natural join |
| `any` | disjunction / union |
| `reduce` | grouping and aggregation |
| `rule` | derive/materialize claims |
| `goal` | query a relation of bindings |
| `transition` | state-changing operator for planning |
| `assumption` | candidate missing premise for abduction |
| `CALL` | extensible binding provider |
| `TEST` | deterministic constraint/builtin |
| `NONE` | stratified not-exists / negation-as-failure |
| `NOT` | explicit negative evidence |

## Reasoning currently covered

The same representation supports recursive deduction, relational querying, constraints, local contradictions, aggregation, bounded abduction, best-first planning and a small rule-induction research harness.

This does **not** mean that all of those problems are solved by one efficient algorithm. The project separates a small semantic kernel from specialized search/evaluation strategies so those strategies can be compared experimentally.

## Evaluation strategies

Two materializers are included:

- `naive`: repeated fixed-point rule evaluation;
- `delta`: semi-naive-style delta restriction for the positive Horn fragment, with a safe fallback for more general rule bodies.

Two scopes are supported by `Reasoner.evaluate()`:

- `global`: materialize all rules;
- `sliced`: compute a backward predicate-dependency slice from the goal and materialize only relevant rules.

`NONE` is evaluated using **stratified negation**. Negative recursive cycles are rejected instead of silently producing order-dependent results.

## Extensibility

### Add a binding provider

```js
reasoner.registerProvider('square', function* (args, bindings) {
  // yield { bindings, evidence }
});
```

A provider can later wrap an SMT solver, graph index, SQL query, vector retriever, deterministic function or another execution engine.

### Add a wire type

```js
reasoner.registerWireType('myWire', function* ({ def, args, seed, evidence, solve }) {
  // implement the semantics and yield binding rows
});
```

The central evaluator does not need to be modified.

### Add a materialization strategy

```js
reasoner.registerMaterializer('myStrategy', (reasoner, options) => {
  // return { rounds, added, facts, converged, ... }
});
```

This is the intended mechanism for comparing future evaluators.

## Metrics

Every execution collects symbolic cost indicators including:

- relation lookups;
- candidate rows;
- unifications;
- matched rows;
- rule firings;
- facts derived;
- fixed-point rounds;
- wire/provider/builtin calls;
- elapsed wall-clock time.

Wall-clock timing is machine-dependent; symbolic counts are usually more useful for architecture comparisons.

## Research experiments

```bash
npm run experiment:depth
npm run experiment:noise
npm run experiment:strategies
npm run experiment:wires
```

The repository also contains seeded randomized tests that compare recursive reasoning with an independent graph transitive-closure implementation. `experiment:wires` compares the same reachability task implemented by recursive rules and by a specialized graph wire.

## Main modules

```text
src/model.mjs                 IR: atoms, rules, transitions, assumptions
src/store.mjs                 indexed four-valued claim store + provenance
src/conditions.mjs            all/any/none/ref/reduce wire definitions
src/wire-types.mjs            pluggable wire semantics
src/providers.mjs             pluggable binding producers
src/engine/evaluator.mjs      binding composition kernel
src/engine/materialize.mjs    fixed-point materializers
src/stratify.mjs              safe NONE / negative-dependency analysis
src/dependency.mjs            backward rule slicing
src/reasoner.mjs              public orchestration API
src/parser.mjs                SOP/CNL parser
src/search/                   generic search, planning, abduction
src/learning/                 micro-world rule-induction experiments
src/comparison.mjs            common comparison contract
src/validate.mjs              static program sanity checks
```

## Documentation

Start with `docs/README.md`. The documents intentionally separate:

- the scientific hypothesis (`RESEARCH_HYPOTHESIS.md`);
- formal/conceptual semantics (`SEMANTIC_MODEL.md`);
- implementation architecture (`ARCHITECTURE.md`);
- experiment discipline (`RESEARCH_PROTOCOL.md`, `COMPARISON_PROTOCOL.md`);
- the long-term abstraction-learning loop (`ABSTRACTION_LEARNING.md`);
- future experiments (`EXPERIMENT_ROADMAP.md`);
- unresolved questions and current limits (`OPEN_QUESTIONS.md`, `LIMITATIONS.md`).

Before adding a permanent primitive, read `WIRE_IDEAS.md` and compare generic rules, a specialized wire and a provider/solver where possible.

## Status

The packaged baseline has a full Node test suite covering the kernel, CNL, recursive closure, randomized graph properties, aggregation, providers, custom wire types, strategy plugins, planning, abduction, rule induction, stratified negation and proof export.
