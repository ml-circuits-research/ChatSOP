import { Reasoner, atom, rule, materializeNaive } from '../src/index.mjs';

const r = new Reasoner();
r.facts([atom('edge', 'A', 'B'), atom('edge', 'B', 'C')]);
r.addRules([
  rule('base', atom('reach', '?x', '?y'), [atom('edge', '?x', '?y')]),
  rule('rec', atom('reach', '?x', '?y'), [atom('reach', '?x', '?z'), atom('edge', '?z', '?y')]),
]);

r.registerMaterializer('instrumentedNaive', (reasoner, options) => {
  const before = reasoner.store.size();
  const result = materializeNaive(reasoner, options);
  return { ...result, custom: { factsBefore: before, factsAfter: reasoner.store.size() } };
});

console.log(r.evaluate(atom('reach', 'A', 'C'), { strategy: 'instrumentedNaive', scope: 'sliced' }));
