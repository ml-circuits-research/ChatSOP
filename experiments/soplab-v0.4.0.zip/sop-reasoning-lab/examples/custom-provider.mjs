import { Reasoner, provider, unifyTerms } from '../src/index.mjs';

const r = new Reasoner();
r.registerProvider('square', function* (args, bindings) {
  const [input, output] = args;
  for (let n = 1; n <= 5; n++) {
    let b = unifyTerms(input, n, bindings);
    if (!b) continue;
    b = unifyTerms(output, n * n, b);
    if (b) yield { bindings: b, evidence: [{ kind: 'provider', provider: 'square' }] };
  }
});

console.log(r.query(provider('square', '?n', '?square'), { select: ['?n', '?square'] }));
