import { Reasoner, atom, ref, unifyTerms } from '../src/index.mjs';

const r = new Reasoner();
r.facts([
  atom('edge', 'A', 'B'),
  atom('edge', 'B', 'C'),
  atom('edge', 'C', 'D'),
]);

// Example of a specialized wire that computes graph reachability directly.
// It exists to demonstrate the extension API; the normal recursive-rule
// implementation remains the baseline for comparisons.
r.registerWireType('graphClosure', function* ({ reasoner, def, args, seed, evidence }) {
  const edges = reasoner.store.values()
    .filter((x) => x.atom.sign === 1 && x.atom.pred === def.relation && x.atom.args.length === 2)
    .map((x) => x.atom.args);
  const adjacency = new Map();
  for (const [a, b] of edges) {
    if (!adjacency.has(a)) adjacency.set(a, []);
    adjacency.get(a).push(b);
  }
  const nodes = new Set(edges.flat());
  for (const start of nodes) {
    const seen = new Set(), queue = [start];
    while (queue.length) {
      const cur = queue.shift();
      for (const next of adjacency.get(cur) ?? []) {
        if (seen.has(next)) continue;
        seen.add(next); queue.push(next);
        let b = unifyTerms(args[0], start, seed);
        if (!b) continue;
        b = unifyTerms(args[1], next, b);
        if (b) yield { bindings: b, evidence: [...evidence, { kind: 'wire', wireType: 'graphClosure', id: def.id }] };
      }
    }
  }
});

r.addWire({
  kind: 'wire', wireType: 'graphClosure', id: 'reachable',
  params: ['?from', '?to'], relation: 'edge',
});

console.log(r.query(ref('reachable', 'A', '?to'), { select: ['?to'] }));
